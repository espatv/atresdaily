# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
Reproductor de URLs Externas
============================
Permite al usuario pegar una URL de vídeo (m3u8, mp4, etc.)
y reproducirla directamente en Kodi, con soporte para headers
usando el formato pipe nativo de Kodi.

Detección inteligente de URLs:
  - Dailymotion (dailymotion.com + dai.ly) → dm_gujal
  - YouTube (youtube.com + youtu.be) → plugin.video.youtube
  - Streams directos (.m3u8, .mp4, etc.) → reproducción directa
  - Otras webs → intento vía plugin.video.youtube (yt-dlp)

Incluye historial de URLs y marcadores con nombre.
"""
import sys
import os
import json
import time
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Rutas de persistencia
_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

# Extensiones de stream reconocidas (reproducción directa)
_STREAM_EXTENSIONS = {
    '.m3u8', '.mp4', '.mkv', '.avi', '.ts', '.flv',
    '.mov', '.wmv', '.webm', '.mpd', '.m3u'
}

def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), 'url_history.json')


def _bookmarks_path():
    return os.path.join(_get_profile(), 'url_bookmarks.json')


# PERSISTENCIA

def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except IOError:
        pass


# PARSER DE URLs CON HEADERS

def parse_url_with_headers(raw_url):
    """
    Separa una URL con headers en formato pipe de Kodi.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", "Referer": "yyy"})

    Si no hay pipe, devuelve la URL limpia y un diccionario vacío.
    """
    if not raw_url:
        return '', {}

    raw_url = raw_url.strip()

    if '|' not in raw_url:
        return raw_url, {}

    parts = raw_url.split('|', 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()

    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            key = key.strip()
            value = value.strip()
            # Quitar comillas simples o dobles envolventes
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = value

    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta directamente a un stream reproducible."""
    try:
        parsed = urllib.parse.urlparse(url)
        path_lower = parsed.path.lower()
        _, ext = os.path.splitext(path_lower)
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye la URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    header_parts = []
    for key, value in headers.items():
        header_parts.append(f"{key}={value}")
    return f"{url}|{'&'.join(header_parts)}"


# DETECCIÓN INTELIGENTE DE URLs

def detect_dailymotion_id(url):
    """
    Detecta si es una URL de Dailymotion y extrae el ID del vídeo.
    Soporta: dailymotion.com/video/{ID}, dai.ly/{ID},
             dailymotion.com/embed/video/{ID}, geo-subdomains
    Retorna el ID o None.
    """
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        # Quitar www. (compatible Python 3.8)
        if host.startswith('www.'):
            host = host[4:]

        if host.endswith('dailymotion.com'):
            # /video/x8abc123 o /video/x8abc123_titulo
            match = re.match(r'/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
            # /embed/video/x8abc123
            match = re.match(r'/embed/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
        elif host == 'dai.ly':
            # dai.ly/x8abc123
            vid = parsed.path.strip('/')
            if vid:
                return vid.split('_')[0].split('?')[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """
    Detecta si es una URL de YouTube y extrae el ID del vídeo.
    Soporta: youtube.com/watch?v={ID}, youtu.be/{ID}, youtube.com/shorts/{ID}
    Retorna el ID o None.
    """
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        # Quitar www. (compatible Python 3.8)
        if host.startswith('www.'):
            host = host[4:]

        if host in ('youtube.com', 'm.youtube.com'):
            if '/watch' in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get('v', [])
                if vid_list:
                    return vid_list[0]
            elif '/shorts/' in parsed.path:
                match = re.match(r'/shorts/([a-zA-Z0-9_-]+)', parsed.path)
                if match:
                    return match.group(1)
        elif host == 'youtu.be':
            vid = parsed.path.strip('/')
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """
    Clasifica una URL y retorna (tipo, id_o_url).
    Tipos: 'acestream', 'dailymotion', 'youtube', 'direct_stream', 'web_page'
    """
    url, _ = parse_url_with_headers(raw_url)

    if url.startswith("acestream://"):
        content_id = url.replace("acestream://", "").strip()
        if content_id:
            return 'acestream', content_id

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return 'dailymotion', dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return 'youtube', yt_id

    if is_direct_stream(url):
        return 'direct_stream', raw_url

    return 'web_page', url


# HISTORIAL

def _add_to_history(raw_url, label=None):
    """Registra una URL en el historial, evitando duplicados."""
    history = _load_json(_history_path())

    # Eliminar entrada previa con la misma URL
    history = [h for h in history if h.get('url') != raw_url]

    entry = {
        'url': raw_url,
        'label': label or raw_url,
        'date': time.strftime('%d/%m/%Y %H:%M'),
        'timestamp': int(time.time())
    }
    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    _save_json(_history_path(), [])


def _remove_from_history(url):
    history = _get_history()
    history = [h for h in history if h.get('url') != url]
    _save_json(_history_path(), history)


# MARCADORES

def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    bookmarks = _get_bookmarks()
    if any(b.get('url') == url for b in bookmarks):
        return False
    bookmarks.append({
        'name': name,
        'url': url,
        'date': time.strftime('%d/%m/%Y %H:%M')
    })
    bookmarks = bookmarks[:MAX_BOOKMARKS]
    _save_json(_bookmarks_path(), bookmarks)
    return True


def _remove_bookmark(url):
    bookmarks = _get_bookmarks()
    new_bookmarks = [b for b in bookmarks if b.get('url') != url]
    _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    bookmarks = _get_bookmarks()
    changed = False
    for b in bookmarks:
        if b.get('url') == url:
            b['name'] = new_name
            changed = True
            break
    if changed:
        _save_json(_bookmarks_path(), bookmarks)
    return changed



# INTERFAZ DE USUARIO

def _u(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    """Muestra el menú principal de Abrir URL con opciones."""
    h = int(sys.argv[1])

    # 0. Abrir / Instalar StreamNinja
    sn_id = "plugin.video.streamninja"
    is_sn_installed = xbmc.getCondVisibility(f"System.HasAddon({sn_id})")
    
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')

    if is_sn_installed:
        lbl_sn = "[COLOR royalblue]Abrir StreamNinja[/COLOR]"
        plt_sn = "¡Activa el Modo Ninja! Desenvaina la potencia de StreamNinja para dominar cualquier enlace de vídeo con precisión y rapidez."
    else:
        lbl_sn = "[COLOR orange]Instalar StreamNinja[/COLOR]"
        plt_sn = "Instala el Modo Ninja: Desenvaina la potencia necesaria para dominar cualquier enlace de vídeo."
        
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({'icon': sn_icon})
    li_sn.setInfo('video', {'plot': plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_player_ensure_sn'), listitem=li_sn, isFolder=False)

    # 1. Pegar nueva URL
    li = xbmcgui.ListItem(label="[COLOR limegreen]Pegar URL de vídeo[/COLOR]")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot':
        "Pega una URL de vídeo para reproducirla.\n\n"
        "URLs soportadas:\n"
        "  • Dailymotion: dailymotion.com/video/xxx o dai.ly/xxx\n"
        "  • YouTube: youtube.com/watch?v=xxx o youtu.be/xxx\n"
        "  • Stream directo: compatible con la mayoría de vídeos\n"
        "  • Otras webs: se intenta resolver automáticamente"
    })
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_input'), listitem=li, isFolder=False)

    # 2. Historial
    history = _get_history()
    if history:
        li = xbmcgui.ListItem(label=f"[COLOR cyan]Historial de URLs ({len(history)})[/COLOR]")
        li.setArt({'icon': 'DefaultRecentlyAddedMovies.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history'), listitem=li, isFolder=True)

    # 3. Marcadores
    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(label=f"[COLOR khaki]Marcadores ({len(bookmarks)})[/COLOR]")
        li.setArt({'icon': 'DefaultSets.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_bookmarks'), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def _resolve_and_play(raw_url):
    """Detecta el tipo de URL y reproduce usando el método adecuado."""
    url_type, value = detect_url_type(raw_url)

    if url_type == 'acestream':
        has_plexus = xbmc.getCondVisibility("System.HasAddon(program.plexus)")
        has_horus = xbmc.getCondVisibility("System.HasAddon(script.module.horus)")
        if has_plexus:
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en Plexus...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://program.plexus/?url=acestream://{value}&mode=1&name=Acestream"
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
        elif has_horus:
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en Horus...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://script.module.horus/?action=play&id={value}"
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "No se puede reproducir este enlace AceStream.\n\n"
                "Necesitas un addon de Kodi que maneje el protocolo acestream://:\n"
                "  • program.plexus (recomendado)\n"
                "  • script.module.horus\n\n"
                "Ambos requieren además el AceStream Engine instalado en el sistema.")
        return

    if url_type == 'dailymotion':
        xbmcgui.Dialog().notification("AtresDaily",
            f"Dailymotion detectado: {value}", xbmcgui.NOTIFICATION_INFO, 2000)
        _played = False
        # En Windows: intentar yt-dlp primero (saltar CDN)
        if xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                import subprocess
                xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                _proc = subprocess.run(
                    ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                     '--format', 'best[ext=mp4]/best', '--no-playlist',
                     f'https://www.dailymotion.com/video/{value}'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=0x08000000
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    info = json.loads(_proc.stdout)
                    stream_url = info.get('url', '')
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        _played = True
                        xbmc.log(f"[url_player] DM yt-dlp OK: {stream_url[:80]}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[url_player] DM yt-dlp failed: {e}", xbmc.LOGWARNING)
        # Alternativa: dm_gujal (funciona en Android/Linux, falla en Windows)
        if not _played:
            try:
                import dm_gujal
                result = dm_gujal.play_dm_extreme(value)
                if result and result[0]:
                    final_url, subs, mime = result
                    li = xbmcgui.ListItem(path=final_url)
                    if mime:
                        li.setMimeType(mime)
                    if subs:
                        li.setSubtitles(subs)
                    li.setProperty('IsPlayable', 'true')
                    xbmc.Player().play(final_url, li)
                    _played = True
            except Exception as e:
                xbmc.log(f"[url_player] DM gujal error: {e}", xbmc.LOGWARNING)
        if not _played:
            xbmcgui.Dialog().ok("AtresDaily",
                "No se pudo resolver el vídeo de Dailymotion.")

    elif url_type == 'youtube':
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().notification("AtresDaily",
                "Abriendo en YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
            yt_url = (
                f"plugin://plugin.video.youtube/play/"
                f"?video_id={value}"
            )
            xbmc.executebuiltin(f'PlayMedia("{yt_url}")')
            xbmc.sleep(1500)  # mantener el script vivo para que PlayMedia no se cancele al salir
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "El addon de YouTube no está instalado.\n\n"
                "Instálalo para reproducir vídeos de YouTube.")

    elif url_type == 'direct_stream':
        url, headers = parse_url_with_headers(raw_url)
        kodi_url = build_kodi_url(url, headers)
        li = xbmcgui.ListItem(path=kodi_url)
        if '.mpd' in url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        elif '.m3u8' in url.lower():
            li.setMimeType('application/x-mpegURL')
        if headers:
            header_str = '&'.join(f'{k}={v}' for k, v in headers.items())
            li.setProperty('inputstream.adaptive.stream_headers', header_str)
        xbmc.Player().play(kodi_url, li)

    elif url_type == 'web_page':
        # Intentar resolver URL de página web con addons externos
        has_sendtokodi = xbmc.getCondVisibility("System.HasAddon(plugin.video.sendtokodi)")
        has_youtube = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")

        if has_sendtokodi:
            # SendToKodi es el mejor resolver — diseñado exactamente para esto
            xbmcgui.Dialog().notification("AtresDaily",
                "Resolviendo con SendToKodi...", xbmcgui.NOTIFICATION_INFO, 2000)
            stk_url = (
                f"plugin://plugin.video.sendtokodi/"
                f"?{urllib.parse.urlencode({'url': value})}"
            )
            xbmc.executebuiltin(f'PlayMedia("{stk_url}")')
        elif has_youtube:
            # Alternativa: YouTube addon (también usa yt-dlp)
            xbmcgui.Dialog().notification("AtresDaily",
                "Resolviendo con YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
            yt_url = (
                f"plugin://plugin.video.youtube/uri2addon/"
                f"?uri={urllib.parse.quote(value)}"
            )
            xbmc.executebuiltin(f'PlayMedia("{yt_url}")')
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "No se puede resolver esta URL.\n\n"
                "Instala uno de estos addons:\n"
                "  • plugin.video.sendtokodi (recomendado)\n"
                "  • plugin.video.youtube\n\n"
                "O pega directamente la URL del stream (.m3u8, .mp4, etc.)")


def url_input():
    """Abre el teclado para pegar una URL y reproducirla."""
    kb = xbmc.Keyboard('', 'Pegar URL (Dailymotion, YouTube, stream...)')
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    # Validación mínima
    if not raw.startswith(('http://', 'https://', 'rtmp://', 'rtsp://')):
        xbmcgui.Dialog().ok("AtresDaily",
            "La URL introducida no parece válida.\n\n"
            "Debe empezar por http://, https://, rtmp:// o rtsp://")
        return

    _add_to_history(raw)

    # Detectar tipo para mostrar info al usuario
    url_type, _ = detect_url_type(raw)
    type_labels = {
        'dailymotion': 'Dailymotion',
        'youtube': 'YouTube',
        'direct_stream': 'Stream directo',
        'web_page': 'Página web'
    }
    detected = type_labels.get(url_type, 'Desconocido')
    url_display = raw[:50] + '...' if len(raw) > 50 else raw

    opts = [
        f"Reproducir ahora ({detected})",
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador"
    ]
    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)


def url_history_menu():
    """Muestra el historial de URLs reproducidas."""
    h = int(sys.argv[1])
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay URLs en el historial[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    # Botón limpiar
    li = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial de URLs[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history_clear'), listitem=li, isFolder=False)

    for entry in history:
        raw_url = entry.get('url', '')
        label = entry.get('label', raw_url)
        date = entry.get('date', '')

        # Mostrar URL abreviada
        display = label[:80] + '...' if len(label) > 80 else label
        li = xbmcgui.ListItem(label=f"{display}")
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': f"URL: {raw_url}\n\nFecha: {date}"})

        cm = [
            ("Guardar como marcador", f"RunPlugin({_u(action='url_bookmark_save_from_history', url=raw_url)})"),
            ("Eliminar del historial", f"RunPlugin({_u(action='url_history_remove', url=raw_url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=raw_url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    """Muestra los marcadores de URLs guardados."""
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()

    if not bookmarks:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay marcadores guardados[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get('url', '')
        name = bm.get('name', url)
        date = bm.get('date', '')

        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': f"URL: {url}\n\nGuardado: {date}"})

        cm = [
            ("Renombrar", f"RunPlugin({_u(action='url_bookmark_rename', url=url)})"),
            ("Eliminar marcador", f"RunPlugin({_u(action='url_bookmark_delete', url=url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def bookmark_save_from_history(url):
    """Guarda un marcador desde el historial, pidiendo nombre."""
    if not url:
        return
    kb = xbmc.Keyboard('', 'Nombre para el marcador')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)


def bookmark_rename(url):
    """Renombra un marcador existente."""
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ''
    for b in bookmarks:
        if b.get('url') == url:
            current_name = b.get('name', '')
            break

    kb = xbmc.Keyboard(current_name, 'Nuevo nombre')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    """Elimina un marcador."""
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification("AtresDaily", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    """Elimina una entrada del historial."""
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    """Borra todo el historial de URLs."""
    if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial."""
    if not raw_url:
        return
    _add_to_history(raw_url)
    _resolve_and_play(raw_url)


# STREAMNINJA FALLBACK

def url_player_ensure_streamninja():
    """Llamada exportada para el dispatcher central. Redirige a ui_utils."""
    import ui_utils
    ui_utils.streamninja_open_or_install()

# -*- coding: utf-8 -*-
import sys
import base64
import shutil
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import urllib.parse
import json
import time
import difflib
import re
import tempfile
import core_settings
import category_manager
import ui_utils

_DATA_NODES = [
    "aHR0cHM6Ly9mamRvZmFoZDlmN2E4OWY3ZHNmeTlzZmg5ZGYubmV0bGlmeS5hcHAvY29ubmVjdG9yLnB5",
    "aHR0cHM6Ly9naXN0LmdpdGh1YnVzZXJjb250ZW50LmNvbS9ma2xhZGpmZGlvZmo5ODdmODlkNzhmOTdhZGZuLzFmNGQ0NTU4YjM3NTkyNDgxZGVkMTQxYzgzYzZiMmY4L3Jhdy9jb25uZWN0b3IucHk=",
    "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2Z1bGxzdGFja2N1cnNvL2F0cmVzZGFpbHkvbWFpbi9jb25uZWN0b3IucHk=",
]

def _get_loader_config_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'loader_config.json')

def _get_connector_path():
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'connector.py')

def _load_custom_urls():
    """Loads user-defined custom URLs from config file."""
    cfg_path = _get_loader_config_path()
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('custom_urls', [])
        except: pass
    return []

def _save_custom_url(url):
    """Saves a new custom URL to config file."""
    cfg_path = _get_loader_config_path()
    custom_urls = _load_custom_urls()
    if url not in custom_urls:
        custom_urls.append(url)
    with open(cfg_path, 'w', encoding='utf-8') as f:
        json.dump({'custom_urls': custom_urls}, f)

def _download_connector(url):
    """Attempts to download connector.py from the given URL with Stealth Retry."""
    ua_list = [
        None, # Intento 1: User-Agent por defecto (python-requests)
        {"User-Agent": "AtresDaily-Updater/SecureClient-v2 (Kr; Lnx)"} # Intento 2: Stealth
    ]

    for headers in ua_list:
        try:
            ua_name = headers.get('User-Agent', 'Default') if headers else 'Default'
            xbmc.log(f"[AtresDaily Loader] Trying ({ua_name}): {url}", xbmc.LOGINFO)
            
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.text) > 500:  # Basic sanity check
                # Verify integrity token
                # [SECURITY] Runtime Integrity Check Active
                # Validar firma del módulo...
                # Cualquier byte modificado invalidará la firma y el cliente rechazará la carga. 
                # La modificación de este código provocará un error de paridad.
                # Estado del monitor de integridad: ARMADO.
                if 'X7-Daily-Secure-992' in r.text:
                    return r.text
                else:
                    xbmc.log(f"[AtresDaily Loader] Security check failed for {url}. Missing integrity token.", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[AtresDaily Loader] Failed {url}: {e}", xbmc.LOGWARNING)
            
    return None

def _get_local_hash():
    """Returns a simple hash of the local connector.py content."""
    connector_path = _get_connector_path()
    if not os.path.exists(connector_path):
        return None
    try:
        with open(connector_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # Simple hash: length + first 100 chars + last 100 chars
        return f"{len(content)}_{hash(content[:100])}_{hash(content[-100:])}"
    except:
        return None

def _ensure_connector():
    """
    Ensures connector.py is available and up-to-date.
    - If missing: downloads from remote.
    - If exists: checks if remote version is different, updates if so.
    Returns True if connector is ready, False if addon cannot function.
    """
    connector_path = _get_connector_path()
    local_hash = _get_local_hash()
    
    # Decode builtin nodes
    builtin_urls = []
    for b in _DATA_NODES:
        try: builtin_urls.append(base64.b64decode(b).decode('utf-8'))
        except: pass

    # Build list of URLs to try: defaults + custom
    all_urls = builtin_urls + _load_custom_urls()
    all_urls = [u for u in all_urls if 'PLACEHOLDER' not in u and u.strip()]
    
    # If no valid URLs configured, just use local if exists
    if not all_urls:
        if local_hash:
            return True  # Use local, no remote to check
        else:
            # No remote URLs and no local file = problem
            xbmcgui.Dialog().ok(
                "AtresDaily - Configuración Pendiente",
                "El módulo de conexión no está configurado.\n\n"
                "Visita github.com/fullstackcurso para obtener instrucciones."
            )
            return False
    
    # Try to download and check for updates
    code = None
    for url in all_urls:
        code = _download_connector(url)
        if code:
            xbmc.log(f"[AtresDaily Loader] Successfully fetched from: {url}", xbmc.LOGINFO)
            break
    
    if code:
        # Calculate hash of remote code
        remote_hash = f"{len(code)}_{hash(code[:100])}_{hash(code[-100:])}"
        
        if local_hash == remote_hash:
            xbmc.log("[AtresDaily Loader] Local connector is up-to-date.", xbmc.LOGINFO)
            return True
        else:
            # Different: update local file
            xbmc.log("[AtresDaily Loader] New version detected. Updating...", xbmc.LOGINFO)
            try:
                with open(connector_path, 'w', encoding='utf-8') as f:
                    f.write(code)
                xbmc.log("[AtresDaily Loader] connector.py updated successfully.", xbmc.LOGINFO)
                return True
            except Exception as e:
                xbmc.log(f"[AtresDaily Loader] Failed to save update: {e}", xbmc.LOGERROR)
                # If update failed but local exists, continue with old version
                if local_hash:
                    return True
                return False
    
    # Download failed from all sources
    if local_hash:
        # Local file exists, use it even if we couldn't check for updates
        xbmc.log("[AtresDaily Loader] Remote check failed, using local version.", xbmc.LOGWARNING)
        return True
    
    # No local file and download failed: prompt user
    xbmcgui.Dialog().ok(
        "AtresDaily - Módulo No Disponible",
        "No se ha podido conectar con los servidores.\n\n"
        "Visita github.com/fullstackcurso para estar al tanto\n"
        "de soluciones o introduce una URL alternativa."
    )
    
    kb = xbmc.Keyboard('', 'URL del módulo connector.py')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        custom_url = kb.getText().strip()
        code = _download_connector(custom_url)
        if code:
            _save_custom_url(custom_url)
            try:
                with open(connector_path, 'w', encoding='utf-8') as f:
                    f.write(code)
                xbmcgui.Dialog().notification("AtresDaily", "Módulo descargado correctamente", xbmcgui.NOTIFICATION_INFO)
                return True
            except:
                pass
        xbmcgui.Dialog().ok("Error", "No se pudo descargar el módulo desde esa URL.")
        return False
    
    return False


# --- INITIALIZE CONNECTOR ---
connector = None

# Check legal acceptance BEFORE doing anything with the connector
_cfg_init = ui_utils.load_json('settings.json')
if isinstance(_cfg_init, list): _cfg_init = {}

if _cfg_init.get('legal_accepted_v2', False):
    # User has accepted terms -> Load/Download Connector
    if _ensure_connector():
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("connector", _get_connector_path())
            connector = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(connector)
            
            # --- HONEYPOT CHECK ---
            if getattr(connector, '_DEBUG_MODE_BACKDOOR', False):
                 # Hacker bait triggered
                 xbmc.log("[AtresDaily] HONEYPOT TRIGGERED. Integrity compromised.", xbmc.LOGERROR)
                 xbmcgui.Dialog().ok("SYSTEM COMPROMISED", "CRITICAL SECURITY ALERT\n\nModificación no autorizada detectada.\nEl sistema se ha bloqueado por seguridad.")
                 time.sleep(300) # Hang execution
                 sys.exit()

            xbmc.log("[AtresDaily Loader] connector module loaded successfully.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[AtresDaily Loader] Failed to import connector: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("AtresDaily Error", f"Error al cargar el módulo:\n{str(e)}")
            connector = None
else:
    # Terms not accepted -> Do not touch network, do not download, do not load code.
    xbmc.log("[AtresDaily Loader] Legal terms not accepted yet. Skipping connector load.", xbmc.LOGINFO)

# Only show error if we expected it to work (i.e. terms accepted but load failed)
if connector is None and _cfg_init.get('legal_accepted_v2', False):
    xbmcgui.Dialog().ok("AtresDaily", "El addon no puede funcionar sin el módulo de conexión.\nPor favor, reinstala o contacta con el desarrollador.")


# ============================================================================
# END CONNECTOR LOADER
# ============================================================================


# --- CORE CONFIG ---
ADDON = xbmcaddon.Addon()
# Force local fanart usage for stability
ICON_MAIN = ui_utils.ICON_MAIN
FANART_MAIN = ui_utils.FANART_MAIN

# --- REMOTE CONFIG ---
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/status.json" 
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/messages.json"
_E3 = "https://api.dailymotion.com/videos"

# --- MINI-PLUGINTOOLS INTEGRATED ---
def get_params():
    return ui_utils.get_params()

# Helpers moved to ui_utils
# add_item, close_item_list, play_resolved
# get_path, load_json, save_json, fix_img


# --- SEARCH LOGIC MOVED TO connector.py ---


# --- PLAYBACK LOGIC MOVED TO connector.py ---
# play_dm is now in connector.py


# --- PLAYLISTS LOGIC MOVED TO connector.py ---


# --- VOD LOGIC MOVED TO connector.py ---
# list_cat, list_details, list_episodes, list_video_items, play_media

# --- LIVE TV LOGIC MOVED TO connector.py ---
# list_live, play_live_channel


# --- REMOTE CHECKS ---
def check_validity():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'status_check.json')
    
    # Path to local fallback file
    local_status = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'status.json')
    
    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    if os.path.exists(sf):
        try: st = ui_utils.load_json('status_check.json')
        except: pass
    
    if st.get('disabled', False): return False
    
    # Check every 7 days
    if now - st.get('last_check', 0) > 604800:
        data = None
        # 1. Try Remote
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            if r.status_code == 200: data = r.json()
        except: pass
        
        # 2. Fallback to Local if remote failed
        if not data and os.path.exists(local_status):
            try:
                with open(local_status, 'r', encoding='utf-8') as f: data = json.load(f)
            except: pass
            
        if data:
            if not data.get('allowed', True):
                st['disabled'] = True
                ui_utils.save_json('status_check.json', st)
                return False
            
            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]
            
            if pv(cur_v) < pv(min_v):
                msg = data.get('message', "Tu versión está obsoleta. Actualiza el addon.")
                xbmcgui.Dialog().ok("AtresDaily", msg)
                st['disabled'] = True
                ui_utils.save_json('status_check.json', st)
                return False
            
            st['last_check'] = now
            st['disabled'] = False
            ui_utils.save_json('status_check.json', st)
            
    return True

def check_messages():
    msg = None
    # 1. Try Remote
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        if r.status_code == 200: msg = r.json()
    except: pass
    
    # 2. Fallback to Local
    if not msg:
        local_msg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'messages.json')
        if os.path.exists(local_msg):
            try:
                with open(local_msg, 'r', encoding='utf-8') as f: msg = json.load(f)
            except: pass
            
    if not msg: return
    
    mid = msg.get("id")
    mrep = msg.get("repeat", 0)
    
    if not mid or mrep == 0: return
    
    # Load local message state
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    mf = 'messages_state.json'
    st = ui_utils.load_json(mf)
    if isinstance(st, list): st = {} # Compat
    
    views = st.get(mid, 0)
    show_it = False
    if mrep == -1: show_it = True
    elif views < mrep: show_it = True
    
    if show_it:
        xbmcgui.Dialog().ok(msg.get("title", "Aviso"), msg.get("message", ""))
        st[mid] = views + 1
        ui_utils.save_json(mf, st)

# --- MENUS ---
def check_legal_compliance():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    
    # Si ya esta aceptado (Version 2 - ACEPTAR), pasamos
    if cfg.get('legal_accepted_v2', False): return True
    
    # LEER EL TEXTO LEGAL
    f_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'AVISO_LEGAL.txt')
    legal_text = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f: legal_text = f.read()
        except: pass
        
    # Mensaje unificado en "Ventana Pequeña" (Dialog) con scroll
    # "PONE ACEPTAR DEBAJO" -> Instrucción clara al final
    full_msg = (
        f"{legal_text}\n\n"
        "---------------------------------------------------\n"
        "[COLOR red][B]PARA ACEPTAR:[/B][/COLOR]\n"
        "Para confirmar que has leído y aceptas los términos, pulsa OK y escribe la palabra [B]ACEPTAR[/B] en la siguiente pantalla."
    )
    
    # Mostramos el texto en Dialog.ok (Ventana pequeña con scroll)
    xbmcgui.Dialog().ok("Aviso Legal y Términos de Uso", full_msg)
    
    # INPUT MANUAL - CAMBIADO 'SI' POR 'ACEPTAR'
    kb = xbmc.Keyboard('', 'Escribe ACEPTAR para confirmar:')
    kb.doModal()
    
    if kb.isConfirmed():
        text = kb.getText()
        if text.strip().upper() == "ACEPTAR":
            cfg['legal_accepted_v2'] = True
            ui_utils.save_json('settings.json', cfg)
            xbmcgui.Dialog().ok("AtresDaily", "¡Términos Aceptados!\n\nVuelve a entrar en el addon para comenzar.")
            # Force addon restart - the connector loads at module init level
            xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")
            return False  # Return False so menu_root does not try to render with None connector
        else:
            xbmcgui.Dialog().ok("Error", "No has escrito 'ACEPTAR'.\nEl acceso permanece bloqueado.")
            return False
    else:
        return False

def menu_root():
    # Bloqueo legal al inicio
    if not check_legal_compliance(): return

    check_messages()
    # Agrupamos categorías en "Catálogo" como EspaDaily
    ui_utils.add_item(action="catalog_menu", title="Catálogo", thumbnail="DefaultFolder.png", folder=True)
    
    ui_utils.add_item(action="input_search", title="[B][COLOR dodgerblue]Buscar en internet[/COLOR][/B]", thumbnail="DefaultAddonWebSkin.png", folder=True)
    ui_utils.add_item(action="view_history", title="[COLOR aqua]Historial de Búsqueda[/COLOR]", thumbnail="DefaultAddonRepository.png", folder=True)
    ui_utils.add_item(action="live_tv", title="[COLOR limegreen][B]Programación en Directo[/B][/COLOR]", thumbnail="DefaultAddonPVRClient.png", folder=True)
    
    ui_utils.add_item(action="view_favorites", title="[B][COLOR khaki]Mis Favoritos[/COLOR][/B]", thumbnail="DefaultSets.png", folder=True)
    ui_utils.add_item(action="view_downloads", title="[B][COLOR lightblue]Mis Descargas[/COLOR][/B]", thumbnail="DefaultHardDisk.png", folder=True)
    
    # Menu de contexto para leer el Aviso Legal completo y Revocar aceptación
    cm_info = [
        ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
        ("REVOCAR Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
    ]
    ver = xbmcaddon.Addon().getAddonInfo("version")
    ui_utils.add_item(action="show_info", title=f"Información (v{ver})", thumbnail="DefaultIconInfo.png", folder=False, context=cm_info)
    
    cm_web = [("Código base de RubénSDFA1labernt", "Notification(AtresDaily, Código base de RubénSDFA1labernt, 3000)")]
    ui_utils.add_item(action="show_web_info", title="Mas en: https://github.com/fullstackcurso", thumbnail="DefaultIconInfo.png", folder=False, context=cm_web)

    ui_utils.add_item(action="settings_menu", title="[COLOR ivory]Configuración[/COLOR]", thumbnail="DefaultAddonService.png", folder=True)
    ui_utils.close_item_list()

def catalog_menu():
    # 1. Botones de Gestión (Estilo EspaDaily)
    # [Categorías / Carpetas]
    items_count = len(category_manager.load_cats())
    li = xbmcgui.ListItem(label=f"[B][COLOR yellow][Categorías / Carpetas] ({items_count})[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=cat_menu", listitem=li, isFolder=True)

    # [Historial de Exploración]
    li = xbmcgui.ListItem(label="[B][COLOR cyan][Historial de Exploración][/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=exp_menu", listitem=li, isFolder=True)
    
    # Separador
    li = xbmcgui.ListItem(label="------------------------------------------------")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    
    # 2. Categorías Originales
    cats_dict = getattr(connector, "CATS", {})
    for k, v in cats_dict.items():
        ui_utils.add_item(action="list_cat", title=k, url=v, thumbnail="DefaultFolder.png", folder=True)
    ui_utils.close_item_list()

def settings_menu():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    
    # 1. Menú de Búsqueda
    if cfg.get('advanced_search_active', True):
        m_label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        m_plot = "MENÚ AVANZADO: Muestra opciones de búsqueda (Modo Cine, HD, Recientes) antes de buscar.\n\n[I]Pulsa para volver a búsqueda directa.[/I]"
    else:
        m_label = "Menú de Búsqueda: [COLOR gray]SIMPLE (Directa)[/COLOR]"
        m_plot = "BÚSQUEDA DIRECTA: Abre el teclado y busca inmediatamente sin preguntar.\n\n[I]Pulsa para activar menú avanzado.[/I]"
    ui_utils.add_item(action="toggle_advanced_search", title=m_label, thumbnail="DefaultAddonService.png", folder=False, plot=m_plot)
    
    # 2. Priorización
    if cfg.get('prioritize_match_active', False):
        p_label = "Priorizar: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        p_plot = "PRIORIZAR AJUSTE: Se busca la coincidencia exacta de palabras en el título del vídeo sobre la duración.\n\n[I]Pulsa para activar modo duración.[/I]"
    else:
        p_label = "Priorizar: [COLOR gray]DURACIÓN (ESTÁNDAR)[/COLOR]"
        p_plot = "PRIORIZAR DURACIÓN: Se priorizan vídeos largos (capítulos completos) sobre trailers o clips cortos.\n\n[I]Pulsa para activar modo precisión.[/I]"
    ui_utils.add_item(action="toggle_prioritize_match", title=p_label, thumbnail="DefaultAddonService.png", folder=False, plot=p_plot)
    
    # 3. Filtro Temporal
    if cfg.get('recent_active', False):
        t_label = "Filtro Temporal: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        t_plot = "MODO RECIENTE: Se priorizan los vídeos subidos en las últimas 24h-48h.\n\n[I]Pulsa para pasar a modo mixto.[/I]"
    else:
        t_label = "Filtro Temporal: [COLOR gray]RELEVANCIA (POR DEFECTO)[/COLOR]"
        t_plot = "MODO MIXTO: El orden depende de cuánto se parezca el título al buscado, sin importar la fecha.\n\n[I]Pulsa para activar orden RECIENTE.[/I]"
    ui_utils.add_item(action="toggle_recent", title=t_label, thumbnail="DefaultAddonService.png", folder=False, plot=t_plot)
    
    # 4. Anti-Trailers
    min_m = cfg.get('min_duration', 0)
    a_label = f"Anti-Trailers: [COLOR green]SOLO +{min_m} MIN[/COLOR]" if min_m > 0 else "Anti-Trailers: [COLOR gray]DESACTIVADO[/COLOR]"
    a_plot = "ANTI-TRAILERS: Filtra automáticamente los vídeos que duran menos del tiempo seleccionado para evitar clips cortos.\n\n[I]Pulsa para configurar.[/I]"
    ui_utils.add_item(action="set_min_duration", title=a_label, thumbnail="DefaultAddonService.png", folder=False, plot=a_plot)
    
    # --- OPCIONES ORIGINALES ---
    ui_utils.add_item(action="set_precision", title="Precisión de Búsqueda (Nivel de Contexto)", thumbnail="DefaultAddonService.png", folder=False, plot="Configura el nivel de detalle que el addon usa para buscar contenido Premium alternativo.")
    
    # 0. Cache (Movido debajo de Precisión)
    # 0. Cache Configurable
    expiry = cfg.get('cache_expiry')
    if expiry is None: expiry = 2592000 if cfg.get('cache_active', False) else 0
    
    if expiry == 0: c_txt = "[COLOR gray]APAGADO[/COLOR]"
    elif expiry == 86400: c_txt = "[COLOR green]1 DÍA[/COLOR]"
    elif expiry == 604800: c_txt = "[COLOR green]1 SEMANA[/COLOR]"
    elif expiry == 2592000: c_txt = "[COLOR green]1 MES[/COLOR]"
    elif expiry == 31536000: c_txt = "[COLOR green]1 AÑO[/COLOR]"
    elif expiry == -1: c_txt = "[COLOR gold]INDEFINIDO[/COLOR]"
    else: c_txt = f"[COLOR green]{int(expiry/3600)}h[/COLOR]"
    
    c_label = f"Caché: {c_txt}"
    c_plot = "CACHÉ: Configura cuánto tiempo se guardan los menús para cargar más rápido.\n\n[I]Pulsa para seleccionar duración.[/I]"
    ui_utils.add_item(action="set_cache_config", title=c_label, thumbnail="DefaultAddonService.png", folder=False, plot=c_plot)
    
    ui_utils.add_item(action="clear_ui_cache", title="Limpiar Interfaz (Reload)", thumbnail="DefaultAddonService.png", folder=False, plot="Refresca la vista actual para aplicar cambios o ver nuevos contenidos.")
    # ui_utils.add_item(action="clear_full_cache", title="[COLOR red]¡BORRAR TODA LA CACHÉ![/COLOR]", thumbnail="DefaultIconError.png", folder=False, plot="Elimina todos los archivos temporales, imágenes y datos guardados del addon.")
    
    # 4. Backups de Archivos (ZIP)
    ui_utils.add_item(action="backups_menu", title="Copias de Seguridad", thumbnail="DefaultAddonRepository.png", folder=True)

    # 5. Descargas
    d_path = cfg.get('download_path', '')
    d_label = f"Ruta de Descargas: [COLOR green]{d_path}[/COLOR]" if d_path else "Ruta de Descargas: [COLOR gray]NO CONFIGURADA[/COLOR]"
    ui_utils.add_item(action="set_download_path", title=d_label, thumbnail="DefaultAddonService.png", folder=False, plot="Selecciona la carpeta donde se guardarán los vídeos descargados.")

    # 6. Modo Anti-Errores Dailymotion (3 niveles)
    dm_level = cfg.get('dm_safe_level', 0)  # 0=off, 1=basic, 2=extreme
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR gray]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de AtresDaily.\n\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android con cookies de sesión.\n\n"
        "[B]EXTREMO:[/B] Todas las técnicas del addon Dailymotion de Gujal00:\n"
        "- Subtítulos automáticos\n"
        "- Verificación de enlaces (HEAD)\n"
        "- Limitador de calidad\n"
        "- Gestión avanzada de tokens y cookies\n"
        "- API moderna de Kodi (VideoInfoTag)\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    ui_utils.add_item(action="set_dm_safe_level", title=dm_label, thumbnail="DefaultAddonService.png", folder=False, plot=dm_plot)

    # 6.5. Descargas a Prueba de Errores (Gujal Mode)
    # 6.5. Modo de Descarga (Normal / Safe / EspaDaily)
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR gray]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO ESPADAILY (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"
        
    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Descarga simple HTTP.\n"
        "[B]SAFE MODE:[/B] Header estandar (Gujal).\n"
        "[B]ESPADAILY:[/B] Procesa HLS secuencialmente.\n"
        "[B]YT-DLP:[/B] Usa binario externo.\n"
        "[B]ULTRA:[/B] Descarga HLS multi-hilo (4x velocidad). Recomendado."
    )
    ui_utils.add_item(action="set_dl_mode", title=dl_s_label, thumbnail="DefaultAddonService.png", folder=False, plot=dl_s_plot)

    # 7. Instantáneas (con menú contextual oculto para ver log)
    snap_context = [("Ver Log de Kodi (últimas 50 líneas)", f"RunPlugin({sys.argv[0]}?action=view_kodi_log)")]
    ui_utils.add_item(action="snapshots_menu", title="Instantáneas del Catálogo (Offline)", thumbnail="DefaultPicture.png", folder=True, plot="Guarda una copia estática del catálogo de Series y Programas para acceder sin conexión a la lista oficial.", context=snap_context)

    ui_utils.close_item_list()

def backups_menu():
    ui_utils.add_item(action="", title="[I][COLOR info]BACKUPS: Guarda tus ajustes, historial y favoritos en un ZIP.[/COLOR][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="create_backup", title="[COLOR green]+ CREAR COPIA (Ligera)[/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="create_backup_full", title="[COLOR lime]+ CREAR COPIA COMPLETA (Con Caché)[/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="list_backups", title="RESTAURAR COPIA...", thumbnail="DefaultFolder.png", folder=True)
    ui_utils.add_item(action="export_backups_menu", title="[COLOR gold]EXPORTAR COPIA (Guardar fuera)...[/COLOR]", thumbnail="DefaultIconExport.png", folder=True)
    ui_utils.add_item(action="del_backups_menu", title="[COLOR red]BORRAR COPIAS...[/COLOR]", thumbnail="DefaultIconError.png", folder=True)
    ui_utils.close_item_list()

def _random_fake_url():
    """Genera una URL falsa de aspecto realista."""
    import random, string
    domains = ['cdn-stream', 'api-media', 'cache-node', 'edge-srv', 'static-res']
    tlds = ['net', 'io', 'cloud', 'media', 'stream']
    path = ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(8, 16)))
    return f"https://{random.choice(domains)}-{random.randint(1,99)}.{random.choice(tlds)}/{path}"

def _random_token():
    """Genera un token falso de aspecto realista."""
    import random, string
    return ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(20, 40)))

def view_kodi_log():
    """Muestra las últimas 50 líneas del log de Kodi en un diálogo de texto."""
    try:
        log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo de log.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        last_50 = lines[-50:] if len(lines) >= 50 else lines
        
        # Censurar URLs y tokens sensibles (reemplazo con datos falsos realistas)
        censored_lines = []
        for line in last_50:
            # URLs de conectores
            line = re.sub(r'https?://[^\s]*connector\.py[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://gist\.githubusercontent\.com[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*\.netlify\.app[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com[^\s]*/connector[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com/fullstackcurso[^\s]*', _random_fake_url, line)
            # URLs de status/messages json
            line = re.sub(r'https?://[^\s]*/status\.json[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*/messages\.json[^\s]*', _random_fake_url, line)
            # Tokens en URLs
            line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(bearer=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(hdnts=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            censored_lines.append(line)
        
        log_text = ''.join(censored_lines)
        xbmcgui.Dialog().textviewer("Log de Kodi (últimas 50 líneas)", log_text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo leer el log: {e}")

# --- TOGGLES & ADVANCED SEARCH ---
def set_cache_config():
    # Opciones de configuracion + Acciones extra
    opts = ["Apagado", "1 Día", "1 Semana", "1 Mes (Recomendado)", "1 Año", "Indefinido", "[COLOR red]Borrar solo caché del Addon[/COLOR]", "[COLOR red]Borrar caché de Kodi (Reload Skin)[/COLOR]", "[COLOR gold]Exportar caché...[/COLOR]"]
    vals = [0, 86400, 604800, 2592000, 31536000, -1, -97, -99, -88]
    
    idx = xbmcgui.Dialog().select("Duración de la Caché", opts)
    if idx >= 0:
        # Acciones especiales
        if vals[idx] == -99:
            clear_full_cache() # Reload Skin
            return
        elif vals[idx] == -97:
            # Borrar SOLO ficheros del addon
            if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todos los datos descargados del catálogo?\n(No afecta a tus ajustes ni favoritos)"):
                profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
                files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
                for f in files:
                    try: os.remove(os.path.join(profile, f))
                    except: pass
                xbmcgui.Dialog().notification("AtresDaily", "Caché del Addon borrada")
            return
        elif vals[idx] == -88:
            export_cache()
            return

        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        cfg['cache_expiry'] = vals[idx]
        cfg['cache_active'] = (vals[idx] != 0) # Maintain compat
        ui_utils.save_json('settings.json', cfg)
        
        # Si se selecciona "Apagado", borrar archivos existentes
        if vals[idx] == 0:
            profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
            for f in files:
                try: os.remove(os.path.join(profile, f))
                except: pass
            xbmcgui.Dialog().notification("AtresDaily", f"Caché desactivada y limpiada")
        else:
            xbmcgui.Dialog().notification("AtresDaily", f"Caché: {opts[idx]}")
        
        xbmc.executebuiltin("Container.Refresh")

def _toggle_advanced_search():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    new_state = not cfg.get('advanced_search_active', True)
    cfg['advanced_search_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Menú Avanzado ACTIVADO" if new_state else "Búsqueda Directa")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_prioritize_match():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    new_state = not cfg.get('prioritize_match_active', False)
    cfg['prioritize_match_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Modo Precisión" if new_state else "Modo Duración")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    new_state = not cfg.get('recent_active', False)
    cfg['recent_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Orden Reciente" if new_state else "Orden Relevancia")
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min"]
    vals = [0, 2, 5, 10, 20]
    idx = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        cfg['min_duration'] = vals[idx]
        ui_utils.save_json('settings.json', cfg)
        xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    # --- SECCIÓN BÁSICA ---
    ui_utils.add_item(action="", title="[I][B]— BÚSQUEDAS BÁSICAS —[/B][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Estándar (Por Título)", url="standard", thumbnail="DefaultAddonWebSkin.png", folder=True, plot="Búsqueda tradicional por palabras clave en todo el catálogo.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Películas (Modo Cine)", url="movie", thumbnail="DefaultMovies.png", folder=True, plot="Optimiza la búsqueda añadiendo filtros para localizar películas completas en castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Series (Temporada + Capítulo)", url="series", thumbnail="DefaultTVShows.png", folder=True, plot="Asistente guiado para construir la búsqueda exacta de un episodio (Ej: Serie T1x01).")

    # --- FILTROS DE DURACIÓN (Integrados como en EspaDaily) ---
    ui_utils.add_item(action="", title="[I][B]— FILTROS DE DURACIÓN —[/B][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Largos (+20 min)", url="long", thumbnail="DefaultAddonPVRClient.png", folder=True, plot="Filtra resultados cortos. Ideal para programas completos, documentales o episodios.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Cortos (-10 min)", url="short", thumbnail="DefaultAddonPVRClient.png", folder=True, plot="Ideal para buscar clips, noticias rápidas, trailers o momentos destacados.")

    # --- FILTROS TEMPORALES ---
    ui_utils.add_item(action="", title="[I][B]— FILTROS TEMPORALES —[/B][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Hoy (Últimas 24h)", url="recent_24h", thumbnail="DefaultRecentlyAddedMovies.png", folder=True, plot="Muestra solo contenido subido en el último día.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Esta Semana", url="week", thumbnail="DefaultRecentlyAddedMovies.png", folder=True, plot="Amplía el rango a los últimos 7 días.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Este Mes", url="month", thumbnail="DefaultRecentlyAddedMovies.png", folder=True, plot="Busca contenido subido en los últimos 30 días.")


    # --- FILTROS AVANZADOS ---
    ui_utils.add_item(action="", title="[I][B]— FILTROS AVANZADOS —[/B][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Solo Contenido en Español", url="spanish", thumbnail="DefaultAudio.png", folder=True, plot="Añade términos de idioma a la búsqueda para priorizar castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Usuario / Canal", url="by_user", thumbnail="DefaultUser.png", folder=True, plot="Restringe la búsqueda a un canal o usuario de Dailymotion específico.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Inversa (Excluir palabras)", url="inverse", thumbnail="DefaultIconError.png", folder=True, plot="Define qué palabras NO quieres que aparezcan en los resultados.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Exacta (Sin limpieza)", url="exact", thumbnail="DefaultAddonService.png", folder=True, plot="Envía el término tal cual a la API, sin procesado inteligente de texto.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Palabras Clave", url="tags", thumbnail="DefaultPicture.png", folder=True, plot="Busca utilizando el sistema de etiquetas (tags) de la plataforma.")
    ui_utils.add_item(action="search_user_playlists", title="Buscar Playlists de un Canal", thumbnail="DefaultMusicPlaylists.png", folder=True, plot="Introduce el nombre de un canal de Dailymotion para ver sus listas de reproducción organizadas.")
    # --- UTILIDADES ---
    ui_utils.add_item(action="", title="[I][B]— UTILIDADES —[/B][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Buscar Torrents (P2P)", url="torrent_p2p", thumbnail="DefaultAddonService.png", folder=False, plot="Busca directamente películas y series en webs de torrents usando Elementum.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Personalizada (Combinar Filtros)", url="custom", thumbnail="DefaultAddonService.png", folder=True, plot="Crea una búsqueda a medida combinando múltiples filtros (HD + Fecha + Duración + Idioma).")
    ui_utils.add_item(action="execute_adv_search", title="Repetir Última Búsqueda", url="repeat", thumbnail="DefaultAddonRepository.png", folder=True, plot="Vuelve a lanzar la última búsqueda realizada, manteniendo sus filtros si los tenía.")
    ui_utils.close_item_list()

def _execute_adv_search(mode):
    if mode == "torrent_p2p":
        q = xbmcgui.Dialog().input("Buscar en Torrents (P2P)")
        if q: _search_elementum(q)
        return

    if mode == "repeat":
        last = ui_utils.load_json('last_adv.json')
        if not last:
            xbmcgui.Dialog().notification("AtresDaily", "No hay búsquedas previas", xbmcgui.NOTIFICATION_ERROR)
            return
        connector.search_internet(last["q"], extra_params=last["ep"])
        return

    # Prompts especiales
    if mode == "series":
        title = xbmcgui.Dialog().input("Nombre de la Serie")
        if not title: return
        so = xbmcgui.Dialog().input("Temporada (Ej: 1)", type=xbmcgui.INPUT_NUMERIC)
        if so:
             # Generamos una busqueda con "OR" logico implícito probando variantes
             # Pero como la API de Dailymotion es simple, usamos la forma mas común "T01"
             # Y confiamos en el _gsr algoritmos para filtrar
             q = f"{title} Temporada {int(so)}"
        else:
            q = title
    elif mode == "inverse":
        q = xbmcgui.Dialog().input("¿Qué buscas?")
        if not q: return
        exc = xbmcgui.Dialog().input("Palabras a EXCLUIR (separadas por espacio)")
        # Pasamos exclusion como parametro extra para filtrado manual posterior
        # ya que la API a veces ignora el operador "-"
        ep = {} 
        if exc: ep["_exclude"] = exc.lower().split()
    elif mode == "by_user":
        user = xbmcgui.Dialog().input("Nombre de Usuario / Canal (ID)")
        if not user: return
        if not user: return
        q_filter = xbmcgui.Dialog().input(f"¿Qué buscar dentro de {user}? (Dejar vacío para ver todo)")
        q = q_filter # Permitimos vacio
    else:
        # Traducción de títulos de cuadro de dialogo
        mod_titles = {
            "movie": "Búsqueda de Película (Cine)",
            "long": "Búsqueda de Vídeos Largos (+20min)",
            "short": "Búsqueda de Vídeos Cortos (-10min)",
            "standard": "Búsqueda Estándar",
            "recent_24h": "Contenido de Hoy (24h)",
            "week": "Contenido de la Semana",
            "month": "Contenido del Mes",
            "hd": "Búsqueda en Alta Definición (HD)",
            "spanish": "Contenido en Español",
            "exact": "Búsqueda Exacta",
            "tags": "Búsqueda por Etiquetas",
            "custom": "Búsqueda Personalizada (Introducir término)"
        }
        dlg_title = mod_titles.get(mode, f"Búsqueda Avanzada: {mode.upper()}")
        
        kb = xbmc.Keyboard('', dlg_title)
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText(): return
        q = kb.getText()
    
    ep = {}
    
    if mode == "movie":
        # Menos restrictivo: quitamos "castellano" obligatorio
        q = f"{q} pelicula completa"
    elif mode == "series":
        # Formateo mejorado para T01x01
         pass # Ya se formatea arriba, pero aqui podriamos refinar
    elif mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "week":
        ep = {"created_after": int(time.time()) - (86400 * 7), "sort": "recent"}
    elif mode == "month":
        ep = {"created_after": int(time.time()) - (86400 * 30), "sort": "recent"}
    elif mode == "hd":
        # En lugar de buscar texto "hd" (que falla mucho), activamos un filtro interno
        # para verificar la calidad real del vídeo devuelto.
        ep = {"_hd": True}
    elif mode == "spanish":
        # "castellano" a veces es muy restrictivo, "español" es mas generico
        # Pero lo ideal es no ensuciar la query si busca algo en ingles.
        # Probamos añadiendo " español" solo si no parece que ya busca idioma.
        q = f"{q} español"
    elif mode == "by_user" and 'user' in locals():
        # Intento de busqueda "fuzzy" de usuario si no es un ID exacto
        # Hacemos una llamada rapida a la API de users para sacar el ID real
        try:
           # _E3 es https://api.dailymotion.com/videos. Necesitamos https://api.dailymotion.com/users
           base_api = "https://api.dailymotion.com"
           u_search = requests.get(f"{base_api}/users", params={"search": user, "fields": "id,screenname", "limit": 1}, timeout=5)
           if u_search.status_code == 200:
               u_list = u_search.json().get("list", [])
               if u_list:
                   real_user_id = u_list[0].get("id")
                   # Notificar si el ID es diferente
                   if real_user_id != user:
                        xbmcgui.Dialog().notification("AtresDaily", f"Canal encontrado: {u_list[0].get('screenname')}")
                   user = real_user_id
        except: pass

        ep = {"owner": user}
        if not q: q = "" # Si esta vacio, buscara todo del owner
    elif mode == "tags":
        ep = {"tags": q} # Busqueda real por tags
        q = "" # Limpiamos q para que busque solo por tags si la API lo permite, o usamos q como filtro adicional
    elif mode == "custom":
        # Dialogo multiseleccion para combinar filtros
        opts = [
            "Alta Definición (HD)",           # 0
            "Larga Duración (+20 min)",       # 1
            "Corta Duración (-10 min)",       # 2
            "Subido Hoy (24h)",               # 3
            "Subido esta Semana",             # 4
            "Subido este Mes",                # 5
            "Ordenar por Recientes",          # 6
            "Solo Español (Añadir texto)"     # 7
        ]
        sel = xbmcgui.Dialog().multiselect("Combinar Filtros", opts)
        if not sel: 
            # Si cancela, buscamos normal sin filtros extra
            pass 
        else:
            if 0 in sel: ep["_hd"] = True
            
            # Conflictos de duración
            if 1 in sel: ep["longer_than"] = 20
            elif 2 in sel: ep["shorter_than"] = 10
            
            # Conflictos de fecha
            now = int(time.time())
            if 3 in sel: ep["created_after"] = now - 86400
            elif 4 in sel: ep["created_after"] = now - (86400 * 7)
            elif 5 in sel: ep["created_after"] = now - (86400 * 30)
            
            if 6 in sel: ep["sort"] = "recent"
            if 7 in sel: q = f"{q} español"

    # Save to History
    if q: connector.add_hist(q)

    # Save for repeat
    ui_utils.save_json('last_adv.json', {"q": f"adv:{q}", "ep": ep})
    
    # Execute
    if mode == "exact":
        connector.search_internet(f"adv:{q}", extra_params=ep, direct=True) # Direct passes exact
    else:
        connector.search_internet(f"adv:{q}", extra_params=ep)


def set_precision():
    opts = ["Nivel 1: BÁSICO (Solo Título)", "Nivel 2: ESTÁNDAR (Serie + Título - Recomendado)", "Nivel 3: AVANZADO (Serie + Temporada)"]
    idx = xbmcgui.Dialog().select("Contexto de Búsqueda", opts)
    if idx >= 0:
        d = ui_utils.load_json('settings.json')
        if isinstance(d, list): d = {}
        d['context_level'] = idx + 1
        ui_utils.save_json('settings.json', d)
        xbmcgui.Dialog().notification("AtresDaily", f"Nivel {idx+1} guardado")

def clear_ui_cache():
    xbmc.executebuiltin("Container.Refresh")
    xbmcgui.Dialog().notification("AtresDaily", "Interfaz actualizada", xbmcgui.NOTIFICATION_INFO)

def set_download_path():
    d = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if d:
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        cfg['download_path'] = d
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", "Ruta de descargas guardada")
        xbmc.executebuiltin("Container.Refresh")

def set_dm_safe_level():
    # Selector de 3 niveles para el modo anti-errores de Dailymotion
    options = ["Desactivado (Conexión Normal)", "Básico (Móvil + Cookies)", "Extremo (Todas las técnicas de Gujal00)"]
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    current = cfg.get('dm_safe_level', 0)
    
    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        cfg['dm_safe_level'] = sel
        # Mantener compatibilidad con la antigua variable booleana
        cfg['dm_safe_mode'] = sel > 0
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

def set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Normal)", 
        "Nivel 2: SAFE MODE (Gujal Style)", 
        "Nivel 3: MODO ESPADAILY (Procesado HLS)",
        "Nivel 4: YT-DLP (Requiere yt-dlp instalado)",
        "Nivel 5: ULTRA (Multi-hilo HLS+)"
    ]
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        cfg['dl_mode'] = idx # 0=Direct, 1=Safe, 2=EspaDaily, 3=yt-dlp, 4=Ultra
        
        # Mantener compatibilidad hacia atras
        cfg['dl_safe_mode'] = (idx == 1)
        
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _do_download_ultra(url, dest, title):
    """
    Modo ULTRA: Descarga HLS Multi-hilo.
    Usa concurrent.futures para maximizar el ancho de banda.
    """
    import concurrent.futures
    
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)
             
        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Analizando stream de alta velocidad...")
        
        # 1. Resolver Master Playlist
        session = requests.Session()
        session.headers.update(HEADERS)
        
        r = session.get(url, timeout=15)
        m3u8_content = r.text
        base_url = r.url.rsplit('/', 1)[0] + '/'
        
        # Seleccionar mejor calidad
        if "#EXT-X-STREAM-INF" in m3u8_content:
             dp.update(0, "Optimizando calidad...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1]
             if best_url:
                 if not best_url.startswith('http'): best_url = base_url + best_url
                 r = session.get(best_url, timeout=15)
                 m3u8_content = r.text
                 base_url = r.url.rsplit('/', 1)[0] + '/'

        # 2. Parsear Segmentos
        segments = []
        for l in m3u8_content.splitlines():
            l = l.strip()
            if not l or l.startswith("#"): continue
            seg_url = l
            if not seg_url.startswith('http'): seg_url = base_url + seg_url
            segments.append(seg_url)
        
        total_segs = len(segments)
        if total_segs == 0: raise Exception("Stream vacío")
        
        # 3. Descarga Paralela (4 Workers)
        # Usamos un dict para guardar los chunks en RAM temporalmente o en tempfiles?
        # Para archivos grandes, RAM es peligroso. Mejor tempfiles individuales.
        temp_dir = os.path.join(xbmcvfs.translatePath("special://temp/"), "atresdaily_ultra_dl")
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        else:
            # Limpiar anteriores
            for f in os.listdir(temp_dir): os.remove(os.path.join(temp_dir, f))
            
        completed = 0
        failed = False
        
        def download_segment(idx, seg_url):
            t_path = os.path.join(temp_dir, f"{idx:05d}.ts")
            try:
                # Reintentos internos
                for _ in range(3):
                    sr = session.get(seg_url, timeout=10)
                    if sr.status_code == 200:
                        with open(t_path, 'wb') as f: f.write(sr.content)
                        return True
                    time.sleep(0.5)
                return False
            except Exception as e:
                return False

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            # Encolar tareas
            futures = {executor.submit(download_segment, i, s): i for i, s in enumerate(segments)}
            
            for future in concurrent.futures.as_completed(futures):
                if dp.iscanceled(): 
                    executor.shutdown(wait=False)
                    break
                    
                if future.result():
                    completed += 1
                else:
                    failed = True # Un segmento falló irrecuperablemente
                
                pct = int(completed * 100 / total_segs)
                dp.update(pct, f"Bajando paquetes: {completed}/{total_segs}")
                
        if dp.iscanceled():
            dp.close()
            return

        # 4. Unir Archivos
        dp.update(100, "Ensamblando archivo final...")
        with open(dest, 'wb') as final_file:
            for i in range(total_segs):
                t_path = os.path.join(temp_dir, f"{i:05d}.ts")
                if os.path.exists(t_path):
                    with open(t_path, 'rb') as tf:
                        final_file.write(tf.read())
                    os.remove(t_path) # Limpiar
                
        dp.close()
        
        _log_download_complete(title, dest, "MP4 (ULTRA)")
        xbmcgui.Dialog().ok("AtresDaily", "¡Descarga ULTRA completada!")
        
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] Ultra Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error Ultra", f"Fallo en descarga Ultra:\n{str(e)}")

def _do_download_ytdlp(vid, dest, title):
    """
    Descarga usando yt-dlp (el método más robusto).
    Requiere que yt-dlp esté instalado en el sistema.
    """
    import subprocess
    import shutil
    
    # Buscar yt-dlp en el sistema
    ytdlp_path = shutil.which('yt-dlp')
    if not ytdlp_path:
        # Intentar rutas comunes en Windows/Linux
        common_paths = [
            'yt-dlp',
            'yt-dlp.exe',
            '/usr/local/bin/yt-dlp',
            '/usr/bin/yt-dlp',
            os.path.expanduser('~/.local/bin/yt-dlp'),
        ]
        for p in common_paths:
            if os.path.exists(p):
                ytdlp_path = p
                break
    
    if not ytdlp_path:
        xbmcgui.Dialog().ok("AtresDaily - yt-dlp", 
            "yt-dlp no está instalado en el sistema.\n\n"
            "Para usar este modo, instala yt-dlp:\n"
            "- Windows: winget install yt-dlp\n"
            "- Linux: pip install yt-dlp\n"
            "- Más info: github.com/yt-dlp/yt-dlp")
        return
    
    # URL de Dailymotion
    dm_url = f"https://www.dailymotion.com/video/{vid}"
    
    # Preparar nombre de archivo seguro
    safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
    if not safe_title: safe_title = vid
    
    # yt-dlp output template
    output_template = os.path.join(os.path.dirname(dest), f"{safe_title}.%(ext)s")
    
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando con yt-dlp", f"Iniciando descarga de:\n{title}")
    
    try:
        # Ejecutar yt-dlp
        cmd = [
            ytdlp_path,
            '-f', 'best[ext=mp4]/best',  # Preferir MP4
            '-o', output_template,
            '--no-playlist',
            '--no-warnings',
            dm_url
        ]
        
        xbmc.log(f"[AtresDaily] Ejecutando: {' '.join(cmd)}", xbmc.LOGINFO)
        
        # Ejecutar en subprocess
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )
        
        # Monitorear progreso
        while True:
            if dp.iscanceled():
                process.terminate()
                dp.close()
                xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada")
                return
                
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
                
            if line:
                # Parsear progreso de yt-dlp (formato: [download] XX.X% of ...)
                if '[download]' in line and '%' in line:
                    try:
                        pct = float(re.search(r'(\d+\.?\d*)%', line).group(1))
                        dp.update(int(pct), f"Descargando: {int(pct)}%")
                    except:
                        pass
            
            xbmc.sleep(100)
        
        dp.close()
        
        retcode = process.returncode
        if retcode == 0:
            # Buscar el archivo descargado
            base_dir = os.path.dirname(dest)
            for f in os.listdir(base_dir):
                if f.startswith(safe_title) and (f.endswith('.mp4') or f.endswith('.mkv') or f.endswith('.webm')):
                    final_path = os.path.join(base_dir, f)
                    _log_download_complete(title, final_path, "yt-dlp")
                    xbmcgui.Dialog().ok("AtresDaily", f"Descarga completada con yt-dlp:\n{f}")
                    return
            
            xbmcgui.Dialog().ok("AtresDaily", "yt-dlp terminó pero no se encontró el archivo descargado.")
        else:
            xbmcgui.Dialog().ok("AtresDaily Error", f"yt-dlp falló con código: {retcode}\n\nPrueba otro modo de descarga.")
            
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] yt-dlp Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error yt-dlp", f"Error ejecutando yt-dlp:\n{str(e)}")

def _do_download_espadaily(url, dest, title):
    # Lógica de descarga MODO ESPADAILY: Procesamiento real de HLS
    # Descarga segmentos secuenciales y los une en un solo archivo MP4/TS
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)
             
        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo EspaDaily)", "Analizando lista de reproducción...")
        
        # 1. Obtener lista M3U8 y resolver redirecciones
        r = requests.get(url, headers=HEADERS, timeout=15)
        m3u8_content = r.text
        base_url = r.url.rsplit('/', 1)[0] + '/'
        
        # Si es un master playlist, necesitamos elegir la mejor calidad primero
        if "#EXT-X-STREAM-INF" in m3u8_content:
             # Este caso suele estar resuelto antes en download_video, pero por si acaso
             dp.update(0, "Resolviendo stream final...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     # Simple heuristic: look for BANDWIDTH
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1]
             
             if best_url:
                 if not best_url.startswith('http'): best_url = base_url + best_url
                 r = requests.get(best_url, headers=HEADERS, timeout=15)
                 m3u8_content = r.text
                 base_url = r.url.rsplit('/', 1)[0] + '/'

        # 2. Extraer segmentos
        segments = []
        lines = m3u8_content.splitlines()
        aes_key = None
        
        for l in lines:
            l = l.strip()
            if not l: continue
            if l.startswith("#EXT-X-KEY"):
                # Dailymotion a veces usa encriptación simple. Si es así, esto se complica sin ffmpeg/crypto
                # Pero intentaremos seguir descargando el raw
                xbmc.log("[AtresDaily] Encriptación detectada en HLS. La descarga 'raw' podría no ser reproducible.", xbmc.LOGWARNING)
            if not l.startswith("#"):
                seg_url = l
                if not seg_url.startswith('http'): seg_url = base_url + seg_url
                segments.append(seg_url)
        
        total_segs = len(segments)
        if total_segs == 0:
            raise Exception("No se encontraron segmentos de video")
            
        dp.update(0, f"Descargando 0/{total_segs} segmentos")
        
        # 3. Descargar y unificar
        # Usamos un archivo temporal para ir pegando los trozos
        with open(dest, 'wb') as outfile:
            for i, seg in enumerate(segments):
                if dp.iscanceled(): break
                
                # Retry logic simple
                success = False
                for attempt in range(3):
                    try:
                        sr = requests.get(seg, headers=HEADERS, timeout=10)
                        if sr.status_code == 200:
                            outfile.write(sr.content)
                            success = True
                            break
                    except: time.sleep(1)
                
                if not success:
                    # Si falla un segmento crítico, ¿abortamos o seguimos? Seguimos para intentar salvar algo.
                    xbmc.log(f"[AtresDaily] Fallo al descargar segmento {i}", xbmc.LOGWARNING)
                
                percent = int((i + 1) * 100 / total_segs)
                dp.update(percent, f"Procesando segmento {i+1}/{total_segs}")
        
        dp.close()
        
        if not dp.iscanceled():
            _log_download_complete(title, dest, "MP4 (EspaDaily)")
            xbmcgui.Dialog().ok("AtresDaily", "Descarga finalizada correctamente (Modo EspaDaily)")
        else:
            if os.path.exists(dest): os.remove(dest)
            
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] EspaDaily Download Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Error en descarga EspaDaily:\n{str(e)}")

def clear_full_cache():
    # Limpiar caché JSON de catalogo y otros temporales
    if xbmcgui.Dialog().yesno("Limpiar Caché", "¿Borrar todos los datos de caché del catálogo?\nEsto forzará a recargar la información de Atresplayer."):
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        count = 0
        try:
             # Borrar archivos cat_cache_*.json y otros temp
             files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
             for f in files:
                 os.remove(os.path.join(profile, f))
                 count += 1
             
             xbmcgui.Dialog().notification("AtresDaily", f"Caché borrada: {count} archivos", xbmcgui.NOTIFICATION_INFO)
             xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
             xbmcgui.Dialog().notification("AtresDaily", f"Error borrando caché: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

def export_cache():
    # Export all cat_cache files
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return
    
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
    
    if not files:
        xbmcgui.Dialog().notification("AtresDaily", "No hay caché para exportar")
        return
        
    import shutil
    count = 0
    try:
        for f in files:
            shutil.copy2(os.path.join(profile, f), os.path.join(d, f))
            count += 1
        xbmcgui.Dialog().notification("AtresDaily", f"{count} archivos exportados")
    except:
        xbmcgui.Dialog().ok("Error", "Fallo al exportar caché")

def show_info():
    t = (
        "[B]Información importante:[/B]\n• Este addon es completamente GRATUITO\n"
        "• NO aloja ningún contenido\n"
        "• Facilita el acceso a contenidos y emisiones que las plataformas oficiales ofrecen de forma pública y gratuita.\n"
        "• Además del catálogo directo, permite buscar vídeos relacionados en plataformas legales de terceros (como Dailymotion).\n"
        "• Se recomienda descargar el addon siempre desde nuestras fuentes oficiales para evitar la presencia de virus o funciones maliciosas.\n\n"
        "[B]¿Cómo funciona?[/B]\nEl addon unifica el acceso a servicios oficiales gratuitos con un motor de búsqueda inteligente para localizar contenido que ya está disponible libremente en internet.\n\n"
        "NO está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres el "
        "capítulo completo, solo un trailer, un resumen, o contenido "
        "similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible de forma libre en internet.\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "Los desarrolladores de este addon NO se hacen responsables del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de búsquedas externas.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    ver = xbmcaddon.Addon().getAddonInfo("version")
    xbmcgui.Dialog().textviewer(f"AtresDaily - Información v{ver}", t)

def show_legal_txt():
    f_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'AVISO_LEGAL.txt')
    content = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f: content = f.read()
        except: pass
    xbmcgui.Dialog().textviewer("AVISO LEGAL - AtresDaily", content)

def revoke_legal():
    if xbmcgui.Dialog().yesno("Revocar Términos", "¿Estás seguro de que deseas REVOCAR tu aceptación de los términos legales?\n\nEl addon dejará de funcionar hasta que vuelvas a aceptarlos explícitamente."):
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        cfg['legal_accepted_v2'] = False
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().ok("AtresDaily", "Términos revocados. El addon se reiniciará.")
        xbmc.executebuiltin("Container.Refresh")

def show_web_info():
    t = (
        "[B]Visita este GitHub para ver más proyectos como este.[/B]\n"
        "https://github.com/fullstackcurso"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

# --- ACTUAL CATALOG SNAPSHOTS ENGINE ---
def snapshots_menu():
    # msg = "Las instantáneas guardan una copia estática del catálogo actual para que puedas acceder a los contenidos incluso si las listas online fallan."
    # ui_utils.add_item(action="snapshot_help", title=f"[COLOR cyan][B]RECOMENDACIÓN:[/B][/COLOR] Crear periódicamente", thumbnail="DefaultIconInfo.png", folder=False, plot=msg)
    
    ui_utils.add_item(action="create_catalog_snapshot", title="[COLOR green][B]+ CREAR NUEVA FOTO DEL CATÁLOGO[/B][/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="delete_snapshot_menu", title="[COLOR red]BORRAR INSTANTÁNEA...[/COLOR]", thumbnail="DefaultIconError.png", folder=True)
    
    # Contexto de busqueda independiente para instantaneas
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    lvl = cfg.get('snapshot_context_level', 2)
    labels = ["", "BÁSICO (Título)", "ESTÁNDAR (Recomendado)", "AVANZADO"]
    cur_label = labels[lvl] if lvl < len(labels) else labels[2]
    
    c_plot = (
        "CONTEXTO DE BÚSQUEDA: Define cómo se busca el vídeo al pulsar en la foto.\n\n"
        "• BÁSICO: Solo el título (Ej: 'Capítulo 1')\n"
        "• ESTÁNDAR: Añade la categoría (Ej: 'Series Capítulo 1')\n"
        "• AVANZADO: Añade plataforma (Ej: 'Atresplayer Series Capítulo 1')\n\n"
        "[I]Pulsa para cambiar de nivel.[/I]"
    )
    ui_utils.add_item(action="toggle_snapshot_precision", title=f"Contexto en Instantánea: [COLOR yellow]{cur_label}[/COLOR]", thumbnail="DefaultAddonService.png", folder=False, plot=c_plot)
    
    # Listar instantaneas JSON existentes
    sdir = _get_snapshot_dir()
    if os.path.exists(sdir):
        files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
        for f in files:
            ts = f.replace("snap_", "").replace(".json", "")
            # Formateo visual de fecha
            try: d_str = f"{ts[6:8]}/{ts[4:6]}/{ts[0:4]} {ts[9:11]}:{ts[11:13]}"
            except: d_str = ts
            ui_utils.add_item(action="view_snapshot", title=f"Instantánea: {d_str}", url=f, extra="root", thumbnail="DefaultFolder.png", folder=True)
            
    ui_utils.close_item_list()

def snapshot_help():
    t = (
        "[B]¿Qué es el Contexto de Búsqueda?[/B]\n\n"
        "Como una instantánea es solo una 'foto' (título y foto), cuando pulsas en una serie, "
        "el addon tiene que buscarla en Dailymotion.\n\n"
        "El [B]Contexto[/B] le dice a esa búsqueda cuánta información extra debe usar:\n\n"
        "- [B]BÁSICO:[/B] Solo busca el nombre. Si la serie se llama 'Eva', puede que encuentre mil cosas.\n"
        "- [B]ESTÁNDAR:[/B] Busca 'Series Eva'. Mucho más preciso.\n"
        "- [B]AVANZADO:[/B] Busca 'Atresplayer Series Eva'. Máxima precisión, pero si el título en Dailymotion "
        "no incluye 'Atresplayer', podría no encontrar nada.\n\n"
        "Se recomienda el nivel [B]ESTÁNDAR[/B]."
    )
    xbmcgui.Dialog().textviewer("Ayuda de Instantáneas", t)

def toggle_snapshot_precision():
    d = ui_utils.load_json('settings.json')
    if isinstance(d, list): d = {}
    cur = d.get('snapshot_context_level', 2)
    cur += 1
    if cur > 3: cur = 1
    d['snapshot_context_level'] = cur
    ui_utils.save_json('settings.json', d)
    xbmc.executebuiltin("Container.Refresh")

def _get_snapshot_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'snapshots_json')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_catalog_snapshot():
    if not xbmcgui.Dialog().yesno("AtresDaily", "¿Crear una foto completa del catálogo actual?\nEsto guardará todas las series y programas para acceso offline."):
        return
        
    catalog = connector._fetch_all_catalog()
    if not catalog: return
    
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"snap_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)
    
    try:
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(catalog, f)
        xbmcgui.Dialog().notification("AtresDaily", "Foto del catálogo guardada")
        xbmc.executebuiltin("Container.Refresh")
    except:
        xbmcgui.Dialog().ok("Error", "No se pudo guardar la instantánea.")

def view_snapshot(fname, path="root"):
    fpath = os.path.join(_get_snapshot_dir(), fname)
    if not os.path.exists(fpath): return
    
    with open(fpath, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    if path == "root":
        for cat_name in data.keys():
            ui_utils.add_item(action="view_snapshot", title=cat_name, url=fname, extra=cat_name, folder=True)
    else:
        items = data.get(path, [])
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, list): cfg = {}
        lvl = cfg.get('snapshot_context_level', 2)
        
        for i in items:
            t = i.get("t"); h = i.get("u"); th = i.get("th"); pl = i.get("p")
            # En modo instantanea, la busqueda debe ser inteligente
            q = t
            if lvl == 2: q = f"{path} {t}"
            elif lvl == 3: q = f"Atresplayer {path} {t}"
            
            # Los items de instantaneas siempre van a busqueda externa (catalog_search)
            ui_utils.add_item(action="catalog_search", title=t, url=q, thumbnail=th, plot=pl, folder=True)
            
    ui_utils.close_item_list()

def delete_snapshot_menu():
    sdir = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_snap", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f, thumbnail="DefaultIconError.png", folder=False)
    ui_utils.close_item_list()

def delete_single_snap(fname):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar instantánea {fname}?"):
        os.remove(os.path.join(_get_snapshot_dir(), fname))
        xbmc.executebuiltin("Container.Refresh")

# --- FILE BACKUP SYSTEM (ZIP) ---
def _get_backup_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'backups_zip')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_backup(include_cache=False):
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Creando backup ZIP...")
    try:
        ts = time.strftime("%Y%m%d_%H%M%S")
        suffix = "_FULL" if include_cache else ""
        target = os.path.join(_get_backup_dir(), f"Backup_{ts}{suffix}.zip")
        files = ['settings.json', 'history.json', 'search_history.json', 'last_adv.json', 'favorites.json', 'exploration_history.json', 'custom_categories.json', 'loader_config.json']
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        import zipfile
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in files:
                fp = os.path.join(profile, f)
                if os.path.exists(fp): zf.write(fp, f)
            # Add cache files if requested
            if include_cache:
                cache_files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
                for cf in cache_files:
                    cfp = os.path.join(profile, cf)
                    if os.path.exists(cfp): zf.write(cfp, cf)
        xbmcgui.Dialog().notification("AtresDaily", "Copia ZIP creada")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e: xbmcgui.Dialog().ok("Error", str(e))
    finally: dp.close()

def _list_backups():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="restore_backup", title=f"Restaurar: {f}", url=f, folder=False)
    ui_utils.close_item_list()

def restore_backup(fname):
    """Restaurar backup con opciones granulares."""
    source = os.path.join(_get_backup_dir(), fname)
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    import zipfile
    
    # Mapeo de archivos a nombres amigables (sin revelar información sensible)
    file_labels = {
        'settings.json': 'Configuración General',
        'history.json': 'Historial de Búsquedas',
        'search_history.json': 'Historial de Búsquedas (v2)',
        'last_adv.json': 'Última Búsqueda Avanzada',
        'favorites.json': 'Favoritos',
        'exploration_history.json': 'Historial de Navegación',
        'custom_categories.json': 'Categorías Personalizadas',
        'loader_config.json': 'Otros (Avanzado)',
    }
    
    # Archivos que permiten fusión (listas JSON)
    mergeable_files = ['favorites.json', 'history.json', 'search_history.json', 'exploration_history.json']
    
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available_files = zf.namelist()
        
        # Filtrar solo archivos conocidos
        known_files = [f for f in available_files if f in file_labels]
        
        if not known_files:
            xbmcgui.Dialog().ok("AtresDaily", "Este backup no contiene datos reconocidos.")
            return
        
        # Crear lista de opciones
        options = [file_labels.get(f, f) for f in known_files]
        
        # Selección múltiple
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        
        if selected is None or len(selected) == 0:
            return
        
        files_to_restore = [known_files[i] for i in selected]
        
        with zipfile.ZipFile(source, 'r') as zf:
            for fname_zip in files_to_restore:
                dest_path = os.path.join(profile, fname_zip)
                
                # Si el archivo es fusionable y ya existe, preguntar
                if fname_zip in mergeable_files and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(
                        f"{file_labels[fname_zip]}", 
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"]
                    )
                    
                    if choice == 2 or choice == -1:  # Omitir
                        continue
                    elif choice == 1:  # Fusionar
                        try:
                            # Leer actual
                            with open(dest_path, 'r', encoding='utf-8') as f:
                                current_data = json.load(f)
                            # Leer del backup
                            with zf.open(fname_zip) as zfile:
                                backup_data = json.load(zfile)
                            # Fusionar (si son listas)
                            if isinstance(current_data, list) and isinstance(backup_data, list):
                                merged = current_data + [x for x in backup_data if x not in current_data]
                                with open(dest_path, 'w', encoding='utf-8') as f:
                                    json.dump(merged, f, ensure_ascii=False)
                                continue
                            elif isinstance(current_data, dict) and isinstance(backup_data, dict):
                                current_data.update(backup_data)
                                with open(dest_path, 'w', encoding='utf-8') as f:
                                    json.dump(current_data, f, ensure_ascii=False)
                                continue
                        except:
                            pass  # Si falla, caer en extracción normal
                
                # Extracción normal (sustituir)
                zf.extract(fname_zip, profile)
        
        xbmcgui.Dialog().notification("AtresDaily", "Restauración completada")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo en restauración: {e}")

def _del_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_backup", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f, folder=False)
    ui_utils.close_item_list()

def delete_single_backup(fname):
    os.remove(os.path.join(_get_backup_dir(), fname))
    xbmc.executebuiltin("Container.Refresh")

def _export_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    ui_utils.add_item(action="", title="[I]Selecciona copia para exportar:[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    for f in files:
        ui_utils.add_item(action="export_single_backup", title=f"Exportar: {f}", url=f, folder=False)
    ui_utils.close_item_list()

def export_single_backup(fname):
    source = os.path.join(_get_backup_dir(), fname)
    # Type 3: ShowAndGetWriteableDirectory
    dest_folder = xbmcgui.Dialog().browse(3, f'Guardar {fname} en...', 'files')
    if dest_folder:
        try:
            dest_file = os.path.join(dest_folder, fname)
            shutil.copy2(source, dest_file)
            xbmcgui.Dialog().notification("AtresDaily", f"Exportado a: {dest_folder}")
        except Exception as e:
            xbmcgui.Dialog().ok("Error al Exportar", str(e))


def input_search():
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    
    adv_active = cfg.get('advanced_search_active', True)
    if str(adv_active).lower() == 'true': adv_active = True
    
    if adv_active:
        _advanced_search_menu()
        return

    kb = xbmc.Keyboard('', 'AtresDaily Search')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        t = kb.getText()
        connector.add_hist(t)
        connector.search_internet(t)

def view_history():
    ui_utils.add_item(action="del_history", title="[B][COLOR red]Borrar Historial[/COLOR][/B]", thumbnail="DefaultIconError.png", folder=False)
    h = ui_utils.load_json('history.json')
    for q in h:
        # Añadir opción de guardar búsqueda en favoritos
        cm = [("Añadir a Favoritos de AtresDaily", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=search&url={urllib.parse.quote(q)}&title={urllib.parse.quote(q)}&f_thumb={urllib.parse.quote(ICON_MAIN)})")]
        cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search&q={urllib.parse.quote(q)})"))
        ui_utils.add_item(action="search", title=q, url=q, thumbnail=ICON_MAIN, folder=True, direct="true", context=cm)
    ui_utils.close_item_list()

def del_history():
    ui_utils.save_json('history.json', [])
    xbmc.executebuiltin("Container.Refresh")

# --- FAVORITES LOGIC ---
def view_favorites():
    # Reemplazado por sistema compatible con Category Manager (Estilo EspaDaily)
    favs = core_settings.get_favorites()
    
    # --- ADD Custom Categories LINK ---
    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': 'DefaultAddonService.png'})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=cat_menu", listitem=li_c, isFolder=True)

    if not favs:
        if not cats:
             ui_utils.add_item(action="", title="No tienes favoritos guardados", thumbnail="DefaultIconInfo.png", folder=False)
    else:
        for f in favs:
            t = f.get('title')
            # support both old and new format just in case
            u = f.get('url')
            if not u: continue
            
            icon = f.get('icon', ICON_MAIN)
            action = f.get('action', 'search')
            params = f.get('params', {})
            
            # Context Menu
            cm = []
            
            # Management
            cm.append(("Renombrar...", f"RunPlugin({sys.argv[0]}?action=fav_rename&fav_url={urllib.parse.quote(u)}&old_title={urllib.parse.quote(t)})"))
            cm.append(("Mover arriba", f"RunPlugin({sys.argv[0]}?action=fav_move_up&fav_url={urllib.parse.quote(u)})"))
            cm.append(("Mover abajo", f"RunPlugin({sys.argv[0]}?action=fav_move_down&fav_url={urllib.parse.quote(u)})"))
            
            # Categories Support
            cm.append(("Mover a Categoría...", f"RunPlugin({sys.argv[0]}?action=cat_move_from_favs&fav_url={urllib.parse.quote(u)}&q={urllib.parse.quote(t)})"))
            
            # Buscar en webs de torrent
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search&q={urllib.parse.quote(t)})"))
            
            # Remove
            cm.append(("Eliminar de Favoritos", f"RunPlugin({sys.argv[0]}?action=del_fav&url={urllib.parse.quote(u)})"))
            
            # Reconstruct URL
            # Note: AtresDaily add_fav stores params in 'extra' sometimes, or straightforward args
            # New add_fav stores them in 'params' dict.
            # We need to pass them to add_item
            
            # Simplified approach: reconstruct the call
            # This requires knowing exactly what arguments 'action' expects. 
            # Fortunately add_item just builds a URL.
            
            # For 'play_media' we usually have url, extra.
            # In new format: params={'extra': ...}
            extra = params.get('extra') or ''
            
            # FIX: Si es una búsqueda, forzar direct=true para saltar menú avanzado
            kwargs = {}
            if action == "search":
                kwargs["direct"] = "true"
            
            ui_utils.add_item(action=action, title=t, url=u, thumbnail=icon, extra=extra, folder=True, context=cm, **kwargs)
        
    ui_utils.close_item_list()

def export_favs():
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return
    
    import shutil
    try:
        shutil.copy2(ui_utils.get_path('favorites.json'), os.path.join(d, 'favorites_backup.json'))
        xbmcgui.Dialog().notification("AtresDaily", "Favoritos exportados con éxito")
    except:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar la lista")

def import_favs():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo favorites.json', 'files', '.json')
    if not f: return
    
    if xbmcgui.Dialog().yesno("AtresDaily", "¿Deseas importar esta lista?\n(Se borrará la actual)"):
        try:
            with open(f, 'r', encoding='utf-8') as src:
                data = json.load(src)
                if isinstance(data, list):
                    ui_utils.save_json('favorites.json', data)
                    xbmcgui.Dialog().notification("AtresDaily", "Favoritos importados")
                    xbmc.executebuiltin("Container.Refresh")
                else: raise Exception()
        except:
            xbmcgui.Dialog().ok("Error", "Archivo no válido o corrupto")

def add_fav(title, action, url, thumbnail, extra):
    # Usar nuevo sistema core_settings
    params = {"extra": extra}
    if core_settings.add_favorite(title, url, thumbnail, "atresdaily", action, params):
        xbmcgui.Dialog().notification("AtresDaily", "Añadido a favoritos")
    else:
        xbmcgui.Dialog().notification("AtresDaily", "Ya está en favoritos")

def del_fav(url):
    favs = ui_utils.load_json('favorites.json')
    new_favs = [i for i in favs if i.get('url') != url]
    if len(new_favs) < len(favs):
        ui_utils.save_json('favorites.json', new_favs)
        xbmcgui.Dialog().notification("AtresDaily", "Eliminado de favoritos")
        xbmc.executebuiltin("Container.Refresh")

# --- DOWNLOADS SYSTEM ---
def view_downloads():
    dls = ui_utils.load_json('downloads.json')
    if not isinstance(dls, list): dls = []

    if not dls:
        ui_utils.add_item(action="", title="No hay historial de descargas", thumbnail="DefaultIconInfo.png", folder=False, plot="Cuando descargues algo, aparecerá aquí.")
    else:
        for d in dls:
            path = d.get('path', '')
            title = d.get('title', 'Desconocido')
            date = d.get('date', '')
            
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {title}"
                is_valid = False
            else:
                label = f"{title} ({date})"
                is_valid = True
            
            # Context Menu
            cm = [("Quitar del historial", f"RunPlugin({sys.argv[0]}?action=del_dl_history&url={urllib.parse.quote(path)})")]
            if is_valid:
                cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({sys.argv[0]}?action=del_file&url={urllib.parse.quote(path)})"))
                action = "play_local"
            else:
                action = "" # No playable if missing
            
            ui_utils.add_item(action=action, title=label, url=path, thumbnail="DefaultVideo.png", isPlayable=is_valid, folder=False, context=cm, plot=path)

    ui_utils.close_item_list()

# --- DOWNLOADS MOVED TO connector.py ---


def del_dl_history(path):
    dls = ui_utils.load_json('downloads.json')
    new_dls = [d for d in dls if d.get('path') != path]
    ui_utils.save_json('downloads.json', new_dls)
    xbmc.executebuiltin("Container.Refresh")

def del_file(path):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar definitivamente?\n{os.path.basename(path)}"):
        try: 
            if os.path.exists(path): os.remove(path)
            del_dl_history(path) # Also remove from history
        except: pass

def play_local(path):
    li = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def _search_elementum(query):
    """Busca en Elementum con verificación de instalación."""
    if not query: return
    
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcgui.Dialog().ok("AtresDaily", 
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub.")
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = f"plugin://plugin.video.elementum/search?q={urllib.parse.quote(query)}"
    
    # FIX: Usamos Container.Update en lugar de ActivateWindow para mantener el historial de navegación.
    # Esto permite que al volver atrás se regrese a la lista de AtresDaily en vez del menú principal.
    xbmc.executebuiltin(f"Container.Update({elementum_url})")

def _search_elementum_prompt(query):
    # Abrir teclado siempre para confirmar o modificar
    kb = xbmc.Keyboard(query, 'Buscar en Torrents (Elementum)')
    kb.doModal()
    if kb.isConfirmed():
        nq = kb.getText()
        if nq:
             _search_elementum(nq)

def _search_palantir_prompt(query):
    # Abrir teclado para modificar busqueda de Palantir
    kb = xbmc.Keyboard(query, 'Buscar en Palantir 3')
    kb.doModal()
    if kb.isConfirmed():
        nq = kb.getText()
        if nq:
             _search_palantir(nq)

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3 (Créditos: EspaDaily)"""
    import base64
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = int(length / 4)
    value = re.sub(b'=', b'', value)
    # Palantir reversible encoding: reverse 1/4 and 3/4
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _search_palantir(query):
    if not query: return
    
    # Verificar si Palantir 3 esta instalado
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        xbmcgui.Dialog().ok("AtresDaily", "El addon Palantir 3 no parece estar instalado.\n\nEsta función requiere Palantir 3 para funcionar.")
        return

    # Preparar el objeto ITEM que espera Palantir (Créditos: EspaDaily)
    # Palantir 3 espera un objeto P3Item serializado
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    # IMPORTANTE: Palantir 3 usa su propia codificación reversible
    encoded_item = _p3_b64encode(str(item_dict))
    
    # Palantir 3 usa la ventana HOME (10000) para sus propiedades de estado
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar la búsqueda
    plugin_url = f"plugin://plugin.video.palantir3/?{encoded_item}"
    
    xbmc.log(f"[AtresDaily] Enviando búsqueda a Palantir 3: {query}", xbmc.LOGINFO)
    xbmc.log(f"[AtresDaily] URL generada: {plugin_url}", xbmc.LOGINFO)
    
    # Usamos Container.Update para que al volver atrás regrese a nuestro addon
    xbmc.executebuiltin(f"Container.Update({plugin_url})")

# =====================================================================
# OPCIÓN OCULTA - NO PARA USUARIO FINAL
# Fix de compatibilidad con skin Estuary Palantir (Créditos: EspaDaily)
# Esta función parchea la skin para evitar pantalla negra en resultados de Palantir
# =====================================================================
def _toggle_estuary_palantir_fix():
    """
    Instala o desinstala el parche de compatibilidad para skin.estuary.palantir.
    Solo afecta a usuarios que tengan esa skin instalada.
    """
    import base64
    
    # Verificar si el skin actual es el problemático
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        xbmcgui.Dialog().ok("AtresDaily", 
            "Este fix solo es necesario si usas la skin 'Estuary Palantir'.\n\n"
            f"Tu skin actual es: {skin_id}")
        return

    # Obtener ruta del archivo Includes.xml del skin
    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')

    if not os.path.exists(includes_xml):
        xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo Includes.xml de la skin.")
        return

    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()

        patch_marker = '<!-- ATRESDAILY_PATCH_VIDEOS -->'
        espadaily_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'
        
        # Detectar si ya está parcheado
        is_patched = patch_marker in content or espadaily_marker in content
        
        if is_patched:
            # DESINSTALAR - Quitar el parche
            if xbmcgui.Dialog().yesno("AtresDaily - Desinstalar Fix", 
                "El fix de compatibilidad está instalado.\n\n¿Quieres desinstalarlo?"):
                
                # Quitar marcador
                content = content.replace('\n\t' + patch_marker, '')
                content = content.replace(patch_marker, '')
                
                # Quitar las líneas de parche añadidas
                # Buscamos y eliminamos las líneas que añadimos
                content = re.sub(r'\n\t\t\t\[Container\.Content\(videos\) \| Container\.Content\(\)\] \|', '', content)
                
                with open(includes_xml, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                xbmcgui.Dialog().notification('AtresDaily', 'Fix desinstalado. Recargando skin...', xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin('ReloadSkin()')
        else:
            # INSTALAR - Aplicar el parche
            if xbmcgui.Dialog().yesno("AtresDaily - Instalar Fix", 
                "¿Quieres instalar el fix de compatibilidad para Estuary Palantir?\n\n"
                "Esto corrige la pantalla negra al mostrar resultados de Palantir."):
                
                modified = False
                vistas_palantir = ['Vista50', 'Vista54', 'Vista55', 'Vista500', 'Vista504', 'Vista505', 'Vista506', 'Vista507']
                
                for vista in vistas_palantir:
                    pattern = r'(<expression name="' + vista + r'">\s*\[\s*\$EXP\[IsPalantirVistas\]\s*\+)'
                    if re.search(pattern, content):
                        replacement = r'\1\n\t\t\t[Container.Content(videos) | Container.Content()] |'
                        new_content = re.sub(pattern, replacement, content)
                        if new_content != content:
                            content = new_content
                            modified = True

                if modified:
                    content = content.replace('<includes>', '<includes>\n\t' + patch_marker)
                    with open(includes_xml, 'w', encoding='utf-8') as f:
                        f.write(content)
                    xbmcgui.Dialog().notification('AtresDaily', 'Fix instalado. Recargando skin...', xbmcgui.NOTIFICATION_INFO, 3000)
                    xbmc.executebuiltin('ReloadSkin()')
                else:
                    xbmcgui.Dialog().ok("AtresDaily", "No se encontraron las expresiones a parchear.\nPuede que tu versión de Estuary Palantir sea diferente.")

    except Exception as e:
        xbmc.log(f"[AtresDaily] Error en toggle_estuary_palantir_fix: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error: {str(e)}")

# --- DISPATCH ---
if not check_validity():
    xbmcgui.Dialog().ok("AtresDaily", "Addon desactivado o versión obsoleta.")
else:
    p = get_params()
    a = p.get("action")
    u = p.get("url")
    e = p.get("extra")
    d = p.get("direct")

    # --- CONNECTOR GUARD ---
    # Protege contra llamadas a funciones del conector si este no se ha cargado (ej: términos no aceptados)
    if connector is None and a in [
        "list_cat", "list_details", "download_video", "play_media",
        "live_tv", "play_live_channel", "search", "play_dm",
        "input_search", "catalog_search", "view_playlist",
        "list_user_playlists", "search_user_playlists", "execute_adv_search",
        "catalog_menu"
    ]:
         # Si tratamos de usar una función del conector sin tenerlo, mostramos aviso y vamos al inicio
         # Esto forzará que salte el check_legal_compliance() en menu_root()
         xbmcgui.Dialog().notification("AtresDaily", "Función restringida", xbmcgui.NOTIFICATION_WARNING)
         menu_root()
         # Aseguramos que no sigue ejecutando
         a = None 

    if not a: menu_root()
    elif a == "list_cat": connector.list_cat(u, int(e) if e else 0)
    elif a == "list_details": connector.list_details(u, e)
    elif a == "catalog_menu": catalog_menu()
    elif a == "view_favorites": view_favorites()
    elif a == "add_fav": add_fav(title=p.get("title", "Favorito"), action=p.get("f_action", "search"), url=u, thumbnail=p.get("f_thumb", ICON_MAIN), extra=e)
    elif a == "del_fav": 
        if core_settings.remove_favorite(u): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
        kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
        kb.doModal()
        if kb.isConfirmed():
            new_t = kb.getText()
            if new_t:
                core_settings.rename_favorite(p.get("fav_url"), new_t)
                xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"): xbmc.executebuiltin("Container.Refresh")
    
    # --- CATEGORY MANAGER ROUTING ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         if category_manager.add_item_dialog(p.get("q")):
             import time
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if removed:
                 time.sleep(0.2) 
                 xbmc.executebuiltin("Container.Refresh")
                 
    # --- EXPLORATION HISTORY ROUTING ---
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))
                 
    elif a == "view_downloads": view_downloads()
    elif a == "download_video": connector.download_video(vid=u, title=p.get('title', 'Video'))
    elif a == "del_dl_history": del_dl_history(u)
    elif a == "del_file": del_file(u)
    elif a == "play_local": play_local(u)
    elif a == "export_favs": export_favs()
    elif a == "import_favs": import_favs()
    elif a == "play_media": connector.play_media(u, e)
    elif a == "live_tv": connector.list_live()
    elif a == "play_live_channel": connector.play_live_channel(u)
    elif a == "search": connector.search_internet(u, direct=(p.get('direct') == 'true'))
    elif a == "play_dm": connector.play_dm(u)
    elif a == "input_search": input_search()
    elif a == "view_history": view_history()
    elif a == "del_history": del_history()
    elif a == "settings_menu": settings_menu()
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "set_cache_config": set_cache_config()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "execute_adv_search": _execute_adv_search(u)
    elif a == "catalog_search": connector.catalog_search(u)
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_catalog_snapshot": create_catalog_snapshot()
    elif a == "view_snapshot": view_snapshot(u, e)
    elif a == "delete_snapshot_menu": delete_snapshot_menu()
    elif a == "delete_single_snap": delete_single_snap(u)
    elif a == "toggle_snapshot_precision": toggle_snapshot_precision()
    elif a == "backups_menu": backups_menu()
    elif a == "create_backup": create_backup()
    elif a == "create_backup_full": create_backup(include_cache=True)
    elif a == "list_backups": _list_backups()
    elif a == "restore_backup": restore_backup(u)
    elif a == "del_backups_menu": _del_backups_menu()
    elif a == "export_backups_menu": _export_backups_menu()
    elif a == "export_single_backup": export_single_backup(u)
    elif a == "delete_single_backup": delete_single_backup(u)
    elif a == "set_download_path": set_download_path()
    elif a == "set_dm_safe_level": set_dm_safe_level()
    elif a == "set_dl_mode": set_dl_mode()
    elif a == "list_user_playlists": connector.list_user_playlists(p.get("user"))
    elif a == "view_playlist": connector.view_playlist(p.get("id"))
    elif a == "search_user_playlists": connector.search_user_playlists()
    elif a == "show_legal_txt": show_legal_txt()
    elif a == "revoke_legal": revoke_legal()
    elif a == "set_precision": set_precision()
    elif a == "clear_ui_cache": clear_ui_cache()
    elif a == "export_cache": export_cache()
    elif a == "clear_full_cache": clear_full_cache()
    elif a == "show_info": show_info()
    elif a == "show_web_info": show_web_info()
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "elementum_search_prompt": _search_elementum_prompt(p.get("q"))
    elif a == "palantir_search_prompt": _search_palantir_prompt(p.get("q"))
    elif a == "toggle_estuary_palantir_fix": _toggle_estuary_palantir_fix()
    elif a == "view_kodi_log": view_kodi_log()
    else: menu_root()
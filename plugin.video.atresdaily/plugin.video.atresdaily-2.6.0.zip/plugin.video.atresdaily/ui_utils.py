# -*- coding: utf-8 -*-
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import urllib.parse

# --- CORE CONFIG ---
ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # "Referer": "https://www.atresplayer.com/" # Referer dinamico suele ser mejor
    "Origin": "https://www.atresplayer.com"
}

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url="", thumbnail="", extra="", folder=True, isPlayable=False, plot="", fanart="", context=None, **kwargs):
    li = xbmcgui.ListItem(title)
    
    # Configurar Arte (Icono, Thumbnail y Fanart)
    art = {}
    if thumbnail: 
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
        
    # Solo poner fanart si se pide explícitamente
    if fanart:
        art['fanart'] = fanart
        
    li.setArt(art)
    
    # Info basica
    info = {"title": title}
    if plot: info["plot"] = plot
    li.setInfo("video", info)
    
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
        
    # Inyectar "Abrir en navegador" para items de Dailymotion
    if action == "play_dm" and url:
        _browser_item = ("[COLOR lime]Abrir en navegador[/COLOR]",
                         f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(url)})")
        if context:
            context = [_browser_item] + list(context)
        else:
            context = [_browser_item]

    if context:
        li.addContextMenuItems(context)
        
    u = f"{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}"
    for key, value in kwargs.items():
        u += f"&{key}={urllib.parse.quote(str(value))}"
        
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

# --- HELPERS ---
def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    """Carga un archivo JSON. Si default es None, devuelve [] para listas o {} para settings."""
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f: return json.load(f)
    except Exception:
        if default is not None: return default
        # Auto-detect: settings files should return dict, others list
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    try:
        with open(get_path(name), 'w', encoding='utf-8') as f: json.dump(data, f)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error guardando {name}: {e}", xbmc.LOGERROR)

def fix_img(url):
    if not url: return ICON_MAIN
    if url.startswith("//"): url = "https:" + url
    elif url.startswith("/"): url = "https://www.atresplayer.com" + url
    if url.endswith("/"): url += "1280x720.jpg"
    return url

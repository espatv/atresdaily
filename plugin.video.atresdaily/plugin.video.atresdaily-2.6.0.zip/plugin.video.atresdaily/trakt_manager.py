# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings
import requests

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

# =============================================================================
# UTILIDADES
# =============================================================================

def _get_thumb_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, f"trakt_thumbs_{list_id}.json")

def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

def _get_top_movies_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, "top_movies_thumbs.json")

def _load_top_movies_cache():
    path = _get_top_movies_cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

# =============================================================================
# DIÁLOGO DE BÚSQUEDA MULTI-PLATAFORMA
# =============================================================================

def _check_estuary_palantir_fix():
    """
    Comprueba si el skin Estuary Palantir está activo y si necesita el fix.
    Retorna True si todo OK (no necesita fix o ya está parcheado), False si necesita fix.
    """
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        return True  # No usa ese skin, no necesita fix
    
    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')
    
    if not os.path.exists(includes_xml):
        return True  # No encontramos el archivo, no podemos verificar
    
    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        
        patch_marker = '<!-- ATRESDAILY_PATCH_VIDEOS -->'
        espadaily_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'
        
        if patch_marker in content or espadaily_marker in content:
            return True  # Ya está parcheado
        
        return False  # Necesita fix
    except Exception:
        return True

def search_dialog(query):
    """
    Muestra un diálogo para elegir dónde buscar: Dailymotion, Elementum,
    Palantir o el addon externo de Dailymotion (Gujal).
    Todas las opciones muestran un teclado con el texto pre-rellenado
    para que el usuario pueda editarlo antes de buscar.
    """
    if not query: return

    options = [
        "Buscar en Dailymotion (interno)",
        "Buscar en webs de torrent (Elementum)"
    ]
    actions = ["dailymotion", "elementum"]

    # Addon de Dailymotion de Gujal (fallback externo)
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
            options.append("Buscar en addon Dailymotion (Gujal)")
            actions.append("dm_gujal")
    except Exception: pass

    # Palantir 3
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
            options.append("Buscar en Palantir 3")
            actions.append("palantir")
    except Exception: pass

    # YouTube
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            options.append("Buscar en YouTube")
            actions.append("youtube")
    except Exception: pass

    sel = xbmcgui.Dialog().select(f"Buscar: {query}", options)
    if sel < 0: return

    choice = actions[sel]

    if choice == "dailymotion":
        kb = xbmc.Keyboard(query, 'Buscar en Dailymotion')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            xbmc.executebuiltin(
                f"Container.Update({_u(action='search', url=kb.getText(), direct='true')})")

    elif choice == "elementum":
        kb = xbmc.Keyboard(query, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            xbmc.executebuiltin(
                f"RunPlugin({_u(action='elementum_search', q=kb.getText())})")

    elif choice == "dm_gujal":
        kb = xbmc.Keyboard(query, 'Buscar en addon Dailymotion')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            dm_url = (
                f"plugin://plugin.video.dailymotion_com/"
                f"?action=search&query={urllib.parse.quote(kb.getText())}"
            )
            xbmc.executebuiltin(f'Container.Update("{dm_url}")')

    elif choice == "palantir":
        if not _check_estuary_palantir_fix():
            if xbmcgui.Dialog().yesno("AtresDaily",
                "Tienes la skin [B]Estuary Palantir[/B] instalada pero SIN el fix de compatibilidad.\n\n"
                "Sin el fix, puede que veas una pantalla negra al mostrar resultados de Palantir.\n\n"
                "¿Quieres instalar el fix ahora? (Después se buscará automáticamente)"):
                xbmc.executebuiltin(f"RunPlugin({_u(action='toggle_estuary_palantir_fix')})")
                xbmc.sleep(2000)

        xbmc.executebuiltin(
            f"RunPlugin({_u(action='palantir_search_prompt', q=query)})")

    elif choice == "youtube":
        kb = xbmc.Keyboard(query, 'Buscar en YouTube')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            youtube_url = (
                f"plugin://plugin.video.youtube/kodion/search/query/"
                f"?q={urllib.parse.quote(kb.getText())}"
            )
            xbmc.executebuiltin(f'Container.Update("{youtube_url}")')

# =============================================================================
# MENÚS TRAKT
# =============================================================================

def menu_trakt_root():
    # Carpeta "Listas de Trakt.tv"
    # Contiene: Opciones + Listas Importadas + Películas Top
    
    # 1. Opciones
    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar Lista[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)
    
    # 2. Películas (Top Historia/Populares)
    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)
    
    # 3. Listas Importadas
    lists = core_settings.get_trakt_lists()
    for l in lists:
        list_id = l.get('id')
        list_name = l.get('name', f'Lista {list_id}')
        if not list_id: continue
        count = l.get('item_count', 0)
        label = f"{list_name} [COLOR gray]({count} ítems)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': f"ID: {list_id}\nUsuario: {l.get('user', '?')}\nTotal: {count} elementos."})
        
        cm = [("Eliminar lista", f"RunPlugin({_u(action='trakt_delete_list', list_id=list_id)})")]
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id), listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(_handle())

def menu_options():
    # Menú de Opciones
    
    # 1. GUÍA DE AYUDA
    li = xbmcgui.ListItem(label="[COLOR yellow][B]Guía: Cómo obtener tu API Key (Paso a Paso)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)

    # 2. Configurar API Key
    key = core_settings.get_trakt_api_key()
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"
    
    li = xbmcgui.ListItem(label=f"Configurar API Key {status}")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Pulsa aquí para introducir tu Client ID una vez lo tengas."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)
    
    # 3. Importar Lista
    if key:
        li = xbmcgui.ListItem(label="Importar Lista por ID")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la lista pública (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(_handle())

def help_guide():
    heading = "[COLOR yellow]GUÍA: CONFIGURAR TRAKT.TV[/COLOR]"
    
    text = (
        "[B]PASO 1: REGISTRO[/B]\n"
        "Entra en tu navegador (PC o móvil) a:\n"
        "[COLOR cyan]https://trakt.tv/oauth/applications[/COLOR]\n"
        "Identifícate con tu cuenta de usuario.\n\n"
        
        "[B]PASO 2: CREAR APLICACIÓN[/B]\n"
        "Pulsa el botón verde [B]NEW APPLICATION[/B].\n\n"
        
        "[B]PASO 3: RELLENAR DATOS[/B]\n"
        "Copia y pega exactamente esto en los cuadros:\n"
        " • [B]Name:[/B] AtresDaily\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Javascript (cors) origins:[/B] (Vacío)\n"
        " • [B]Permissions:[/B] No marques nada.\n\n"
        "Baja al final y dale al botón morado [B]SAVE APP[/B].\n\n"
        
        "[B]PASO 4: OBTENER EL CÓDIGO[/B]\n"
        "Tras guardar, aparecerán varios códigos.\n"
        "Busca el que dice [B]Client ID[/B] (es una línea de letras y números).\n\n"
        "Copia ese código y pégalo en el menú 'Configurar API Key' de este addon.\n\n"
        "--------------------------------------------------\n"
        "[I]* Nota: La API Key es personal y gratuita. Solo sirve para que el addon pueda leer las listas públicas de Trakt.tv.[/I]"
    )
    
    xbmcgui.Dialog().textviewer(heading, text)

def set_api_key():
    k = xbmc.Keyboard(core_settings.get_trakt_api_key(), 'Introduce Trakt Client ID (API Key)')
    k.doModal()
    if k.isConfirmed():
        key = k.getText().strip()
        core_settings.set_trakt_api_key(key)
        xbmcgui.Dialog().notification("AtresDaily", "API Key Guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Configura la API Key primero", xbmcgui.NOTIFICATION_ERROR)
        return

    k = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    k.doModal()
    if k.isConfirmed():
        list_id = k.getText().strip()
        if not list_id: return
        
        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("AtresDaily", "Importando lista de Trakt...")
        
        try:
            r = requests.get(f'https://api.trakt.tv/lists/{list_id}', headers=headers, timeout=15)
            if r.status_code != 200:
                pDialog.close()
                xbmcgui.Dialog().notification("Error Trakt", f"Error {r.status_code}: No se pudo leer la lista", xbmcgui.NOTIFICATION_ERROR)
                return
            
            data = r.json()
            name = data.get('name', f'Lista {list_id}')
            user = data.get('user', {}).get('username', 'Unknown')
            item_count = data.get('item_count', 0)
            
            core_settings.add_trakt_list(list_id, name, user, item_count)
            
            pDialog.close()
            
            if xbmcgui.Dialog().yesno("AtresDaily", f"Lista '{name}' importada con éxito.\n\n¿Quieres abrirla ahora mismo?"):
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_view_list', list_id=list_id)})")
            else:
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_root')})")
            
        except Exception as e:
            if 'pDialog' in locals(): pDialog.close()
            xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().notification("Error", "Falta API Key", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle())
            return

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception:
            xbmcplugin.endOfDirectory(_handle())
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudieron cargar los elementos:\n{msg}")
            xbmcplugin.endOfDirectory(_handle())
            return

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        # --- SISTEMA DE CACHÉ DE IMÁGENES ---
        cache = _load_thumb_cache(list_id)
        has_cache = len(cache) > 0

        # BOTONES DE GESTIÓN DE CARÁTULAS
        if not has_cache:
            li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar y GUARDAR Carátulas permanentemente <<<[/B][/COLOR]")
            li.setArt({'icon': 'DefaultAddonService.png'})
            li.setInfo('video', {'plot': "Esta opción buscará las fotos de TODA la lista y las guardará en tu dispositivo.\n\n[COLOR red][B]ADVERTENCIA:[/B][/COLOR] Una vez guardadas, la lista tardará un poco más en cargar cada vez que entres, pero se verá mucho mejor."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_cache_covers", list_id=list_id), listitem=li, isFolder=False)
            
            if not show_covers:
                li = xbmcgui.ListItem(label="[COLOR green]Ver carátulas solo esta vez (Sin guardar)[/COLOR]")
                li.setArt({'icon': 'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id, show_covers="1"), listitem=li, isFolder=True)
            else:
                li = xbmcgui.ListItem(label="[COLOR cyan]Ocultar carátulas temporales[/COLOR]")
                li.setArt({'icon': 'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id, show_covers="0"), listitem=li, isFolder=True)
        else:
            li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas (Volver a carga rápida)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultIconError.png'})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la lista vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_cache", list_id=list_id), listitem=li, isFolder=False)

        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            data = item.get(t)
            if not data: continue
            
            title = data.get('title')
            if not title: continue
            year = data.get('year')
            overview = data.get('overview', '')
            tagline = data.get('tagline', '')
            
            item_key = f"{title}_{year}"
            label = f"{title} ({year})" if year else title
            li = xbmcgui.ListItem(label=label)
            
            thumb = ai
            if has_cache and item_key in cache:
                thumb = cache[item_key]
            elif show_covers:
                try:
                    search_url = "https://api.dailymotion.com/videos"
                    params = {"search": f"{title} {year} movie poster", "fields": "thumbnail_720_url,thumbnail_360_url", "limit": 1}
                    rs = requests.get(search_url, params=params, timeout=5).json()
                    if rs.get('list'):
                        best_img = rs['list'][0]
                        thumb = best_img.get('thumbnail_720_url') or best_img.get('thumbnail_360_url') or ai
                except Exception: thumb = ai

            li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
            
            video_info = {
                'title': title,
                'year': year,
                'plot': f"[B]{tagline}[/B]\n\n{overview}" if tagline else overview,
                'mediatype': 'movie' if t == 'movie' else 'tvshow'
            }
            li.setInfo('video', video_info)
            
            # Menú contextual: Añadir a Favoritos
            cm = []
            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_fav', title=title, url=title, f_thumb=thumb, f_action='trakt_search_dialog', extra=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            li.addContextMenuItems(cm)
            
            # Clic principal: Diálogo multi-búsqueda
            play_url = _u(action='trakt_search_dialog', q=title)
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=True)
            
        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmcgui.Dialog().ok("Error Trakt", f"Ocurrió un error al ver la lista:\n{str(e)}")
        try: xbmcplugin.endOfDirectory(_handle())
        except Exception: pass

def cache_covers(list_id):
    try:
        if not xbmcgui.Dialog().yesno("AtresDaily", 
            "[B]AVISO DE CARGA:[/B]\n\n"
            "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
            "Esto hará que la lista [COLOR yellow]tarde más en cargar[/COLOR] cada vez.\n\n"
            "¿Quieres continuar con la descarga?"):
            return

        key = core_settings.get_trakt_api_key()
        headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception: 
            xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt", xbmcgui.NOTIFICATION_ERROR)
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudo obtener la lista para cachear:\n{msg}")
            return

        cache = {}
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("AtresDaily", "Descargando carátulas...")
        
        total = len(items)
        if total == 0:
            pDialog.close()
            xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
            return

        for i, item in enumerate(items):
            if pDialog.iscanceled(): break
            if not isinstance(item, dict): continue
            
            t = item.get('type')
            data = item.get(t)
            if not data: continue
            
            title = data.get('title')
            year = data.get('year')
            item_key = f"{title}_{year}"
            
            percent = int((float(i) / total) * 100)
            pDialog.update(percent, f"Procesando ({i}/{total}): {title}")
            
            try:
                search_url = "https://api.dailymotion.com/videos"
                params = {"search": f"{title} {year} movie poster", "fields": "thumbnail_720_url,thumbnail_360_url", "limit": 1}
                rs = requests.get(search_url, params=params, timeout=5).json()
                if rs.get('list'):
                    best_img = rs['list'][0]
                    cache[item_key] = best_img.get('thumbnail_720_url') or best_img.get('thumbnail_360_url')
            except Exception: pass
            
        pDialog.close()
        
        if cache:
            with open(_get_thumb_cache_path(list_id), 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            xbmcgui.Dialog().notification("AtresDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error Cache", f"Error al guardar carátulas:\n{str(e)}")

def clear_cache(list_id):
    try:
        path = _get_thumb_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("AtresDaily", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def delete_list(list_id):
    try:
        if xbmcgui.Dialog().yesno("Eliminar Lista", "¿Seguro que quieres borrar esta lista de tu colección?"):
            core_settings.remove_trakt_list(list_id)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

# =============================================================================
# PELÍCULAS TOP (HISTORIA / POPULARES)
# =============================================================================

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

def top_movies(page):
    try:
        try: page = int(page)
        except Exception: page = 1
        per_page = 50
        movies = _get_movies_list()
        total = len(movies)
        start = (page - 1) * per_page
        end = start + per_page
        page_items = movies[start:end]

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        # --- SISTEMA DE CACHÉ DE IMÁGENES ---
        cache = _load_top_movies_cache()
        has_cache = len(cache) > 0

        # BOTONES DE GESTIÓN DE CARÁTULAS
        if not has_cache:
            li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar y GUARDAR Carátulas permanentemente <<<[/B][/COLOR]")
            li.setArt({'icon': 'DefaultAddonService.png'})
            li.setInfo('video', {'plot': "Esta opción buscará las fotos de TODA la lista (130+ pelis) y las guardará.\n\n[COLOR red][B]Aviso:[/B][/COLOR] Tardará un poco cada vez que entres, pero se verá de cine."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cache_top_movies_covers"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas (Volver a carga rápida)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultIconError.png'})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la lista vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="clear_top_movies_cache"), listitem=li, isFolder=False)

        for m in page_items:
            li = xbmcgui.ListItem(label=m)
            
            thumb = ai
            if has_cache and m in cache:
                thumb = cache[m]

            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
            li.setInfo('video', {'title': m, 'plot': f"Película legendaria: {m}"})
            
            # Menú contextual
            cm = []
            params_json = json.dumps({'q': m})
            fav_url = _u(action='add_fav', title=m, url=m, f_thumb=thumb, f_action='trakt_search_dialog', extra=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            li.addContextMenuItems(cm)
            
            # Clic principal: Diálogo multi-búsqueda
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_search_dialog", q=m), listitem=li, isFolder=True)
        
        if end < total:
            li = xbmcgui.ListItem(label=f"Siguiente Página ({page + 1}) >>")
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar películas top:\n{str(e)}")
        try: xbmcplugin.endOfDirectory(_handle())
        except Exception: pass

def cache_top_movies_covers():
    try:
        if not xbmcgui.Dialog().yesno("AtresDaily", 
            "¿Quieres descargar las carátulas de las 130+ películas top?\n\n"
            "Esto hará que la sección se vea mucho mejor pero [COLOR yellow]tardará un poco más en cargar[/COLOR]."):
            return

        movies = _get_movies_list()
        cache = {}
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("AtresDaily", "Descargando carátulas Top...")
        
        total = len(movies)
        for i, m in enumerate(movies):
            if pDialog.iscanceled(): break
            
            percent = int((float(i) / total) * 100)
            pDialog.update(percent, f"Buscando ({i}/{total}): {m}")
            
            try:
                search_url = "https://api.dailymotion.com/videos"
                params = {"search": f"{m} movie poster", "fields": "thumbnail_720_url,thumbnail_360_url", "limit": 1}
                rs = requests.get(search_url, params=params, timeout=5).json()
                if rs.get('list'):
                    best_img = rs['list'][0]
                    cache[m] = best_img.get('thumbnail_720_url') or best_img.get('thumbnail_360_url')
            except Exception: pass
            
        pDialog.close()
        
        if cache:
            with open(_get_top_movies_cache_path(), 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            xbmcgui.Dialog().notification("AtresDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al guardar carátulas top:\n{str(e)}")

def clear_top_movies_cache():
    try:
        path = _get_top_movies_cache_path()
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("AtresDaily", "Cache eliminada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

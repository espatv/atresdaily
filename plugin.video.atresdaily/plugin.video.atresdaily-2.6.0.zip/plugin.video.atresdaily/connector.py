# -*- coding: utf-8 -*-
# ============================================================================
# MÓDULO EXTERNO - AtresDaily
# ============================================================================
#
# AVISO LEGAL Y CONDICIONES DE USO
# =================================
#
# NATURALEZA DEL SOFTWARE:
# Este archivo es un COMPONENTE EXTERNO de carácter EXPERIMENTAL y EDUCATIVO.
# Su único propósito es estudiar la interoperabilidad entre plataformas web
# públicas (Atresplayer/Dailymotion) y el centro multimedia Kodi (Código Abierto).
#
# PROPIEDAD Y DISTRIBUCIÓN:
# Este módulo NO forma parte del repositorio público del frontend AtresDaily.
# Se distribuye de forma privada bajo licencia "Todos los Derechos Reservados".
# Queda prohibida su modificación, redistribución o ingeniería inversa
# sin autorización expresa.
#
# ACEPTACIÓN EXPLÍCITA:
# La mera presencia de este archivo en el sistema implica que el usuario 
# ha realizado una acción voluntaria de "carga" o "instalación externa".
# Por tanto, este Aviso Legal prevalece sobre cualquier licencia del 
# software principal (AtresDaily Frontend), ya que este código no es 
# una dependencia nativa, sino un añadido opcional bajo responsabilidad única del usuario.
#
# POLÍTICA DE CONTENIDO:
# El código actúa exclusivamente como cliente HTTP (equivalente a un navegador).
# 1. NO aloja, copia ni descifra contenido protegido (DRM).
# 2. NO realiza bypass de sistemas de pago o suscripción.
# 3. Solo accede a flujos de datos "Free-to-View" publicados por los proveedores.
#
# EXENCIÓN DE RESPONSABILIDAD:
# El uso de este conector puede contravenir los Términos de Servicio (TOS)
# de los proveedores de contenido. El usuario asume toda la responsabilidad.
# El autor no ofrece garantías y no se hace responsable de ningún daño derivado.
#
# COOPERACIÓN CON TITULARES DE DERECHOS:
# Si usted es un titular de derechos y considera que este módulo le perjudica,
# contacte con el autor para su desactivación inmediata.
# Existe voluntad total de cooperación y cumplimiento normativo.
#
# © 2026 AtresDaily - Componente Externo
# ============================================================================

import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import requests
import urllib.parse
import json
import time
import difflib
import re
import ui_utils
import exploration_history
import dm_gujal  # GPL v3 licensed module (Gujal00)

# HOTFIX 1
try:
    import __main__
    if not hasattr(__main__, 'exploration_history'):
        __main__.exploration_history = exploration_history
        xbmc.log("[AtresDaily Connector] Hotfix 1: OK", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[AtresDaily Connector] Hotfix 1 Failed: {e}", xbmc.LOGWARNING)

# HOTFIX 2
try:
    import xbmcaddon
    
    _PATCH_MARKER = "# [HOTFIX2-CACHE-24H]"
    _addon_path = xbmcaddon.Addon().getAddonInfo('path')
    _default_py_path = os.path.join(_addon_path, 'default.py')
    

    _needs_patch = True
    try:
        with open(_default_py_path, 'r', encoding='utf-8') as f:
            _default_content = f.read()
        if _PATCH_MARKER in _default_content:
            _needs_patch = False
            xbmc.log("[AtresDaily Connector] Hotfix 2: Patch already applied to default.py", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[AtresDaily Connector] Hotfix 2: Could not read default.py: {e}", xbmc.LOGWARNING)
        _needs_patch = False
    
    if _needs_patch:

        _cache_logic = '''
    # [HOTFIX2-CACHE-24H]
    try:
        import time as _hf_time
        import json as _hf_json
        _hf_cache_file = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'connector_cache.json')
        _hf_cache_hours = 24
        _hf_local_hash = _get_local_hash()
        if os.path.exists(_hf_cache_file) and _hf_local_hash:
            with open(_hf_cache_file, 'r', encoding='utf-8') as _hf_f:
                _hf_cache = _hf_json.load(_hf_f)
            _hf_hours_passed = (_hf_time.time() - _hf_cache.get('last_check', 0)) / 3600
            if _hf_hours_passed < _hf_cache_hours:
                xbmc.log(f"[AtresDaily Loader] Cache valid ({_hf_hours_passed:.1f}h < {_hf_cache_hours}h). Skipping remote check.", xbmc.LOGINFO)
                return True
    except:
        pass
    # [/HOTFIX2-CACHE-24H]
'''
        
        _target_line = 'def _ensure_connector():'
        _inject_after = '"""'
        
        if _target_line in _default_content:

            _func_start = _default_content.find(_target_line)
            

            _docstring_start = _default_content.find(_inject_after, _func_start + len(_target_line))
            
            if _docstring_start != -1:

                _docstring_end = _default_content.find(_inject_after, _docstring_start + len(_inject_after))
                
                if _docstring_end != -1:
                    _docstring_end += len(_inject_after)

                    _line_end = _default_content.find('\n', _docstring_end)
                    
                    if _line_end != -1:

                        _patched_content = (
                            _default_content[:_line_end + 1] +
                            _cache_logic +
                            _default_content[_line_end + 1:]
                        )
                    
                    _func_end = _default_content.find('\ndef ', _func_start + 1)
                    if _func_end == -1:
                        _func_end = len(_default_content)
                    
                    try:
                        _backup_path = _default_py_path + '.backup_pre_hotfix2'
                        if not os.path.exists(_backup_path):
                            with open(_backup_path, 'w', encoding='utf-8') as f:
                                f.write(_default_content)
                        
                        with open(_default_py_path, 'w', encoding='utf-8') as f:
                            f.write(_patched_content)
                        
                        xbmc.log("[AtresDaily Connector] Hotfix 2: Successfully patched default.py with 24h cache", xbmc.LOGINFO)
                        xbmc.log("[AtresDaily Connector] Hotfix 2: Backup saved as default.py.backup_pre_hotfix2", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[AtresDaily Connector] Hotfix 2: Failed to write patch: {e}", xbmc.LOGERROR)
            else:
                xbmc.log("[AtresDaily Connector] Hotfix 2: Could not find docstring in _ensure_connector", xbmc.LOGWARNING)
        else:
            xbmc.log("[AtresDaily Connector] Hotfix 2: Could not find _ensure_connector function", xbmc.LOGWARNING)
    

    try:
        import xbmcvfs
        _cache_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_cache_dir):
            os.makedirs(_cache_dir)
        _cache_path = os.path.join(_cache_dir, 'connector_cache.json')
        
        _should_update_cache = True
        if os.path.exists(_cache_path):
            try:
                with open(_cache_path, 'r', encoding='utf-8') as _hf_f_check:
                    _hf_old = json.load(_hf_f_check)
                # Only update if older than 24h (86400s)
                if (time.time() - _hf_old.get('last_check', 0)) < 86400:
                    _should_update_cache = False
            except:
                pass

        if _should_update_cache:
            with open(_cache_path, 'w', encoding='utf-8') as f:
                json.dump({'last_check': time.time()}, f)
    except:
        pass

except Exception as e:
    xbmc.log(f"[AtresDaily Connector] Hotfix 2 Failed: {e}", xbmc.LOGWARNING)

# HOTFIX 3
try:
    import xbmcaddon
    
    _HF3_MARKER = "# [HOTFIX3-LOG-CLEANUP]"
    _addon_path = xbmcaddon.Addon().getAddonInfo('path')
    _default_py_path = os.path.join(_addon_path, 'default.py')
    
    _needs_patch3 = True
    try:
        with open(_default_py_path, 'r', encoding='utf-8') as f:
            _default_content = f.read()
        if _HF3_MARKER in _default_content:
            _needs_patch3 = False
    except:
        _needs_patch3 = False
    
    if _needs_patch3:
        _replacements = [
            ('xbmc.log(f"[AtresDaily Loader] Trying ({ua_name}): {url}", xbmc.LOGINFO)', '# [HOTFIX3-LOG-CLEANUP]\n            xbmc.log(f"[AtresDaily Loader] Trying source...", xbmc.LOGINFO)'),
            ('xbmc.log(f"[AtresDaily Loader] Security check failed for {url}. Missing integrity token.", xbmc.LOGWARNING)', 'xbmc.log("[AtresDaily Loader] Security check failed. Missing integrity token.", xbmc.LOGWARNING)'),
            ('xbmc.log(f"[AtresDaily Loader] Failed {url}: {e}", xbmc.LOGWARNING)', 'xbmc.log(f"[AtresDaily Loader] Source failed: {type(e).__name__}", xbmc.LOGWARNING)'),
        ]
        
        _patched = _default_content
        _applied = 0
        for _old, _new in _replacements:
            if _old in _patched:
                _patched = _patched.replace(_old, _new, 1)
                _applied += 1
        
        if _applied > 0:
            try:
                with open(_default_py_path, 'w', encoding='utf-8') as f:
                    f.write(_patched)
            except:
                pass

except:
    pass

# --- CONSTANTS ---
API_BASE = "https://api.atresplayer.com"
CH_ID = "5a6b32667ed1a834493ec03b"
_INTERNAL_BUILD_ID = "X7-Daily-Secure-992" # Integrity Token
_DEBUG_MODE_BACKDOOR = False # DO NOT ENABLE - SYSTEM INTEGRITY CHECK


# ----------------------------------------------------------------------------
# PROTECTED LOGIC SEGMENT
# Generated: 2026-01-19 05:21:07
# ----------------------------------------------------------------------------
import zlib, base64

_KIER3_PAYLOAD = "eJzdfUtzG0fS4F2/or5WWGhYIAhSD8sY0wpKpC3ukiKXoDTjoBiIRncBaKnRDfYDJM3BRuxxD/sjfPwOPmz4tpeJGP6xzcyq6q5+4aHXeD7EjEx0V2VlZWXlq7IS9+6zl1bMR0F4ww72onsvd896bIfd3mPwMXo8dHlkdJnxxHpqbQ22t79/9nSw/WzL2XpmPdnaHjwzWqLlSRiMQmtiaY2tTqHx96rxXmAnE+7HlieBDzpPvxsMH4n2g461/Z29PXy8rdof+EPLj11Pwd5+PNjKw7Y7qu2uHSeW5zqWk7beesILmNjGvfm9e/fZxsYG6+3vnr58xQ6Pfz54iQ/uOXzILMfpj90oNi+bXYI7BqIkbj8BLKK2F1hO/30U+GYDGwHt2vit0aSm7pBdMtdn4y4bt0M+CWYcwAgobdePeBibnRaTj1KgkTXjVUBbbHzefdK5aN4jzPq2xy2/H7uxx81YYgdDGgymi8PG4hF+plYYR4B43I6mnhub1KaZvoZeln9j2jCfKx6aTexNXc47F+mzYRAyG9+cK25o6avdKqxmS1utVm41LpoZYvgJeZyEasCti3YUh+7UFNjJd3H6kKYecSu0x33Xj3noc1ibFuPXcWj1AYY1iXZeBz5vMccNuR3v/GR5Ec/I4wcxu+xKwPSQ/rGHo5qFjXgcu/4oKqysG8EKxpZvcxP6tpgHS9XsSji38wzyfbbrzLCdw7xg5NoM+cBhccBgKlbixe3pDeAaTa3YHvOQcOTc4U6LDZKYwSPOrjizogiIiwwVMVp5BushAI4t3/G4I0d7AZ2uLDdu6fDHlsMAuv0honW0FEaTwOFt2fFszFlkh9YUZishu3HEPZyrJDm+2bNc72YSxG7gE3LtbKrI8LBSuJBXbjw2DRinawBVLoEml+ePuxeC1vg1x75yC4glR0btR6FpF5a1qS8htIJZI6j/2KH1VL0qO1X0NNgZ7ZLLjBkjdzL1eJ+QTTfKmdGEXZC2ScdRjWuHu8/2PY7bIZmwYErkMt8cAEn5RLTy3H4MwK4HE3uUuO1DYKADeGl61oB7O0Pj/OXx4fEpu+EebMGL8xcX//zH64DxCNaGXSYcuCOyreg5LDj8N2SNW/ty3mDcB24ZRLD4wGJhCOOfb764ON8kYBdGNnQbGHsXJNBtw7WBsbussSf4ZddxAv+UT4PIJeEz9UcgexrxOJkMljSb58GDAAjMxsx1eAAQbhtTL4gBwtA4SbzIYtZlcvc77ntLzEWfQ0Y7869yOmdiOk1YJ1hIaGQn8DW0ItjMESBkOUGEXXdj+E5c2jYkQglRemjcRjdR2wpHM1jS+XPLxlXZ4WqovpQr0zCYTOMHlzu3Seh57qANKEa8fZkEMWz2y+bc0OTGhECfX6Tf2tZ0yn3HNA25MIDSieWhJAyZuQ/bA9cw8S3gCtu9+wM2so3YN0FMDo3TxD/xkpHrm5W4TiWglVFtGs1mBWo/udcMUEks0PYZcoRIsBIicTAaAftzAaOf4jV0r9MhiQ1Agb4MQFBfx0fcT5DBIxNx0XYK7oApjYWt90hsA0fRZhCybQdEvZmisXXRbDGY7w4sqxC8uKl2cLgWyKqfAs/hoZT7Fds/2/Bq6+25Fsg7s9mGBu7QtS2comlkjIQaDPZexJHrAmS6ELZzxnbwXsF6fXx28NMBWE8Hx6/7+6enx6eZnk3Vi+0FEe8j1n1E38yaSL1E3/k1bJiQkOkrSwDtEe05Sk5qG4Uol0ZSbIa6IJq4ft9J8D0op/YI9GVDPiIQsDM7TfYte9qh1qgeIrvFZigcozAj1gz5fEb9DZLaSJS3uLeN5l/YzM3eug4+cZLsiRrLwLFSiHF40xXNcHmdJHvDr20+jeXLTvpYN1jUrH5kHZLn0PQH9RDUMCyS6ye83DUea9NAkebDAve/2+70gaOMJmrV0tvHz7S36SIevIQVPto9eJ3C9gYkZaTgHngJvzjfO0qFL7udxXNm3hIz299udTrN+Tdsgnq/aZQxDa78DFX4wsM2qGfOfd+aEPE1TawZczZZerIbtAej3gE1S1004s+utGYzl19F/TgA0y3fKr9Ww74D0NCOBHBokg3xD9P4xtn8ZrL5zS/Ql954gW159AqQaZaXNYVjPH9eMXFYxagFm81GDB13BkYKcEcLODQDBavcBwSEVMcO8wm7xS7zqAIiKh6xNC8uXlq+5XVRKbJboOr8nQ8PT5KBB/veCeQLgaF4twfMS4JavpNDi5dvYV9akXwDNJ1XjJ70aXdUSGgAY85cjULQNF7QNM41JVauaRqPmxWraE8yXSW+Zyph9+7/WmAyM4v9ZM2CEJQ6ad2cEFyqFlA8Da3Zg2FfKSzPuuk7kwcorm+REPMHJDzoSzyHhrTN8Gs8zrRVETm5pa7GIDPRFNrb773cPf1595S9vfs/e/vHORtnBTwdWHmy8ck4qcOuFp2MVtJnvvvdarfbq4wMyqWPVCLh75DiIfWdjqfv/34CTmJRCOAzEgHNXFPXKTZEOZxtYECExwpgChsEmuws/tJFrN4FRaz+HazunPzJu3SwmNR2AX9msDQa1yy7NIHfwrgnwE+oMpE3PUZ7ObfuaGtYLs7+zRS3cPUiIAQauz9V8B7gV2JDwqywFqnQV0tnSkiGZHASfcg53kDYJjMXnigNshOP0TJB5K0BNDoLE3BQUSrt4D8t0ldgIu3Yk8KuXWAykCsM7IQsJO3BNEpR7+h+dq/jv4DT8Wf3Of59XI4/v8fxdZyNhJZ+HMfTqLu5aU3dtpMJy7YdTDaJQaPngqh1tHwwdLnnRDuu0yLp0ipZrC1lWreKFmIrry1aSie0dJuwpVl+Dzx34sY72x3Ba2jxZW4JzCfksP9BUpKKSYSpFyTxzpZmliFt0GoLKVoGHhWpI6QaLPH5RdYQ3QwXXQzqkdceyN2u7mgob8Jd5E3gx+mDKZj6E5tPC6+X2udknhOQ+UQzydNlVR9hmrvrmuY0uSjrWW+dqwWoM7kbyuRulEzunMWNn8VWN36EL+Au8QXwU2WaS+ctb5/Taqxio5do+y+x1UtYFC1lIhOZWG7m5OaXyy3zbcEoEgBq/QCnWewgYNaZUG683HQaIVd+SYvZ0Uxm+CNvMxeR+hJ2c+Wgxd2q7F53iSGtmusrXWFM03qvaVDj55OMaskSH21YFxejxpz+AmZ07cp8jFnt6Ha1WxvIWc/eVjJyakXRSnZ3xVEDHTtJ+zunPNc7W5J8ssr5Uo6eH/iNkLSX8/4twms7yWQamTqKILqDMO5D04ho0tREoG3ZYw7WlIcqoiGNPXoosKuMwqURRdEbV2/GQSfph265AaoJkY3dLO4XnQ7YCs/1bDDIce/glEHf0/PyXgG+tVpC31KLc2h+UWqFWxIVKOnOJtvADj+wR087HeU7EaDMFZwi/Q1hmOHJ8lexzdCmIPMMRnzSmetLAD7e9NwQ62Vc4NlV5QKBnQsOR2mFqC/wBPU0RCNDB6CzD7RuJ0IelA+9ZHuFCfmfeI4sTttohsWHsTWKsmcpvTW1W0CAuukPxPbvjx1DTEXQCOey1elka1YyX1cwzYHkcl9PW2zMLTDzo52Ud1/t7+7tn/ZqrOAhGMDAtHES9e0A3EgQ7NsaQ2kTBLdxkbm8kBBGH8SWlzicDjJzC1UwAEl0wTh6m/Ose35XCJTOr8lGv0bQ+ERGFDBPYGA5+PS6cBZgNHO5ArKVHLx5Ua0F1lngvJkIz8ommo5yWSK4kehEvF8lCQwYR5va0EMGpZXopp1Rblb1JTamNjiH61rFtAak8gzwE3sYv6klfmUfbW7QHYhkAD76163Os9z3sTsaYwKBfLYcaYEwLYsyMa6bFXyFDWpZYbE6IcKWFvbj1IqgcaVq6aYgNTWbjkRaBBkPEGnpqiPPiBXZPBk2LQGqxjCSQgLg50yTTHYIA2QkLJAwyof8wqgoZiKb9slf2KVHmQ2ST1RKDTz3STy2h67vWJ5nhg3znfOwCXS/9GQo50tkx0xDF48Z3F95n87A9APK4rsiKxCAy/5VEDokrK5o519RQofXDjmYjzB0YwNjiKzRzJ601ROR39FEZD3um1dN9iPbvsgiOAgvJEmi8VtMsrq081JK0taMSztRLk1ccS4p/OjhEE35HmooINmRyAQyRRrTpQds5sEU0JTQgOZsAEGJbpHL5XOw2ZWWxa0csY0d1mk/LUjOxHdSgkbJxNzSaCpfAMgrAaW0ofT+PxBJZadmOuAW+5aZ+huwtrRueW0HzJqi+xB7P9EOI2sZVkcMgfjCx/ILASbdOlefSx8TyoibMKJx3cyUyaVfthvj+uZxRXMXs9ZiUw7SbLtRlAzwCf5fwmo25WS32x1WgsA9yaqXPvJqJyXrk8poT+rJqE/6JT1xDyvCaTnyRThO+3GXFRcbmam4RSvU7RDH+pGRLS1X8VH1vKjdI63dVnFIOt9/ms16O9tCdurTgkQOi+ee8BoNXBPk9o5nTQaOxa677Br2BDTmM7DqhH+YSziM7PPu9pMLlRr69nivkBdKrq9txaaNDunUGvGdjhTEX0RY8uupG97oIlKoE/E8gyXbuRFD6dHN+m0/+R5M0M4KWpbDvzLpAhyUvlKGpgQFtqw0dXMe47CBERrx6BaIAk4oUmWuOY/00sFonQUdEL9M3AJa6WCavC1u1GHieWAZxrksXIx34LNF+j6I2tikza8xSmGmcJpltgWsVbw1dQpVdxhqQg8zAFVW5gxTXRcZmmpZdtjGVlfvUWle0RZBtH6QHZd3ERYZNam2IjFBkwWwbbKpgGYMgQ0wxckBNt1pJPFw41kD7K6IDbuF5aMIA/K2OSwneJDwUeuq9QPTJLhKHXLxTLA30CnDU5ye3O6eHPRf7Pb255u254Jfujnb2oT+m9LDLHjk0MCNb85uphy98t2zk5+CEAQTquiIU1RJ5bfj+xiIhq8mluu/HFu+z70DTBR/+ap/sAfPbdmWHtIeJzdZgT97td8/Ou6dEXQQgeSWw9/I8kaX5EFmO8o5a65Kia8p1l91yLKWC/qkKvDPzBSmeACUiNq93uF+GAZhi1W9fRkAQYhm1Khik+AxWhuT5obGeXb4ecEALnK9N7DsD4wki+UENIsuI7EgU+XaIE7/unv6+uD1z+Ud9OmEaDEQ7O7wRj+YU5+iaMi76jvCVS/jJBYx76ljWPAUXhQOtzTgmQQl5wXaLtuOC8UabNGrBVs0DfuZOFKLDQsMkdtly5YSth+j5We3ORLNu/gAw6f6YhZSHXXgq6ZYDg0xHAzcLY65YoalZPl9xcpIl8KU3ckUNjLsOPAHkEvvFdGtosVLtHRsy2PZzhC0AURTSO0hSRwMq5jNJbRZK/VUkAWYE0YHBXb3h7+EHKkHQ0esea4rnVLBAD20Wu9+jxOPkjk9/0PWyHP9D9Dmdi55fhzyoVHybaBLhXeT19ND97rvTkamOkGboLDUICOzvwKb8lc8fPD0gwNHO590eGSDuyUtVkPPfKQzuy+VyUYWn8NjABDJ46/yCQyQoZkdiJXfx0095a3i/ZgSKDJNUX9CouOTHpPE4pQE0ChmH1FQDd8PRcaCdiTioKSwfCuMqWXxbETpcfQ9kJXA+9hhjzURuQRHm5SwwM/48ccf2cndb0B2i/Vc4F9Q28gEiDWpWYEnnmShi4KKtPlwq5lDu3BfquaERqePidF4ZsfXO4aRhUvge1cPu1gOHhYp8xLepmED4+/Iaixz9TWBszxHOwdZdF2SXIHYrqfvHU03pQ8phhGQx+6IzROmyqoUK4BXUiqgjdNERWjsnxz0jvf2DaW8dAlQViREcT51IxDYkVloTuQH2aLlo+EnogCIaAh2HeBfVKaS8yLkO7ZVcAcwWZ0S1SvUKgq6qCDozjhKf1iOTMxFK4k5HRsUdZ+wLwWHg30LBJn//Za0aIm7S3urxOUlUmKMNzVIaM27YknoPIO6RqZznrW5EGuSizKufACaX2y1v6qOPz8He5fmscgO++Rp6QPRv/rc6jKXqvTqPtHHJaWqZQypLCF8TN6XzBT05+BqIkOQVhWOeJytb9SfhnyipQ95ljuRO/XkdP/o4M1R5hThjUI92wm43h/xi3PZUEt6EhiIQdUYNLR4kUKsT3+RNsCs5GuOl5gRef2dcvGm5KtNQ16fFUOP1aW87H2TLozKp/mbegCohNDnskfwk/tSm55W8jYo0rXV6WCsi3rBP5v0IN90WabVXz4tvWqpMaWtK3bpZnlZ+xOwhZ0gTXvFVA0evvOz3Cs97+rMnQbwoCH5rlHissbPQK4EjLRGIR9r2CdJKeYnZKVi1Vy7L2v2USLKhDuuVWv0YebWIqNPYL2C5fdAqIZKGIIYBeuwtLoybQOEbXiTEi47/fi7PP2YZ7u+ZNHgZ1HmmTYCMGGC5t2KrQurVn+7Q2YxU5L2Hse/R/DV3DtqlrLWVktUEmiopDXMGHsgb4djHOirp6xJkhXuGNCOg52BZ0jyCBh3SbU5UJ0wRXyaGh2oAiqzpjJ/QLJVLlmKcEhNEgqg5HKnalwFUp8ZFiaNWWVy/2ss7lJMUYgtjCkqbXKL2YzPXx/vnR4RX1TkQZcCdzmFIk2Yth1Mb9BAG58bp3zIQx6K9BqVdHJ1ddW2MtFJSSd5mVYVAVMW07g66eRLRftWivQh8+AfIOlnKwT5Fk1vUYpNXVhPV/qlcN7jzqOSs1MKv9zwyA9MyjlGnvZRwe1jekzkzgJ2AvvQTSYofcisi2LOZne/g5VI03CxRgNer4gSUqfijgXoR8/CHRFbFBhiwdC1Ybz2O/+d/89//A/qFtGlGu6xCFiZQyMsagH/Y5TQ7f6KlzlwNDvFCsBmMCPcx5hEFjFrAPBiK3pe5ZqpAiC4xYS5BLqgIj107UxFjaarZiyqjzfzcudZQpb0PT7jHuip7WrnCzvtgB9INSVEzZCNrYu641LRelu0hu2vqpqAAkz7CssXfUx6RG6mME0Wgo+4gApCqv0+cFXvUssI035Y7U2g/AWuWhvjslmwevBDe4xfczuJ+SBxPVghs1IlIgqobcpR7bwLqYDKCzKw6Kc8CrwZd96Enlm+FyOVQ+kyWUGflh3V5TH3mSSbUTAKlcefdwCjIAltXhnakCMakykfYQIWhQu0SEcueaqbjiubRKGNXtoANMqHohChphXhfAHiIeD+9zcRDzd2R7Cjdwz2sMpCKoq7cyPrY1w0oZPxQCqROhCL9UpFQpiH15FLi4a6codwx9iIW3WXjuwKvI6XKQJGJQDUJbzcZx1OEuFIz60AI70QYnZYE2Bv5y3ImoELYuzGNE7EXF9ZkSxG0BVNxXNgECSGSfOqGUBjz1K84DPuhvVD/l2WKSM/IJc+8N0BxRYWhv9F1sLhwdt9dvY2n7PguTNuqkyFsUoMPU+pcouuvSrd9fSJ9R13tqxnjx4//v4RHwyfonUp4hd4yIrIWeyRMW9V9/9u2y70H+j9PasHEt+q7+4Uh3f07q95cF3b91lnUOjLc32DWf24zx49KfQd6n2P+GhB3+8LOH/XyZEMV1mUzxIa8WKFgFnNWbgLu3PTFofXKPqWW1BPmusJYcqWwKJPmA98jtO8yNKcJPeUE3BtXT6X5aNNwRxbrxWC1MmeZeGxSudUYo9gKL9YoFhx+qQ1RgGCYLuFoYpRKVQQcmRhJW02mmgAVKQUispVlahRkjQih4Plk6JFAbWhFwTX4BXAUB9c51f878y9xv+AcKMtZuNVHPYE/wS2wpppi+dHc5MropxXyZcie0EyIP5nXhMbTddOwlnlhIccPpQpfcmIqfdpn4sxL+ThjmAf3Q0tV1IpXdpR13qr9JW4sV64sA7icLfLDjH0I672RmCUczDuwG31PLCmgYrs7clrmZtQuqK+4Aa5cYjm9gRUT+BzuvUth0ijTELtwvy5D2+lRU9BKIfH3BZuAdr7EqWBF8A3QMqDVjad7RJoC0+nZ3f/SV0B2TbruQJqxKZhAMQBsOCTA4EGFrR2eCSmE3pWev9czCV32b5M8PknXoo2jNyd6Oob0cti7iUeoohad5nbjj1W8dk/1tnUauWUbdGVxOdiY/UQ8P9KBmuNsZrOnlYglMaNKe3XjzNfG1mfxkXxBuKf0tLCHY0b8/Xx2hbWyeHuL4cHvbNe3sbKX4k06S5mLkkfn+RKcyyvF4BdNm/xX7EHCHQFt8t7NJgRl10Yg2nmLqzRpTNxzUncL2sVDgJU9EFcQ2UGj/r7PXwxtCaAFyYjxaC/4E3HyDz7ulDRobQiUrxpZwgiiClpAaOD1z8dNxduXpUKJq80qr18q3tO3VJULu9Yzde7uVXykNfM3cFcKv1m70LuKp/srlpVQV1sKddUWA9njwn7A5wOUjvZytVhTqtWQhyXeVpT5WFKZuC0wgyc5s1AdUcZW9hB4sdZE52F6bjtL6gL7azB4vMtsiD0Q1JpRNySlZSekJq3NOxchvyiQmWIRdYJ/Zu605WVb4S+1CvZZIAXWCM0TyDvMKUPXeEW6yY21Tsf3Udav8IMUiNBZ4+PMgBqolp4dTWVgA9cZ+d2ipUCkK6V4S18QSlz1cZEPi9iSRlFpVk+YptaSEA6bFrK8EoRoNDPzdacpsaLOj91nTWFvYK1SWRTF1Kpc+3149Id4/T2cfli8irXjLc68p7xUmOqnJr7WUTxRwm99VY93Tozy7773VpfuM1qhNvnL5ZJK7G8duWC6pRqLatLbuo7p1B2Ez8LajKukYmwSFTO4oKcVLW/6GKCFJpYI3AFGanilLMYuqaFTnFi8D0tCFaVsFAUjAL+SRhMeRjfmI2D1D+l8mQglwqHISob4WvUX9HrFVakJcQV2QIwn+r6WF9WH+TKQALaq7iN+Pkaol7qxFUEvUxnKNj3Utp/GEjmbv93fjMIrNAxDVE4eALemKadwaws14f6MGg7wVHgWJ7Z1JUHPHcjWK+hG07AN6NNLp+DHDiDVUQnUBNN0ocGXPQmuUjaYom+1A3RSiPcqnIPXTVu0dVIa1zkC2Slvsn882oNwm8NrUHt12SgXCXouz+YWth1rXpx6EgYNMWhZl5Wp5V+sAX+FIMIUaZVi5h0orJ3pSJFVe6ogKslDpRuhYhy9XRnCfZzIs5ns/UDySefKVxQFlLxoEYTrDjh3aFmJOzyAsh1rjUdkNI74h6IGNPo4X9tGN3SySoRKheHAWA/gqqqSP7NEw8aLiBf9rZEwFWI+AlSiEpQ+k6wCgOpoMPe8V9fHx7v7vUKV1LzGkLk35B2yFujs4I1Sv/cZ29OD2U8E+OJbMJjy7FkCp0mraj1JG/B4rFjlQXLw00JxhImrIjWGfqwr8Tel7lehXESqyK7Ji8GqN0YVAuZxXn5YQGZVf5Nly1E19B+sCMnHe8zGYlil/j7JfGNooxVL0AnerIOoKZJqu01Qw0wfppj0+sdFqJp6wy86Eacdje86hrBpZajL6ggfv3lVrOV0j8A2z6eqhRuPGoE3WqzHikNkhOC59jRyWMmupkvYD7ilWRo1x8V7jTwCGtYYY4aXriiEOtl1BYJ2xU3G0RzypO2kjgwas5SEPQQYUmwFeXXkO+zk6LKwx/SKotPa4alixZie0ymjytqvuEHpzCzPHVxX0yoqU0OjATHHVFFC+3+dvGTLk56RNQg45vM4VsJaj5lpsq6ZHtSJMD6YJXWBkwbDxLwqjCPGl2FGNrCMBsMa8AkGlWMcZ9t5xb+1WGPmUeP3jwTlxcll+vbQyyWWNyawPpldC5aXVTG0KMSoWHenpTIm9cbGGIHwVdD9EkusF694PipLCeRAnlkl7cppiJo1gtdpqyF4OFWAjDiSBKWj0c1VX4UacCgpuoZYN5PeIgpQF5UcchQIJaX++me+/t/O9v420bv7HR/92gDPOCqtLLiB/eHB/r04dYFqeeHW7IWCIwv+NIoZzFVoEJ7iPRzHidj0TFo8RNOiPBtWRo7bJzu944P36BG3cF6IdeyZohXT8wUVCT923DSHoVBMjW3xOaTOezGG/+DD9Jq+eQKG5ngqrPm6wZeZyDA8LeoPUPjLtjR+mfJ7iZYc2bixpsCbXt8hDWoQcW3z3orbu6xF1Wm+rCqu//4uc96eNsWUGODG0ZHTEmq3/NIV1bpIExKlTqKVnwKZEnQO/hQbcuD65L+sgulWOJZvzy4lYKQDJR8KiYlcu57ACAE+Y2h7oRDF44sq8520bYDQ9ayAV6QHhhLSCT12wWpov8CjKDgAf7O2dD6FfFJosQK3aDLyFCO5bVg8ctqaRdvQNrXO5frL5I2SCSklMpUc0TO4ioWuRyHTEJJF3TkB/kKgAjvB9bpFv2d9I/UNk+ROYc+lbbCbvSBcJddHBWI0I67KChWwn6ANx25+Qh4V5uAc/eHD8iPgIYOZtZ6TMWM0uBRo5EeL8r/NBolrxFHrZ/ffSb9ddJxmA8ilM7A4zogMadzsbcuUDvR9iqZLyr5rSpfOdXTMFKWmYxTyc5uBDcr2gHT9jgbWO+t8O43kgNRKgducC8kvgtvkFPY0PVluvI+lo/H3ANiYw+bt9k///FSyGIrrEw6LnPySchhH3GGtQzQCcsqFEXWkIsfg6NzdpFRe25nOSniHeb9gKljeaDZRCyEXjbYRr9xUU4XktTLgHfzAwGlMjf4GlnSaKMRVrM8aNpIgd+OtdCmwymJThWJkdnAGLfEcFg64PyWaiZU2kZnoTsa8czm1ZkJf7ePCLEnX7Ij8BfSFl+0vKzj9SeU3pAlastHjeofCrrPjkFSh8CCQujwkWXfYKVWfXQdFtFHAtTq/KUDl9z7DKWtquGPjveO2S9nG3uHJ132JrLSXc4O9pSHi/ye24vaaIXLAvdZ3wn6qW99EzveVPjWuOrKw16sdhbFAWApA4nuWjme+oAVWdxLBA1ycknQaETYLu9mSdn93snu3u7B4S8VDXKU4tHUIjfbVOOjeXGxgG4fR7t9GEdkIn8s+UQFsmzyj2sn/+bw7HR32cQTD6yILzzpNzjGZ5vwVtWEMdREk/75zX/bPaQoU7FRbtqj5L3lrTzt6lI0OYBir64EsQztPuleLNe0Hpd/Hi7+s7Lxp7Pqv4BXqxglPw0wm1aehBaxrS0TVJfHlOpfWRYJo5lddovFSviigj9L/BABTiuABKbXlCwlK0wdEG0cVYK+vPsosKBPvbtWHBX5ZyJAtZdAbgFQzeTr4xWmtIsd4G/j4qVm0VT0M0DpMLMH6l6/ibQWP6Xm7ksxAmxNAZEsIgU2zzIfEZXH1F41Ugp9lfPBKvlVsybOtOS20I9p80hFd5xpW+RpZGY+epNHJ4/VzWc0ZeAR1qAi+9JYubgMsBK3JrIIkIpEPdJ/mxPTQVSUoi2DytpFPT/eABN+FI8b+aqhDmCVSx7ICpsJGjSuBqpcWSmkZ48T/4PIl3XB5e3LkUx63sc6eztbne3H324/eVqdMwskc/FAxQaXz8Fz0fK9LRqrfRW6+AO5CLcs42gOD3cocFXTBK0qotCPVYdP+JnyEGvpq0wLBPkt5tSwTdGzOogyiUZ0tKIWnBYXO2+aNHP8p9ltbw3nRy8A0i2BqnhXHYhy0vL9ErsWDqgt3lScs5c9qCJhc+BX2vzItkvMZJSK//zt7n9fu3HwH8TjlDEj3XU8JMNfY1PmO+zS7jv/FsHrPhVpwUK1T2xTwBlahBx/iV28XEUrYFjOmVJcjtJj8aihimSV8yqKeBAxoBX9CE+nfNtdJt5Rw6nDx/7nligydnA8wLAWxydpSAArHVQIFSTFc6KEjlSewgMr4jI1XW+kgp3PG1itpR2m92xabAufsIcMvuQgpSnNOObDWmhbFxoTFI2GOmzWG7+RBTMmj5JnSkAVRWx+pbR6RvlAv6SyiNVlITodci7mT0F6co6p4p4eGm/cb2iJPiQV+gCeCSGmBqq+MK+1LvnaC3nZOLQobkAHxmCvhIGTyEsuQIq732RWXdvIch9WUAt9oFVZNbjONaafjfqUI5w720hn9ykqoaqrGi5HaDxFbtQchWAHeWYku5aa1Zizuc4prz7MZvxQcuFyxKMEY83IVNXVh5GaVhzzyZQKwlNZKPNRzYwWHm0hcrIacI795Uxyx95tydC1wGjdpV5WgOsPZrJJVlY/Vp/qtcaPOq2oPU2qYgiKJYqRu0A4N+KZsgBfAU/qQUmFd7/Hrk2FGpQcZbfAvw+35hUHiKUHecPBxBSXhyCa8tYDbtcyLGU99ArDbt6mnUSFMWEtlg2fJfbBVzEUUButZCikPoA0FvZVnA89fzrUwVg2aLObzIL497MZ2BsfwQodLXmswlhYSFkRi8bwHx4BKnOBzpWrwsYKTrFOfeE3UwBAGjcWwGS+h6ywi4yEEkCN1oaePIzNTovdphOX2dFd6VVmzxFnqqQNqGdPZ3SjVc1Ee4GDwRs1Zjv9ww+uRPaj+q36Xza+mWx847BvXnW/OZJMoH6yt/yjLUVitHAmaSoWuIC74O6z3uvdk96r4zO2//rng9f7aUpWf8jpx0s8ry/rfKgtIeWmjLQrbwuVNcDsCXTsJAxTX2ot667g1OKG5DLNDPQydEVbmngkyCw8+ge1A6VrqvvViE45s2a5Ys2ayjx+LRnoPpMoTYKITe7+nxe7gEvEpqIwbMTMsYVmxZPsCR5U2WkBLgD3Px/hjxkg7HxuEFaMzfTak3I20AoGQSGS+BJIZice3fOdCpoHeDYWMFND6aFCNi+8ptpxv4kruincP3DXOljdg54j0ptPmt+CI9eR7/NQNMksTuRRyNsyef38RXpj6cXFO1+z4yVGjH6KAdXIPFvuysmuWXmfJsi+TvV9UWX/aW2VffxUmiufu6y+5KPqX3hb0br8yGry9ANPWM1bjIPZFfS75GPrBvbRb9kOAlvZ8mLaXxZWoYpUqWVtEy3HsqaCeI7ibEk18cpey+qCVveSBBgvyQH6nEU+06FR0GR1FTC9FG2VBP4LmtUgVYU61pjCH3W1NSsSZ0oPaEWxbJjcuXFovQ8YWHMiE9fDegaB59ou/fR8i6kCYhF2Ikk6KS9srni3+BWdMp8qi7jUu0auowY7R7GDpe2IPukrUlwPS+ezBbsn9+uaaR0AZ6Ld/jdkuthpzrkMg0EivU4tY5gqOzxikwDo0qZedPoAc32NosjTCoEyE6wY9jMGtptZy60uewF7CE13k96BqTy5+2PmeuzNrtZuuwvmXoyWYNYuDhwrojIO8d1/2r5rW1ItqRl8vR+EdSaihFruyH4ijtlVbbXqg3s0qK2YCithlg/S03qfYEaJBdttlARsEAQeGBJBzg5IxwNThaITpWFzp/uFw/wM24rT/AL4wnmdOpH+29np/tFxl52VFwF5hNaoU7jOZl33VUJ3nk7aGwwJdZ4V7uBRToxwb/EXvMBDAjXRR4sUk6TV6YlkZaquySdcJAxooBeoYMwPVmOs/mMde0eSKcVhBabzg5eQAqq/YK8+C2qCpVCqeuH1uCMgAap+M6VFXUtRzyo+DIIPydSsSkUXFEDSViscAaeXDEjdRCa2rD5RX7f0WHodrQyuIsGiOpBTDAoYalHoUHYIa8WdqgQgcXarsfpWJau/uPtfvYOXwOpvdpVoegj7NPjg8qiOSxfy58ACeUcC9wsw5AsE/u/Pjn8aXhL0XMpJ5VQI4p3Xx6dHu4dsF4Rlr5zAs+oRsfpIs/nTL97gwUPoAnGXtDTm9Rz6Ga4jqc/KHkR6zyYlRPWFRFqTQpDoc4yw8i9c4XFCuY7myr979V73U6pEtXYlCF2F9/K3qdO7G++jc61JxT0N/KQXOgqt6293aBisfMujbNtWEGrpdQ/1WRI3kN4KQq24SNTnkwF3lvIttarnVvzUhujLPCUGXY938bOcfz9lvIU304pUlZRt1KywIa5N0DlbzaUescqiiTo+rIWm/b5Ew5AnlqpC+bt3JL2wwmpx4asXfYGq/Al1mtSS2PmTFCQC+FpqjJ5/ZDqVNEIYlz+kxmvrhtM/oMcsn7+nMBx1EWbJvXUn9zmLh71VqfZZbhue++wdrXeVl/XO3rzoMfMk5DM3SCLcERFdwQ65yBAAWRGPOdgDgyRmJLCvgMgTN4qwsBbwPFZxaWaB5xVylrvrT/djk5XLOGV5lTXZDF8thbKMm8iK/Hx4rZ8Aee//A+qLbkE="

try:
    exec(zlib.decompress(base64.b64decode(_KIER3_PAYLOAD)), globals())
except Exception as e:
    import xbmcgui
    xbmcgui.Dialog().notification("AtresDaily", "Error de Integridad en Conector", xbmcgui.NOTIFICATION_ERROR)
    xbmc.log(f"[AtresDaily] Connector Crash: {e}", xbmc.LOGERROR)

# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import os
import sys
import re
import math
import copy

try:
    import repository
except Exception:
    pass

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import urllib.parse
import zipfile
import requests

# --- CONFIGURACIÓN DEL NÚCLEO ---
ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # "Referer": "https://www.atresplayer.com/" # Referer dinámico suele ser mejor
    "Origin": "https://www.atresplayer.com"
}

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url="", thumbnail="", extra="", folder=True, isPlayable=False, plot="", fanart="", context=None, **kwargs):
    li = xbmcgui.ListItem(title)
    
    # Configurar Arte (Icono, Thumbnail y Fanart)
    art = {}
    if thumbnail: 
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
        
    # Solo poner fanart si se pide explícitamente
    if fanart:
        art['fanart'] = fanart
        
    li.setArt(art)
    
    # Información básica
    info = {"title": title}
    if plot: info["plot"] = plot
    li.setInfo("video", info)
    
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
        
    # Inyectar "Abrir en navegador" para elementos de Dailymotion
    if action == "play_dm" and url:
        _browser_item = ("[COLOR lime]Abrir en navegador[/COLOR]",
                         f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(url)})")
        if context:
            context = [_browser_item] + list(context)
        else:
            context = [_browser_item]

    if context:
        li.addContextMenuItems(context)
        
    u = f"{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}"
    for key, value in kwargs.items():
        u += f"&{key}={urllib.parse.quote(str(value))}"
        
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

# --- AYUDANTES ---
def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    """Carga un archivo JSON. Si default es None, devuelve [] para listas o {} para settings."""
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f: return json.load(f)
    except Exception:
        if default is not None: return default
        # Auto-detección: los archivos de ajustes deben devolver dict, otros lista
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    try:
        with open(get_path(name), 'w', encoding='utf-8') as f: json.dump(data, f)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error guardando {name}: {e}", xbmc.LOGERROR)

def fix_img(url):
    if not url: return ICON_MAIN
    if url.startswith("//"): url = "https:" + url
    elif url.startswith("/"): url = "https://www.atresplayer.com" + url
    if url.endswith("/"): url += "1280x720.jpg"
    return url

# Constantes de StreamNinja requeridas para descarga/verificación fallback
_SN_ID   = "plugin.video.streamninja"
_SN_REPO = "repository.streamninja"
_SN_ZIP  = "https://fullstackcurso.github.io/estreamninja/repository.streamninja-1.0.0.zip"

# --- GESTIÓN DE REPOSITORIOS (NÚCLEO) ---

def is_repo_installed(keyword="atresdaily", target_id="repository.atresdaily"):
    """
    Abstracción para la detección de repositorios.
    Delega la lógica pesada al módulo especializado repository.py.
    """
    try:
        return repository.detector.is_installed(keyword, target_id)
    except Exception:
        # Fallback de seguridad en caso de error de importación
        return xbmc.getCondVisibility(f"System.HasAddon({target_id})")

def check_repo_status():
    """Muestra el estado del repositorio oficial mediante un diálogo premium."""
    installed = is_repo_installed()
    
    if installed:
        title = "Estado del Repositorio"
        msg = (
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado en tu sistema.\n"
            "Recibirás actualizaciones automáticas de AtresDaily."
        )
    else:
        title = "Aviso de Seguridad"
        msg = (
            "[COLOR red][B]○ NO DETECTADO[/B][/COLOR]\n\n"
            "Repositorio no instalado. Para que el addon se mantenga al día\n"
            "y reciba mejoras automáticamente, te recomendamos instalar\n"
            "el repositorio oficial de AtresDaily."
        )
        
    xbmcgui.Dialog().ok(title, msg)


def _sn_download_and_install_repo(dp):
    """Descarga el repositorio de StreamNinja, lo extrae e inicia la instalación del addon.

    Recibe un DialogProgress ya creado. Retorna True si la secuencia de instalación
    se inició con éxito, False en caso contrario.
    """
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "sn_repo.zip")
    try:
        r = requests.get(_SN_ZIP, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError(f"Error HTTP {r.status_code} al descargar el repositorio.")

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        content = bytearray()

        for chunk in r.iter_content(chunk_size=65536):
            if dp.iscanceled():
                raise InterruptedError("Cancelado por el usuario.")
            if chunk:
                content.extend(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    dp.update(
                        10 + int((downloaded * 80) / total_size),
                        "Descargando repositorio...",
                    )

        raw_b = bytes(content)
        if not raw_b.startswith(b"PK\x03\x04"):
            raise ValueError("El archivo descargado no es un ZIP válido.")

        dp.update(90, "Extrayendo...")
        with open(zip_path, "wb") as f:
            f.write(raw_b)

        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(addons_dir)

        dp.update(95, "Actualizando sistema de addons...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
        dp.close()
        xbmcgui.Dialog().ok(
            "AtresDaily",
            "Repositorio instalado con éxito.\n"
            "Acepta las ventanas de confirmación de Kodi.\n"
            "Una vez instalado, vuelve a pulsar el botón.",
        )
        return True

    except Exception as e:
        dp.close()
        msg = str(e)
        if "Cancelado" in msg:
            xbmcgui.Dialog().notification("AtresDaily", msg, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f"[AtresDaily] Error instalando StreamNinja: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", f"No se pudo instalar StreamNinja:\n{e}")
        return False

    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def streamninja_check_or_install():
    """Comprueba si StreamNinja está instalado e instala si es necesario.

    Uso: connector.py (fallback de reproducción cuando Atresplayer devuelve 403).
    NO abre el addon si ya está instalado — retorna True para que el llamador
    proceda con la reproducción vía RunPlugin.

    Retorna True si StreamNinja está disponible, False en caso contrario.
    """
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        return True

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja Requerido",
            "StreamNinja no está instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a intentarlo.",
            )
        return False

    if not xbmcgui.Dialog().yesno(
        "StreamNinja Requerido",
        "Para reproducir este contenido se necesita el complemento StreamNinja.\n"
        "¿Descargar e instalar automáticamente?",
    ):
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Preparando instalación de StreamNinja...")
    dp.update(10, "Configurando conexión...")
    _sn_download_and_install_repo(dp)
    return False


def streamninja_open_or_install():
    """Abre StreamNinja si está instalado, o inicia el proceso de instalación.

    Uso: botón del menú Abrir URL en url_player.py.
    Si el addon está instalado lo abre directamente. Si no, ofrece instalarlo.
    """
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        xbmc.executebuiltin(f"RunAddon({_SN_ID})")
        return

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja",
            "Addon no instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a pulsar el botón.",
            )
        return

    if not xbmcgui.Dialog().yesno(
        "Instalar StreamNinja",
        "StreamNinja no está instalado.\n¿Descargar e instalar el repositorio oficial?",
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Descargando StreamNinja...")
    dp.update(5, "Iniciando descarga...")
    _sn_download_and_install_repo(dp)


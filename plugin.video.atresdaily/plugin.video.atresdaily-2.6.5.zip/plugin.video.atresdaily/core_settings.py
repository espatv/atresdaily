# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import os
import json
import time
import xbmcaddon
import xbmcvfs

# =============================================================================
# GESTOR CENTRALIZADO DE CONFIGURACIÓN
# Centraliza: Contexto, Debug, Modo Congelado, Favoritos, etc.
# =============================================================================

# Paths
_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_CONTEXT_FILE = os.path.join(_PROFILE_PATH, "full_context.json")
_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_SNAPSHOT_CTX_FILE = os.path.join(_PROFILE_PATH, 'snapshot_context.json')
_WATCH_FILE = os.path.join(_PROFILE_PATH, 'watch_history.json')


# --- NIVEL DE CONTEXTO (0, 1, 2, 3) ---
def get_context_level():
    if not os.path.exists(_CONTEXT_FILE): return 1 # Default Level 1
    try:
        with open(_CONTEXT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            val = data.get("level", 1) # Default Level 1
            if isinstance(val, bool): return 1 if val else 0
            return int(val)
    except Exception: return 1 # Default Level 1

def cycle_context_level():
    """Ciclo: 0 -> 1 -> 2 -> 3 -> 0. Guarda y retorna el nuevo nivel."""
    current = get_context_level()
    new_level = (current + 1) % 4
    try:
        with open(_CONTEXT_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_level}, f)
        return new_level
    except Exception:
        return current

# --- NIVEL DE CONTEXTO PARA INSTANTÁNEAS (-1, 0, 1, 2, 3) ---
# -1: Clásico (Valores por defecto)
# 0-3: Niveles de contexto estándar
def get_snapshot_context_level():
    if not os.path.exists(_SNAPSHOT_CTX_FILE): return -1 # Default: Classic
    try:
        with open(_SNAPSHOT_CTX_FILE, 'r', encoding='utf-8') as f:
            return int(json.load(f).get("level", -1))
    except Exception: return -1

def cycle_snapshot_context():
    """Ciclo: -1 -> 0 -> 1 -> 2 -> -1"""
    curr = get_snapshot_context_level()
    new_val = curr + 1
    if new_val > 2: new_val = -1
    
    try:
        with open(_SNAPSHOT_CTX_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_val}, f)
    except Exception:
        return curr
    return new_val

def build_query(title, context_data, force_level=None):
    """
    Aplica contexto a un título basándose en el ajuste de nivel actual.
    context_data puede ser:
      - Una cadena simple (ej. "Nombre del Programa")
      - Una cadena de ruta separada por '||' (ej. "Abuelo||Padre")
      
    force_level: Si se establece, usa este nivel en lugar del ajuste global.
    """
    depth = get_context_level() if force_level is None else force_level
    
    if depth == 0: return title.strip()
    if not context_data: return title.strip()

    clean_title = title.strip()
    
    # Calcular Cadena de Contexto
    if "||" in context_data:
        parts = context_data.split("||")
        # Tomar hasta 'depth' elementos del final
        if depth > len(parts): depth = len(parts) 
        used = parts[-depth:]
        ctx_str = " ".join(used)
    else:
        # Contexto simple (tratar como Nivel 1)
        ctx_str = context_data

    # Evitar duplicación
    if ctx_str.lower() not in clean_title.lower():
        # Limpiar potenciales dobles espacios
        return f"{ctx_str} {clean_title}".strip()
    
    return clean_title


# --- MODO DEBUG ---
def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_debug_active(state):
    with open(_DEBUG_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


# --- MODO CONGELADO (ESTÁTICO) ---
def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

# --- MODO DE PRIORIDAD (Coincidencia vs Duración) ---
_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')

def is_prioritize_match_active():
    if not os.path.exists(_PRIORITY_FILE): return False
    try:
        with open(_PRIORITY_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_prioritize_match(state):
    with open(_PRIORITY_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


# --- FILTRO RECIENTES ---
def is_recent_active():
    if not os.path.exists(_RECENT_FILE): return False
    try:
        with open(_RECENT_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_recent_active(state):
    with open(_RECENT_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


# --- FAVORITOS ---
def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()
    # Evitar duplicados
    if any(f['url'] == url for f in favs): return False
    favs.append({
        "title": title, "url": url, "icon": icon, 
        "platform": platform, "action": action, "params": params or {}
    })
    with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f, ensure_ascii=False)
    return True

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(new_favs, f, ensure_ascii=False)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f, ensure_ascii=False)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f, ensure_ascii=False)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f, ensure_ascii=False)
        return True
        
    return False


# --- HISTORIAL DE REPRODUCCIÓN ---
def get_watch_history():
    if not os.path.exists(_WATCH_FILE): return []
    try:
        with open(_WATCH_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def add_to_watch_history(vid, title, thumb="", duration=0):
    """Registra un vídeo como visto. Deduplica y limita a 100."""
    import time as _time
    history = get_watch_history()
    # Eliminar entrada existente (para moverla al principio)
    history = [h for h in history if h.get('vid') != vid]
    history.insert(0, {
        "vid": vid, "title": title, "thumb": thumb,
        "duration": duration, "watched_at": int(_time.time())
    })
    # Limitar a 100
    history = history[:100]
    with open(_WATCH_FILE, 'w', encoding='utf-8') as f: json.dump(history, f, ensure_ascii=False)

def clear_watch_history():
    with open(_WATCH_FILE, 'w', encoding='utf-8') as f: json.dump([], f)
    return True

def get_watched_ids():
    """Devuelve un set de video IDs vistos para marcar rápidamente."""
    return {h.get('vid') for h in get_watch_history() if h.get('vid')}

def remove_watch_entry(vid):
    """Elimina una entrada del historial de reproducción por video ID."""
    history = get_watch_history()
    new_history = [h for h in history if h.get('vid') != vid]
    if len(new_history) != len(history):
        with open(_WATCH_FILE, 'w', encoding='utf-8') as f: json.dump(new_history, f, ensure_ascii=False)
        return True
    return False


# --- HISTORIAL DE DESCARGAS ---
def get_downloads():
    if not os.path.exists(_DL_FILE): return []
    try:
        with open(_DL_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def log_download(title, path, vid):
    dls = get_downloads()
    # Comprobar si existe y actualizar o añadir
    entry = {"title": title, "path": path, "vid": vid, "date": time.strftime("%d/%m/%Y %H:%M")}
    dls.insert(0, entry) # El más reciente primero
    dls = dls[:50] # Mantener los últimos 50
    try:
        with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(dls, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error guardando descarga: {e}", xbmc.LOGWARNING)

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    try:
        with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(new_dls, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error eliminando descarga: {e}", xbmc.LOGWARNING)

# --- FILTRO DE DURACIÓN ---
def get_min_duration():
    if not os.path.exists(_DURATION_FILE): return 0
    try:
        with open(_DURATION_FILE, 'r', encoding='utf-8') as f: return json.load(f).get('minutes', 0)
    except Exception: return 0

def set_min_duration(minutes):
    with open(_DURATION_FILE, 'w', encoding='utf-8') as f: json.dump({'minutes': minutes}, f)

# --- MODO DE BÚSQUEDA AVANZADA ---
def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return False
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_advanced_search_active(state):
    with open(_ADVANCED_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


# --- AJUSTES DE TRAKT ---
_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')

def get_trakt_settings():
    if not os.path.exists(_TRAKT_SETTINGS_FILE): return {"api_key": "", "lists": []}
    try:
        with open(_TRAKT_SETTINGS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {"api_key": "", "lists": []}

def save_trakt_settings(data):
    with open(_TRAKT_SETTINGS_FILE, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False)

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "")

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    new_lists = [l for l in lists if l['id'] != list_id]
    data["lists"] = new_lists
    save_trakt_settings(data)

# --- DETECCIÓN INTELIGENTE DE ADDONS EXTERNOS PARA QUE SE MUESTREN SOLO SI EL ESTÁN INSTALADOS---
def get_palantir_addon_id():
    """Busca dinámicamente cualquier versión de Palan._tir instalada)."""
    import xbmc
    common_ids = ['plugin.video.palantir', 'plugin.video.palantir2', 'plugin.video.palantir3', 'plugin.video.palantir4']
    for pid in common_ids:
        if xbmc.getCondVisibility(f"System.HasAddon({pid})"):
            return pid
    try:
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        if os.path.exists(addons_dir):
            for d in os.listdir(addons_dir):
                if d.startswith('plugin.video.palantir') and 'visor' not in d:
                    if xbmc.getCondVisibility(f"System.HasAddon({d})"):
                        return d
    except Exception:
        pass
    return None

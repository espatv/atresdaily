# -*- coding: utf-8 -*-
"""
Módulo de gestión y detección de repositorios para AtresDaily.
Implementación robusta y segura para el ecosistema Kodi (Grado A).
"""
import os
import xml.etree.ElementTree as ET
import xbmc
import xbmcvfs

class RepoDetector:
    """Implementa detección precisa de addons mediante parsing XML, con caché en memoria."""
    
    _instance = None
    _cache = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RepoDetector, cls).__new__(cls)
        return cls._instance

    def is_installed(self, keyword, target_id=None):
        """
        Verifica si un repositorio está instalado en Kodi.
        
        Args:
            keyword (str): Subcadena identificativa (ej: 'atresdaily' o 'streamninja').
            target_id (str, optional): ID exacto del addon en la base de datos de Kodi.
            
        Returns:
            bool: True si el repositorio está activo o físicamente presente en disco.
        """
        # 1. Caché de sesión de lectura rápida
        cache_key = f"{keyword}_{target_id}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        # 2. Detección nativa por ID (Alta Fidelidad, Baja Latencia)
        if target_id and xbmc.getCondVisibility(f"System.HasAddon({target_id})"):
            self._cache[cache_key] = True
            return True

        # 3. Fallback de Escaneo Físico y Parseo XML
        # Resuelve: Instalaciones directas desde ZIP (ej. GitHub), repos renombrados o en estado "disabled".
        found = self._deep_scan_filesystem_for_addon(keyword.lower(), target_id)
        
        self._cache[cache_key] = found
        return found

    def _deep_scan_filesystem_for_addon(self, keyword_lower, target_id):
        """
        Escanea el directorio de addons leyendo los addon.xml para extraer iterativamente
        el ID real del complemento, sin depender del nombre de la carpeta, que puede ser inexacto.
        """
        addons_path = "special://home/addons/"
        
        try:
            if not xbmcvfs.exists(addons_path):
                return False
                
            dirs, _ = xbmcvfs.listdir(addons_path)
            for directory in dirs:
                dir_lower = directory.lower()
                
                # Filtro temprano de rendimiento: solo miramos carpetas que parezcan repositorios o contengan la keyword
                if "repository" not in dir_lower and keyword_lower not in dir_lower:
                    continue
                
                # Ruta en formato VFS (sin traducir al OS)
                vfs_xml_path = f"special://home/addons/{directory}/addon.xml"
                
                if xbmcvfs.exists(vfs_xml_path):
                    if self._verify_xml_id(vfs_xml_path, keyword_lower, target_id):
                        # Encontramos el addon pero puede estar deshabilitado, 
                        # forzamos su retorno como 'presente' en disco.
                        xbmc.log(f"[AtresDaily] Repo localizado vía parseo VFS profundo en: {directory}", xbmc.LOGINFO)
                        return True
                        
        except Exception as e:
            # Capturamos I/O Errors en entornos restrictivos (Android 11+, LibreElec)
            xbmc.log(f"[AtresDaily] Error en escaneo profundo de addons: {str(e)}", xbmc.LOGWARNING)
            
        return False

    def _verify_xml_id(self, vfs_xml_path, keyword_lower, target_id):
        """Parsea de forma segura el archivo addon.xml utilizando el VFS nativo de Kodi."""
        try:
            # Usar API nativa VFS en lugar de I/O de sistema operativo puro.
            # Esto previene bloqueos de permisos en plataformas como UWP (Xbox) o Android TV.
            vfs_file = xbmcvfs.File(vfs_xml_path)
            content = vfs_file.read()
            vfs_file.close()

            root = ET.fromstring(content)
            real_id = root.attrib.get('id', '').lower()
            
            # Chequeo 1: Es exactamente el target_id que buscamos?
            if target_id and real_id == target_id.lower():
                return True
                
            # Chequeo 2: ¿Contiene la subcadena en un ID de formato repositorio?
            if real_id.startswith('repository.') and keyword_lower in real_id:
                return True
                
        except Exception:
            # Archivo XML corrupto o permisos de VFS denegados
            pass
            
        return False


    def reset_cache(self):
        """Limpia el estado de la verificación. Debe ser invocado tras instalar un addon."""
        self._cache = {}

# Instancia singleton para ser importada por el resto del addon
detector = RepoDetector()

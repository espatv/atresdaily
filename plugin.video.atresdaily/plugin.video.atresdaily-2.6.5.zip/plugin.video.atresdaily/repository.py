# -*- coding: utf-8 -*-
"""
Módulo de gestión y detección de repositorios para AtresDaily.
Implementación robusta y segura para el ecosistema Kodi (Grado A).
"""
import os
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcvfs

class RepoDetector:
    """Implementa detección precisa de addons mediante parsing XML, con caché en memoria."""
    
    _instance = None
    _cache = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RepoDetector, cls).__new__(cls)
        return cls._instance

    def is_installed(self, keyword, target_id=None):
        """
        Verifica si un repositorio está instalado en Kodi.
        
        Args:
            keyword (str): Subcadena identificativa (ej: 'atresdaily' o 'streamninja').
            target_id (str, optional): ID exacto del addon en la base de datos de Kodi.
            
        Returns:
            bool: True si el repositorio está activo o físicamente presente en disco.
        """
        # 1. Caché de sesión de lectura rápida
        cache_key = f"{keyword}_{target_id}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        # 2. Detección nativa por ID (Alta Fidelidad, Baja Latencia)
        if target_id and xbmc.getCondVisibility(f"System.HasAddon({target_id})"):
            self._cache[cache_key] = True
            return True

        # 3. Fallback de Escaneo Físico y Parseo XML
        # Resuelve: Instalaciones directas desde ZIP (ej. GitHub), repos renombrados o en estado "disabled".
        found = self._deep_scan_filesystem_for_addon(keyword.lower(), target_id)
        
        # Si lo encontramos físicamente pero System.HasAddon falló, es casi seguro que está deshabilitado.
        if found and target_id:
            self._enable_addon(target_id)
            
        self._cache[cache_key] = found
        return found

    def _deep_scan_filesystem_for_addon(self, keyword_lower, target_id):
        """
        Escanea el directorio de addons leyendo los addon.xml para extraer iterativamente
        el ID real del complemento, sin depender del nombre de la carpeta, que puede ser inexacto.
        """
        addons_path = "special://home/addons/"
        
        try:
            if not xbmcvfs.exists(addons_path):
                return False
                
            dirs, _ = xbmcvfs.listdir(addons_path)
            for directory in dirs:
                dir_lower = directory.lower()
                
                # Filtro temprano de rendimiento: solo miramos carpetas que parezcan repositorios o contengan la keyword
                if "repository" not in dir_lower and keyword_lower not in dir_lower:
                    continue
                
                # Ruta en formato VFS (sin traducir al OS)
                vfs_xml_path = f"special://home/addons/{directory}/addon.xml"
                
                if xbmcvfs.exists(vfs_xml_path):
                    if self._verify_xml_id(vfs_xml_path, keyword_lower, target_id):
                        # Encontramos el addon pero puede estar deshabilitado, 
                        # forzamos su retorno como 'presente' en disco.
                        xbmc.log(f"[AtresDaily] Repo localizado vía parseo VFS profundo en: {directory}", xbmc.LOGINFO)
                        return True
                        
        except Exception as e:
            # Capturamos I/O Errors en entornos restrictivos (Android 11+, LibreElec)
            xbmc.log(f"[AtresDaily] Error en escaneo profundo de addons: {str(e)}", xbmc.LOGWARNING)
            
        return False

    def _verify_xml_id(self, vfs_xml_path, keyword_lower, target_id):
        """Parsea de forma segura el archivo addon.xml utilizando el VFS nativo de Kodi."""
        try:
            # Usar API nativa VFS en lugar de I/O de sistema operativo puro.
            # Esto previene bloqueos de permisos en plataformas como UWP (Xbox) o Android TV.
            vfs_file = xbmcvfs.File(vfs_xml_path)
            content = vfs_file.read()
            vfs_file.close()

            root = ET.fromstring(content)
            real_id = root.attrib.get('id', '').lower()
            
            # Chequeo 1: Es exactamente el target_id que buscamos?
            if target_id and real_id == target_id.lower():
                return True
                
            # Chequeo 2: ¿Contiene la subcadena en un ID de formato repositorio?
            if real_id.startswith('repository.') and keyword_lower in real_id:
                return True
                
        except Exception:
            # Archivo XML corrupto o permisos de VFS denegados
            pass
            
        return False


    def install(self):
        """
        Realiza la auto-instalación del repositorio oficial (autocontenido).
        Utiliza 100% la API VFS nativa de Kodi para evitar problemas de permisos
        (Scoped Storage) en Android 11+ y UWP, donde shutil fallaría.
        """
        addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
        repo_id = "repository.atresdaily"
        
        # Ruta origen usando OS join (100% fiable para leer dentro del propio addon)
        import os
        src_vfs = os.path.join(addon_path, "resources", repo_id)
        dest_vfs = f"special://home/addons/{repo_id}"
        
        if not os.path.exists(src_vfs):
            xbmc.log(f"[AtresDaily] Error: No se encontró el repo bundled en {src_vfs}", xbmc.LOGERROR)
            return False
            
        try:
            # 1. Operación atómica de borrado usando VFS
            if xbmcvfs.exists(dest_vfs):
                self._vfs_rmtree(dest_vfs)
                
            # 2. Copia Híbrida (Lee con OS, Escribe con VFS)
            self._hybrid_copytree(src_vfs, dest_vfs)
            xbmc.log(f"[AtresDaily] Repositorio copiado híbrido a {dest_vfs}", xbmc.LOGINFO)
            
            # 3. Notificar a Kodi
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(500)
            xbmc.executebuiltin(f"InstallAddon({repo_id})")
            
            # 4. Forzar habilitación (Kodi 19+ deshabilita addons manuales por defecto)
            self._enable_addon(repo_id)
            
            self.reset_cache()
            return True
            
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error crítico VFS instalando repositorio: {str(e)}", xbmc.LOGERROR)
            
            # Rollback Atómico: Limpiar residuos si la instalación falló a la mitad
            try:
                if xbmcvfs.exists(dest_vfs):
                    self._vfs_rmtree(dest_vfs)
                    xbmc.log(f"[AtresDaily] Rollback ejecutado: Carpeta corrupta eliminada.", xbmc.LOGINFO)
            except Exception as rollback_e:
                xbmc.log(f"[AtresDaily] Fallo durante el rollback: {rollback_e}", xbmc.LOGWARNING)
                
            return False

    def uninstall(self):
        """Elimina físicamente el repositorio del sistema de forma atómica."""
        repo_id = "repository.atresdaily"
        dest_vfs = f"special://home/addons/{repo_id}"
        if not dest_vfs.endswith('/'): dest_vfs += '/'
        
        try:
            # 1. Desactivar primero vía JSON-RPC para liberar la DB
            self._set_enabled(repo_id, False)
            
            # 2. Borrado físico
            if xbmcvfs.exists(dest_vfs):
                self._vfs_rmtree(dest_vfs)
                xbmc.log(f"[AtresDaily] Carpeta {repo_id} borrada físicamente.", xbmc.LOGINFO)
                
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(1000)
            self.reset_cache()
            return True
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error crítico desinstalando repositorio: {str(e)}", xbmc.LOGERROR)
            return False

    def _set_enabled(self, addon_id, enabled):
        """Habilita o deshabilita un addon vía JSON-RPC."""
        try:
            import json
            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id, "enabled": enabled},
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_cmd))
        except: pass

    def _enable_addon(self, addon_id):
        """Usa JSON-RPC para habilitar el addon forzosamente.
        Incluye un bucle de reintentos porque UpdateLocalAddons es asíncrono."""
        try:
            import json
            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id, "enabled": True},
                "id": 1
            }
            payload = json.dumps(rpc_cmd)
            
            for _ in range(5):
                response = xbmc.executeJSONRPC(payload)
                if '"error"' not in response:
                    xbmc.log(f"[AtresDaily] Repositorio {addon_id} habilitado vía JSON-RPC.", xbmc.LOGINFO)
                    return
                xbmc.sleep(1000)
                
            xbmc.log(f"[AtresDaily] Fallo al habilitar addon tras 5 intentos. Res: {response}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallo al habilitar addon vía RPC: {e}", xbmc.LOGWARNING)

    def _vfs_rmtree(self, path):
        """Eliminación recursiva pura VFS con trailing slash safe."""
        if not path.endswith('/'):
            path += '/'
        dirs, files = xbmcvfs.listdir(path)
        for f in files:
            xbmcvfs.delete(f"{path}{f}")
        for d in dirs:
            self._vfs_rmtree(f"{path}{d}")
        xbmcvfs.rmdir(path)

    def _hybrid_copytree(self, src_os, dest_vfs):
        """Copia Híbrida: Lee con OS puro (inmune a paths extraños), Escribe con VFS puro (inmune a Android 11+)."""
        import os
        dest_check = dest_vfs if dest_vfs.endswith('/') else dest_vfs + '/'
        if not xbmcvfs.exists(dest_check):
            xbmcvfs.mkdirs(dest_check)
            
        for item in os.listdir(src_os):
            s = os.path.join(src_os, item)
            d = f"{dest_vfs}/{item}"
            
            if os.path.isdir(s):
                self._hybrid_copytree(s, d)
            else:
                # Leer fichero origen a memoria (vía Python)
                with open(s, 'rb') as f:
                    content = f.read()
                # Escribir fichero destino (vía Kodi VFS C++)
                v_file = xbmcvfs.File(d, 'wb')
                success = v_file.write(content)
                v_file.close()
                
                # BUG 6 Fix: Verificar escritura estricta en Kodi 19+
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {d}")

    def reset_cache(self):
        """Limpia el estado de la verificación. Debe ser invocado tras instalar un addon."""
        self._cache = {}

# Instancia singleton para ser importada por el resto del addon
detector = RepoDetector()

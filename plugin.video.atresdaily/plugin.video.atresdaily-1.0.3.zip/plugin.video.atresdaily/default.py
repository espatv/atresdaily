# -*- coding: utf-8 -*-
import sys

import os
import time
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import re
import base64

try:
    import requests
except ImportError:
    xbmc.log("[AtresDaily] Failed to import requests module", xbmc.LOGERROR)
    sys.exit(1)

# Encoded configuration
def _d(s): return base64.b64decode(s).decode('utf-8')
_c = lambda x: ''.join([chr(ord(c) ^ 0x1F) for c in x])

_E0 = _d("aHR0cHM6Ly9hcGkuYXRyZXNwbGF5ZXIuY29t")
_E1 = _d("NWE2YjMyNjY3ZWQxYTgzNDQ5M2VjMDNi")
_E2 = {"a": _d("NWE2YTFiMjI5ODZiMjgxZDE4YTUxMmI4"), "b": _d("NWE2YTFiYTA5ODZiMjgxZDE4YTUxMmI5"), 
       "c": _d("NWIwNjdiZjM5ODZiMjhiMGEyN2MyZjQy"), "d": _d("NWE2YTI0YjE5ODZiMjgxZDE4YTUxMmMw"),
       "e": _d("NWE2YTIxNWU5ODZiMjgxZDE4YTUxMmJj"), "f": _d("NWI1ZjJmNzc3ZWQxYTg2ODYwMTAyMTQ0")}
_E3 = _d("aHR0cHM6Ly9hcGkuZGFpbHltb3Rpb24uY29tL3ZpZGVvcw==")
_E4 = _d("aHR0cHM6Ly93d3cuZGFpbHltb3Rpb24uY29tL3BsYXllci9tZXRhZGF0YS92aWRlby8=")

# URL del archivo de estado en GitHub (CAMBIAR ESTO POR LA URL REAL RAW)
# El formato del JSON debe ser: {"allowed": true} o {"allowed": false}
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/status.json" 

# URL del archivo de mensajes (Avisos/Novedades)
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/messages.json"

_H = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Origin": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t"),
    "Referer": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29tLw==")
}

def _l(m): xbmc.log(f"[AtresDaily] {m}", xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)

def _fix_img(t):
    if not t: return ""
    if t.startswith("//"): t = "https:" + t
    elif t.startswith("/"): t = _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t") + t
    if t.endswith("/"): t += "1280x720.jpg"
    return t

def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'search_history.json')

def _load_history():
    f = _get_history_file()
    if not os.path.exists(f): return []
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o)
    except: return []

def _add_to_history(q):
    q = q.strip()
    if not q: return
    h = _load_history()
    if q in h: h.remove(q)
    h.insert(0, q)
    h = h[:50]
    with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)

def _show_history():
    h = _load_history()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    
    if not h:
        li = xbmcgui.ListItem(label="No hay historial reciente")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="main_menu"), listitem=li, isFolder=False)
    else:
        for q in h:
            li = xbmcgui.ListItem(label=q)
            li.setArt({'thumb': icon, 'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=q, ot=icon), listitem=li, isFolder=True)
        
        li = xbmcgui.ListItem(label="Borrar Historial")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_history"), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clear_history():
    with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump([], o)
    xbmcgui.Dialog().notification("AtresDaily", "Historial borrado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def main_menu():
    cats = [
        {"title": "Series", "id": _E2["a"]}, {"title": "Programas", "id": _E2["b"]},
        {"title": "Documentales", "id": _E2["c"]}, {"title": "Infantil", "id": _E2["d"]},
        {"title": "Actualidad", "id": _E2["e"]},
    ]
    li = xbmcgui.ListItem(label="Buscar manualmente...")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="manual_search"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Historial de Búsquedas (Últimas 50)")
    li.setArt({'icon': 'DefaultAddonRepository.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_history"), listitem=li, isFolder=True)

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=c["id"]), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    if _is_debug_active():
        li = xbmcgui.ListItem(label="Hecho por RubénSDFA1labernt")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="sanitized_info"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Información del Addon")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info"), listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="Mas en: https://github.com/fullstackcurso")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="web_info"), listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="v1.0.3 - XYZ")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'debug_state.json')

def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f): return False
    try:
        with open(f, 'r') as o: return json.load(o).get('active', False)
    except: return False

def _toggle_debug():
    NewState = not _is_debug_active()
    with open(_get_debug_state_file(), 'w') as o: json.dump({'active': NewState}, o)
    
    msg = "ACTIVADO" if NewState else "DESACTIVADO"
    xbmcgui.Dialog().notification("AtresDaily", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _sanitized_info():
    t = (
        "[B]AtresDaily[/B]\nAddon creado por RubénSDFA1labernt\n\n"
        "[B]Información importante:[/B]\n• Este addon es completamente GRATUITO\n"
        "• Sin ánimo de lucro\n• NO aloja ningún contenido\n"
        "• Solo actúa como buscador de vídeos en internet\n• No contiene software malicioso\n\n"
        "[B]¿Cómo funciona?[/B]\nEl addon explora catálogos públicos y realiza "
        "búsquedas en internet usando únicamente el nombre del contenido.\n\n"
        "NO está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres el "
        "capítulo completo, solo un trailer, un resumen, o contenido "
        "similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible públicamente en internet.\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "El desarrollador de este addon NO se hace responsable del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de las búsquedas. El usuario es el único "
        "responsable de cumplir con las leyes de su país. Este addon "
        "se proporciona \"tal cual\", sin garantías de ningún tipo."
    )
    xbmcgui.Dialog().textviewer("Información", t)

def _info():
    t = (
        "[B]AtresDaily[/B]\nAddon creado por RubénSDFA1labernt\n\n"
        "[B]Información importante:[/B]\n• Este addon es completamente GRATUITO\n"
        "• Sin ánimo de lucro\n• NO aloja ningún contenido\n"
        "• Solo actúa como buscador de vídeos en internet\n• No contiene software malicioso\n\n"
        "[B]¿Cómo funciona?[/B]\nEl addon explora catálogos públicos y realiza "
        "búsquedas en internet usando únicamente el nombre del contenido.\n\n"
        "NO está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres el "
        "capítulo completo, solo un trailer, un resumen, o contenido "
        "similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible públicamente en internet.\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "El desarrollador de este addon NO se hace responsable del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de las búsquedas. El usuario es el único "
        "responsable de cumplir con las leyes de su país. Este addon "
        "se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        "[B]Contacto:[/B]\nhttps://fullstackcurso.github.io/donaciones/#mensaje"
    )
    xbmcgui.Dialog().textviewer("Información de AtresDaily", t)

def _web_info():
    t = (
        "https://github.com/fullstackcurso\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita mi GitHub para más proyectos como este.[/B]\n\n"
        "Allí encontrarás mis otros trabajos y actualizaciones.\n"
        "Cualquier apoyo o difusión de mis proyectos se agradece enormemente.\n\n"
        "------------------------------------------------\n"
        "[B]NOTA:[/B] (No vendo cursos)\n"
        "La cuenta se llama así simplemente porque la creé cuando "
        "estaba estudiando Full Stack."
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _manual_search():
    kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
    kb.doModal()
    if kb.isConfirmed():
        q = kb.getText()
        if q:
            _add_to_history(q)
            _lfd(q, "")

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

"""
INSTRUCCIONES DE USO PARA EL ARCHIVO status.json
================================================

El archivo "status.json" sirve para controlar el addon a distancia una vez que los usuarios lo tienen instalado.
Para que funcione hay un arhivo en el repositorio de GitHub (en la misma ruta que configuré en el código).

EXPLICACIÓN DE LOS CAMPOS:
--------------------------

1. "allowed" (true / false)
   - true: El addon funciona con normalidad.
   - false: "KILL SWITCH". El addon deja de funcionar inmediatamente para todos los usuarios.
     Sirve para apagarlo por emergencia legal o técnica.

2. "min_version" (Ejemplo: "1.0.5")
   - Indica la versión mínima requerida para que el addon funcione.
   - Si un usuario tiene la versión "1.0.2" y pone aquí "1.0.5", el addon dejará de funcionarles
     y les obligará a actualizar.
   - Para no forzar actualizaciones, se deja en una versión baja (ej. "0.0.0").

3. "message"
   - Es el texto que le saldrá en pantalla al usuario si su versión es antigua o si el addon está desactivado.
   - Se puede cambiar para dar avisos (ej: "Mantenimiento", "Actualiza ya", etc).
"""
def _check_validity():
    # Sistema de seguridad para validar el addon remotamente
    pd = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(pd): os.makedirs(pd)
    sf = os.path.join(pd, 'status_check.json')
    
    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    
    # Cargar estado local
    if os.path.exists(sf):
        try:
            with open(sf, 'r') as f: st = json.load(f)
        except: pass
    
    # Si esta marcado como desactivado localmente, bloquear
    if st.get('disabled', False):
        return False
        
    # Comprobar solo si han pasado 7 dias (604800 segundos)
    if now - st.get('last_check', 0) > 604800:
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            
            # Si el archivo no existe (404) o hay error de servidor, IGNORAR (Fail Open)
            if r.status_code != 200:
                return True 
                
            data = r.json()
                
            # 1. Comprobacion Global (Kill Switch)
            if not data.get('allowed', True):
                st['disabled'] = True
                with open(sf, 'w') as f: json.dump(st, f)
                return False
            
            # 2. Comprobacion de Version Minima
            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]
            
            if pv(cur_v) < pv(min_v):
                # La version actual es inferior a la minima requerida
                msg = data.get('message', "Tu versión está obsoleta. Por favor actualiza el addon.")
                xbmcgui.Dialog().ok("AtresDaily", msg)
                st['disabled'] = True
                with open(sf, 'w') as f: json.dump(st, f)
                return False
            
            # Todo ok
            st['last_check'] = now
            st['disabled'] = False
            with open(sf, 'w') as f: json.dump(st, f)
        except:
            pass
            
    return True

"""
SISTEMA DE MENSAJES / AVISOS (messages.json)
============================================

Este sistema comprueba si hay novedades en el archivo "messages.json" de mi GitHub
y muestra una ventana emergente al usuario cuando entra al addon.

Configuración en messages.json:
-------------------------------
1. "id": ¡IMPORTANTE! Es el identificador del mensaje (ej: "aviso_v2").
   - El addon guarda qué IDs ya ha visto el usuario.
   - Para que salga un mensaje NUEVO, cambiar el "id" (ej: de "aviso_v1" a "aviso_v2").
   
2. "title": El título de la ventana emergente.

3. "message": El texto del aviso. Usa \n para saltos de línea.

4. "repeat": Cuántas veces se mostrará este mensaje al usuario.
   - 1  -> Se muestra solo la primera vez que entre (y nunca más).
   - 3  -> Se muestra las primeras 3 veces (para asegurar que lo lea).
   - -1 -> Se muestra SIEMPRE (infinito) cada vez que entre.
   - 0  -> Mensaje desactivado (no lo muestra nadie).

Ejemplo:
  {
    "id": "noticia_importante_enero",
    "title": "Mantenimiento",
    "message": "Mañana habrá cortes por mantenimiento.",
    "repeat": 1
  }
"""
def _check_messages():
    # Comprobar si hay mensajes remotos para mostrar
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'messages_state.json')
    
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        # Fail Open: Si no hay fichero o error, no hacemos nada y seguimos
        if r.status_code != 200: return
        
        msg = r.json()
        mid = msg.get("id")
        mrep = msg.get("repeat", 0)
        
        # Si no hay ID o repeat es 0, salimos
        if not mid or mrep == 0: return
        
        # Cargar estado local (cuantas veces se ha visto cada ID)
        st = {}
        if os.path.exists(sf):
            try:
                with open(sf, 'r') as f: st = json.load(f)
            except: pass
            
        # Vemos cuantas veces ha visto este mensaje concreto
        views = st.get(mid, 0)
        
        show_it = False
        if mrep == -1: show_it = True    # Siempre
        elif views < mrep: show_it = True # Aun no ha llegado al limite
        
        if show_it:
            # Mostrar Dialogo
            xbmcgui.Dialog().ok(msg.get("title", "Aviso"), msg.get("message", ""))
            
            # Incrementar contador y guardar
            st[mid] = views + 1
            with open(sf, 'w') as f: json.dump(st, f)
            
    except:
        pass

def _top_movies(page):
    try: page = int(page)
    except: page = 1
    per_page = 50
    movies = _get_movies_list()
    total = len(movies)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = movies[start:end]

    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')

    for m in page_items:
        li = xbmcgui.ListItem(label=m)
        li.setArt({'thumb': icon, 'icon': icon})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=m, ot=icon, mode="movie"), listitem=li, isFolder=True)
    
    if end < total:
        li = xbmcgui.ListItem(label=f"Siguiente Página ({page + 1}) >>")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls(cid):
    u = f"{_E0}/client/v1/row/search"
    p = {"entityType": "ATPFormat", "sectionCategory": "true", "mainChannelId": _E1, "categoryId": cid, "sortType": "THE_MOST", "size": 50, "page": 0}
    try:
        r = requests.get(u, params=p, headers=_H); r.raise_for_status(); d = r.json()
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e)); return
    items = d.get("itemRows", [])
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try: dr = _sr(tt); th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except: th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)
        except: continue
    if cid == _E2["d"]:
        li = xbmcgui.ListItem(label="Debug")
        li.setArt({'icon': 'DefaultAddonService.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)
        
        li = xbmcgui.ListItem(label="Borrar Caché")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_cache"), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

def _clear_cache():
    if not xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar TODA la caché?\n\nEsto eliminará el historial de búsquedas, configuración de debug y mensajes vistos.\n¿Estás seguro?"):
        return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(p):
        for f in os.listdir(p):
            if f.endswith(".json"):
                try: os.remove(os.path.join(p, f))
                except: pass
    xbmcgui.Dialog().notification("AtresDaily", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
    # Refrescar para reflejar cambios (ej: debug desactivado)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    try: r = requests.get(au, headers=_H); r.raise_for_status(); d = r.json()
    except: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", [])
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth); return
    if id_: _rel(id_, st, sth); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth=""):
    try: r = requests.get(ru, headers=_H); d = r.json(); _rel(d.get("itemRows", []), st, sth)
    except: pass

def _rel(items, st, sth=""):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt
        sq = f"{st} {tt}"; sq += f" {en}" if en and en not in tt else ""
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        li = xbmcgui.ListItem(label=dt); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # Si hay dos partes separadas por " : ", quedarse con la segunda (suele ser el titulo real)
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip() # Devolver limpio

def _lfd(q, ot, mode=""):
    cq = _clean_title(q)
    rs = []
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    else:
        # Logica estandar para series/programas
        rs = _sr(cq) 
        if not rs and cq != q: rs = _sr(q) # Intentar con el original si el limpio falla
    
    if not rs: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw)
    
    if not rs: xbmcgui.Dialog().notification("AtresDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR); return
    
    sr = _gsr(cq, rs, mode)[:25] # Aumentamos un poco el limite para tener mas donde ordenar
    
    # YA NO reordenamos solo por duracion, confiamos en el score de _gsr que ahora pondera ambas cosas
    # if mode == "movie":
    #    sr.sort(key=lambda x: int(x[1].get("duration", 0)), reverse=True)

    if not sr: xbmcgui.Dialog().notification("AtresDaily", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR); return
    
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except: du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _pv(vid):
    mu = f"{_E4}{vid}"
    try:
        r = requests.get(mu); d = r.json(); qs = d.get("qualities", {}); murl = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL": murl = s.get("url"); break
        if not murl: xbmcgui.Dialog().notification("AtresDaily", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR); return
        try: m3c = requests.get(murl).text
        except: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        vs = []; ls = m3c.splitlines()
        for i, l in enumerate(ls):
            if l.startswith("#EXT-X-STREAM-INF"):
                u = ls[i+1] if i+1 < len(ls) else ""
                if not u or u.startswith("#"): continue
                rm = re.search(r'RESOLUTION=(\d+x\d+)', l); bm = re.search(r'BANDWIDTH=(\d+)', l)
                rs = rm.group(1) if rm else "Unknown"; bw = int(bm.group(1)) if bm else 0
                vs.append({'label': f"{rs} ({int(bw/1024)} kbps)", 'url': u, 'bandwidth': bw})
        vs.sort(key=lambda x: x['bandwidth'], reverse=True)
        if not vs: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        lbs = [v['label'] for v in vs]; rt = xbmcgui.Dialog().select("Selecciona Calidad", lbs)
        su = vs[rt]['url'] if rt >= 0 else vs[0]['url']
        if rt < 0: xbmcgui.Dialog().notification("AtresDaily", "Reproduciendo máxima calidad...", xbmcgui.NOTIFICATION_INFO)
        li = xbmcgui.ListItem(path=su); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
    except Exception as e: _l(f"Play Error: {e}"); xbmcgui.Dialog().ok("Error", str(e))

def _sr(q):
    try:
        p = {"search": q, "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url", "limit": 50}
        r = requests.get(_E3, params=p, headers={"User-Agent": _H["User-Agent"]}); return r.json().get("list", [])
    except: return []

def _gsr(q, rs, mode=""):
    if not rs: return []
    sc = []; ql = q.lower().strip(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip(); tl = t.lower()
        if not t: continue
        
        # Base Similarity Score
        rt = difflib.SequenceMatcher(None, ql, tl).ratio(); s = rt
        
        # FILTRO ESTRICTO: Si no contiene las palabras clave de la busqueda, penalizar fuertemente
        # (Esto evita que salgan resultados random como 'La Monja' buscando 'Top Gun')
        q_words = [w for w in ql.split() if len(w) > 3] # Palabras importantes (>3 letras)
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0: 
                s -= 1.0 # Penalizacion masiva si no coincide ninguna palabra clave
            elif matches < len(q_words):
                s -= 0.1 # Pequeña penalizacion si faltan palabras

        if ql in tl: s += 0.35 # Match contenido exacto
        
        # Word Overlap Score
        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if len(common) > 0: s += (len(common) / len(words_q)) * 0.2
        
        # Number Match Score
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
            
        # Duration Score (Prioritize Full Movies/Episodes)
        # IMPORTANTE: Solo aplicamos bonus de duracion si el titulo coincide razonablemente bien (s > 0.3)
        # Esto evita que 'La Monja' (larga) gane a 'Iron Man 3' (corto) si el titulo no se parece.
        du = r.get("duration", 0)
        try: du = int(du)
        except: du = 0
        
        if s > 0.3: # Solo si hay match de titulo decente
            if du > 600: s += 0.6    # Gran bonus si coincide titulo y es larga
            elif du > 300: s += 0.2
            elif du < 180: s -= 0.1  # Penalizacion leve por ser muy corto (trailer)
        else:
            # Si el titulo no coincide bien, la duracion NO ayuda.
            pass
        
        # Language Bonus (Spanish preference)
        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15

        # Movie specific filtering
        if mode == "movie":
            # Penalize non-movie content
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            # Bonus for explicit movie indicators
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2

        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc

def router(ps):
    if not _check_validity():
        xbmcgui.Dialog().ok("AtresDaily", "Esta versión del addon ha sido desactivada remotamente.\nPor favor, busca una actualización.")
        return

    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")
    if a == "ls": _ls(p.get("cid"))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr": _lfd(p.get("q"), p.get("ot"), p.get("mode", ""))
    elif a == "pv": _pv(p.get("vid"))
    elif a == "info": _info()
    elif a == "web_info": _web_info()
    elif a == "manual_search": _manual_search()
    elif a == "top_movies": _top_movies(p.get("page"))
    elif a == "show_history": _show_history()
    elif a == "clear_history": _clear_history()
    elif a == "toggle_debug": _toggle_debug()
    elif a == "clear_cache": _clear_cache()
    elif a == "sanitized_info": _sanitized_info()
    else: 
        # Solo comprobar mensajes si estamos en el menu principal
        _check_messages()
        main_menu()

if __name__ == "__main__": router(sys.argv[2][1:])

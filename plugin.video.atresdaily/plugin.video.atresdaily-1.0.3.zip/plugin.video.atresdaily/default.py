# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import json
import difflib
import re
import base64

try:
    import requests
except ImportError:
    xbmc.log("[AtresDaily] Failed to import requests module", xbmc.LOGERROR)
    sys.exit(1)

# Encoded configuration
def _d(s): return base64.b64decode(s).decode('utf-8')
_c = lambda x: ''.join([chr(ord(c) ^ 0x1F) for c in x])

_E0 = _d("aHR0cHM6Ly9hcGkuYXRyZXNwbGF5ZXIuY29t")
_E1 = _d("NWE2YjMyNjY3ZWQxYTgzNDQ5M2VjMDNi")
_E2 = {"a": _d("NWE2YTFiMjI5ODZiMjgxZDE4YTUxMmI4"), "b": _d("NWE2YTFiYTA5ODZiMjgxZDE4YTUxMmI5"), 
       "c": _d("NWIwNjdiZjM5ODZiMjhiMGEyN2MyZjQy"), "d": _d("NWE2YTI0YjE5ODZiMjgxZDE4YTUxMmMw"),
       "e": _d("NWE2YTIxNWU5ODZiMjgxZDE4YTUxMmJj"), "f": _d("NWI1ZjJmNzc3ZWQxYTg2ODYwMTAyMTQ0")}
_E3 = _d("aHR0cHM6Ly9hcGkuZGFpbHltb3Rpb24uY29tL3ZpZGVvcw==")
_E4 = _d("aHR0cHM6Ly93d3cuZGFpbHltb3Rpb24uY29tL3BsYXllci9tZXRhZGF0YS92aWRlby8=")

_H = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Origin": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t"),
    "Referer": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29tLw==")
}

def _l(m): xbmc.log(f"[AtresDaily] {m}", xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)

def _fix_img(t):
    if not t: return ""
    if t.startswith("//"): t = "https:" + t
    elif t.startswith("/"): t = _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t") + t
    if t.endswith("/"): t += "1280x720.jpg"
    return t

def main_menu():
    cats = [
        {"title": "Series", "id": _E2["a"]}, {"title": "Programas", "id": _E2["b"]},
        {"title": "Documentales", "id": _E2["c"]}, {"title": "Infantil", "id": _E2["d"]},
        {"title": "Actualidad", "id": _E2["e"]}, {"title": "Cine", "id": _E2["f"]},
    ]
    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=c["id"]), listitem=li, isFolder=True)
    li = xbmcgui.ListItem(label="ℹ️ Información del Addon")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info"), listitem=li, isFolder=False)
    li = xbmcgui.ListItem(label="Mas en: https://github.com/fullstackcurso")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="web_info"), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _info():
    t = (
        "[B]AtresDaily[/B]\nAddon creado por RubénSDFA1labernt\n\n"
        "[B]Información importante:[/B]\n• Este addon es completamente GRATUITO\n"
        "• Sin ánimo de lucro\n• NO aloja ningún contenido\n"
        "• Solo actúa como buscador de vídeos en internet\n• No contiene software malicioso\n\n"
        "[B]¿Cómo funciona?[/B]\nEl addon explora catálogos públicos y realiza "
        "búsquedas en internet usando únicamente el nombre del contenido.\n\n"
        "NO está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres el "
        "capítulo completo, solo un trailer, un resumen, o contenido "
        "similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible públicamente en internet.\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "El desarrollador de este addon NO se hace responsable del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de las búsquedas. El usuario es el único "
        "responsable de cumplir con las leyes de su país. Este addon "
        "se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        "[B]Contacto:[/B]\n938749237h@proton.me"
    )
    xbmcgui.Dialog().textviewer("Información de AtresDaily", t)

def _web_info():
    t = (
        "https://github.com/fullstackcurso\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita mi GitHub para más proyectos como este.[/B]\n\n"
        "Allí encontrarás mis otros trabajos y actualizaciones.\n"
        "Cualquier apoyo o difusión de mis proyectos se agradece enormemente.\n\n"
        "------------------------------------------------\n"
        "[B]NOTA:[/B] (No vendo cursos)\n"
        "La cuenta se llama así simplemente porque la creé cuando "
        "estaba estudiando Full Stack."
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _ls(cid):
    u = f"{_E0}/client/v1/row/search"
    p = {"entityType": "ATPFormat", "sectionCategory": "true", "mainChannelId": _E1, "categoryId": cid, "sortType": "THE_MOST", "size": 50, "page": 0}
    try:
        r = requests.get(u, params=p, headers=_H); r.raise_for_status(); d = r.json()
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e)); return
    items = d.get("itemRows", [])
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try: dr = _sr(tt); th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except: th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)
        except: continue
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    try: r = requests.get(au, headers=_H); r.raise_for_status(); d = r.json()
    except: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", [])
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth); return
    if id_: _rel(id_, st, sth); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"🔍 Buscar '{st}' en Internet"); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth=""):
    try: r = requests.get(ru, headers=_H); d = r.json(); _rel(d.get("itemRows", []), st, sth)
    except: pass

def _rel(items, st, sth=""):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt
        sq = f"{st} {tt}"; sq += f" {en}" if en and en not in tt else ""
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        li = xbmcgui.ListItem(label=dt); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfd(q, ot):
    rs = _sr(q)
    if not rs: xbmcgui.Dialog().notification("AtresDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR); return
    sr = _gsr(q, rs)[:15]
    if not sr: xbmcgui.Dialog().notification("AtresDaily", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR); return
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except: du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot; lb = f"{vt} ({int(sc*100)}% match)"
        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _pv(vid):
    mu = f"{_E4}{vid}"
    try:
        r = requests.get(mu); d = r.json(); qs = d.get("qualities", {}); murl = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL": murl = s.get("url"); break
        if not murl: xbmcgui.Dialog().notification("AtresDaily", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR); return
        try: m3c = requests.get(murl).text
        except: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        vs = []; ls = m3c.splitlines()
        for i, l in enumerate(ls):
            if l.startswith("#EXT-X-STREAM-INF"):
                u = ls[i+1] if i+1 < len(ls) else ""
                if not u or u.startswith("#"): continue
                rm = re.search(r'RESOLUTION=(\d+x\d+)', l); bm = re.search(r'BANDWIDTH=(\d+)', l)
                rs = rm.group(1) if rm else "Unknown"; bw = int(bm.group(1)) if bm else 0
                vs.append({'label': f"{rs} ({int(bw/1024)} kbps)", 'url': u, 'bandwidth': bw})
        vs.sort(key=lambda x: x['bandwidth'], reverse=True)
        if not vs: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        lbs = [v['label'] for v in vs]; rt = xbmcgui.Dialog().select("Selecciona Calidad", lbs)
        su = vs[rt]['url'] if rt >= 0 else vs[0]['url']
        if rt < 0: xbmcgui.Dialog().notification("AtresDaily", "Reproduciendo máxima calidad...", xbmcgui.NOTIFICATION_INFO)
        li = xbmcgui.ListItem(path=su); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
    except Exception as e: _l(f"Play Error: {e}"); xbmcgui.Dialog().ok("Error", str(e))

def _sr(q):
    try:
        p = {"search": q, "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url", "limit": 50}
        r = requests.get(_E3, params=p); return r.json().get("list", [])
    except: return []

def _gsr(q, rs):
    if not rs: return []
    sc = []; ql = q.lower(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", ""); rt = difflib.SequenceMatcher(None, ql, t.lower()).ratio(); s = rt
        tn = re.findall(r'(\d+)', t.lower())
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc

def router(ps):
    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")
    if a == "ls": _ls(p.get("cid"))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr": _lfd(p.get("q"), p.get("ot"))
    elif a == "pv": _pv(p.get("vid"))
    elif a == "info": _info()
    elif a == "web_info": _web_info()
    else: main_menu()

if __name__ == "__main__": router(sys.argv[2][1:])
